# study — ImageNet-C × ViT × Pin-GTSVM

Package `vitpin`. Reuses the Pin-GTSVM solver from `../python_port` (package `hazypark`).
Plans, rules and decisions: `../docs/`. Outputs: `../results/`.

| Path | Contents |
|---|---|
| `configs/class_sets/` | Approved class sets: `similar20.json` (20 terriers), `dissimilar20.json` (20 unrelated classes) |
| `scripts/select_classes.py` | Offline, deterministic class selection (WordNet 3.0 + BREEDS); `--check` verifies the saved files |
| `src/vitpin/` | Library code (class-set loader now; data, features, fast solver, experiment framework later) |
| `tests/` | `pytest study/tests` |

Runtime needs only the JSON class-set files; nltk/WordNet are needed only to re-run the selection.
