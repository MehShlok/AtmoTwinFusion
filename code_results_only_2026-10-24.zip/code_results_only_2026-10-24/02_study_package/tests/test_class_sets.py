import importlib.util
import json
import os
from pathlib import Path

import pytest

from vitpin import load_class_set

STUDY = Path(__file__).resolve().parents[1]
CACHE = Path(os.environ.get("STUDY_CACHE", r"D:\ResearchPaper2\.cache"))


def test_both_sets_load_and_are_disjoint():
    sim, dis = load_class_set("similar20"), load_class_set("dissimilar20")
    assert len(sim) == len(dis) == 20
    assert not set(sim.wnids) & set(dis.wnids)


def test_ids_match_imagenet_index_order():
    synsets = CACHE / "imagenet_meta" / "imagenet_synsets.txt"
    if not synsets.exists():
        pytest.skip("ImageNet ID list not cached")
    wnids = synsets.read_text(encoding="utf-8").split()
    for name in ("similar20", "dissimilar20"):
        cs = load_class_set(name)
        assert all(wnids[i] == w for i, w in zip(cs.indices, cs.wnids))


@pytest.mark.parametrize(
    "mutate,match",
    [
        (lambda c: c.__setitem__(1, dict(c[0])), "duplicate"),
        (lambda c: c[0].__setitem__("wnid", "x123"), "malformed"),
        (lambda c: c[0].__setitem__("index", 1000), "out of range"),
        (lambda c: c.reverse(), "index order"),
        (lambda c: c.clear(), "non-empty"),
    ],
)
def test_invalid_files_are_rejected(tmp_path, mutate, match):
    data = json.loads((STUDY / "configs" / "class_sets" / "similar20.json").read_text(encoding="utf-8"))
    mutate(data["classes"])
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ValueError, match=match):
        load_class_set(bad)


def test_missing_file():
    with pytest.raises(FileNotFoundError):
        load_class_set("no_such_set")


def test_selection_is_reproducible():
    """Re-running the offline selection gives exactly the saved files (needs WordNet + cached source lists)."""
    pytest.importorskip("nltk")
    from nltk.corpus import wordnet as wn

    try:
        wn.ensure_loaded()
    except LookupError:
        pytest.skip("WordNet corpus not installed")
    for needed in ("imagenet_meta/imagenet_synsets.txt", "imagenet_meta/imagenet_synset_to_lemma.txt", "breeds/class_hierarchy.txt"):
        if not (CACHE / needed).exists():
            pytest.skip(f"{needed} not cached")
    spec = importlib.util.spec_from_file_location("select_classes", STUDY / "scripts" / "select_classes.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.build(CACHE)
    for name, data in result.items():
        saved = json.loads((STUDY / "configs" / "class_sets" / f"{name}.json").read_text(encoding="utf-8"))
        assert saved == data, f"{name} differs from a fresh selection"
