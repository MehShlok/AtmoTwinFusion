"""Phase 8 gate helpers on tiny fake data (CPU, seconds)."""

import numpy as np
import pandas as pd
import pytest

pytest.importorskip("torch")
hazypark = pytest.importorskip("hazypark.pin_gtsvm")

from vitpin import phase8  # noqa: E402


def fake(k=3, train=12, test=6, d=5, seed=0):
    """Manifest-like rows of one class set + features (row i of features = manifest row i)."""
    rng = np.random.default_rng(seed)
    centres = rng.normal(0, 2, (k, d))
    rows, feats = [], []
    for c in range(k):
        for split, n in (("train", train), ("test", test)):
            for r in range(n):
                rows.append({"class_set": "toy", "wnid": f"n{c:02d}", "split": split, "corruption": f"k{r % 2}"})
                feats.append(centres[c] + rng.normal(0, 1, d))
    rows.append({"class_set": "other", "wnid": "n99", "split": "train", "corruption": "k0"})
    feats.append(np.full(d, 1e6))  # another class set: must be ignored, including by the standardisation
    return np.asarray(feats, dtype=np.float32), pd.DataFrame(rows)


def test_class_set_data_standardises_with_training_rows_only():
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    assert data.Xtr.shape == (36, 5) and data.Xte.shape == (18, 5) and data.wnids == ["n00", "n01", "n02"]
    np.testing.assert_allclose(data.Xtr.mean(0), 0, atol=1e-9)
    np.testing.assert_allclose(data.Xtr.std(0), 1, atol=1e-9)
    with pytest.raises(ValueError):
        phase8.class_set_data(X, man, "missing")


def test_reference_equals_hazypark_classifier():
    """fit_predict with m_c="all" is the exact method: same predictions as hazypark.PinGTSVM (CVXOPT)."""
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    ref = phase8.fit_predict(data, sigma, "all", [(1.0, 0.5), (32.0, 1.0)])
    for c, tau in [(1.0, 0.5), (32.0, 1.0)]:
        for i, j in [(0, 2), (1, 2)]:
            A, B = data.Xtr[data.ytr == i], data.Xtr[data.ytr == j]
            Xe = data.Xte[(data.yte == i) | (data.yte == j)]
            exact = hazypark.PinGTSVM(c1=c, c2=c, tau=tau, sigma=sigma, eps=phase8.EPS,
                                      qp_options={"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10}).fit(
                np.vstack([A, B]), np.r_[np.ones(len(A)), -np.ones(len(B))]).predict(Xe)
            assert np.array_equal(ref["pred"][(c, tau)][(i, j)], np.where(exact == 1, i, j))


def test_exact_reference_equals_all_rows_fast_model():
    """The CVXOPT reference (paper's method) and the fast model with every training row as the basis agree exactly."""
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    s = [(1.0, 0.5), (2.0 ** -5, 0.8), (32.0, 0.0)]
    logged = []
    ref = phase8.exact_reference(data, sigma, s, qp_options={"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10},
                                 log=logged.append)
    same = phase8.fit_predict(data, sigma, "all", s)
    assert ref["not_optimal"] == 0 and logged and logged[-1].startswith("3/3 pairs")
    for setting in s:
        assert set(ref["pred"][setting]) == {(0, 1), (0, 2), (1, 2)}
        for pair, p in ref["pred"][setting].items():
            assert np.array_equal(p, same["pred"][setting][pair])
    part = phase8.exact_reference(data, sigma, s[:1], pairs=[(1, 2)])
    assert set(part["pred"][s[0]]) == {(1, 2)}


def test_corner_settings_cover_the_paper_grid_extremes():
    cs = {c for c, _ in phase8.CORNER_SETTINGS}
    taus = {t for _, t in phase8.CORNER_SETTINGS}
    assert min(cs) == 2.0 ** -5 and max(cs) == 2.0 ** 5  # paper Sec. 5.9: c in {2^-5 ... 2^5}
    assert {0.5, 0.8, 1.0} <= taus and 0.0 in taus  # paper's tau values + the hinge case (RQ2)
    assert len(phase8.CORNER_SETTINGS) == 16


def test_fast_compare_gate_and_table_end_to_end():
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    s = [(1.0, 0.5)]
    ref = phase8.fit_predict(data, sigma, "all", s)
    fast = phase8.fit_predict(data, sigma, 4, s)
    assert set(fast["pred"][s[0]]) == {(0, 1), (0, 2), (1, 2)} and 0 <= fast["ovo_acc"][s[0]] <= 1
    cmp = phase8.compare(data, ref["pred"], fast["pred"], {"m_c": 4})
    assert len(cmp) == 3 and (cmp.n_test == 12).all() and (cmp.agree <= cmp.n_test).all()
    assert phase8.gate(cmp)["n_test"] == 36
    same = phase8.compare(data, ref["pred"], ref["pred"], {"m_c": "all"})
    assert phase8.gate(same)["agreement"] == 1.0 and phase8.gate(same)["passed"]
    part = phase8.fit_predict(data, sigma, 4, s, pairs=[(1, 2)])
    assert set(part["pred"][s[0]]) == {(1, 2)} and not part["ovo_acc"]
    table = phase8.predictions_table(ref["pred"])
    assert set(table) == {"c=1.0|tau=0.5|0-1", "c=1.0|tau=0.5|0-2", "c=1.0|tau=0.5|1-2"}
    assert all(v.dtype == np.int8 for v in table.values())


def test_gate_thresholds():
    base = {"i": 0, "j": 1, "n_test": 1000}
    ok = pd.DataFrame([{**base, "agree": 990, "correct_fast": 900, "correct_exact": 905}])
    assert phase8.gate(ok)["passed"]  # 99.0 % agreement, -0.5 points
    assert not phase8.gate(ok.assign(agree=989))["passed"]
    assert not phase8.gate(ok.assign(correct_fast=894))["passed"]  # -1.1 points
    assert not phase8.gate(ok.iloc[:0])["passed"]


def test_grid_is_the_approved_one():
    assert phase8.SIGMA_MULTS_GRID == (0.25, 0.5, 1.0, 2.0, 4.0) and phase8.GRID_CV_FOLDS == (1, 2, 3)
    cs = sorted({c for c, _ in phase8.GRID_SETTINGS})
    assert cs == [2.0 ** k for k in (-5, -3, -1, 1, 3, 5)]
    assert sorted({t for _, t in phase8.GRID_SETTINGS}) == [0.0, 0.5, 0.8, 1.0] and len(phase8.GRID_SETTINGS) == 24


def test_fold_data_uses_training_rows_only_without_source_overlap():
    rng = np.random.default_rng(0)
    rows = []
    for c in range(3):
        for src in range(10):
            split, fold = ("train", src % 5 + 1) if src < 8 else ("test", 0)
            for corr in range(2):
                rows.append({"class_set": "toy", "wnid": f"n{c}", "split": split, "cv_fold": fold,
                             "source_id": c * 100 + src, "corruption": f"k{corr}"})
    man = pd.DataFrame(rows)
    X = rng.normal(size=(len(man), 4)).astype(np.float32)
    d = phase8.fold_data(X, man, "toy", 2)
    tr = man[(man.split == "train") & (man.cv_fold != 2)]
    va = man[(man.split == "train") & (man.cv_fold == 2)]
    assert d.Xtr.shape == (len(tr), 4) and d.Xte.shape == (len(va), 4)
    assert not set(tr.source_id) & set(va.source_id)
    np.testing.assert_allclose(d.Xtr.mean(0), 0, atol=1e-9)
    with pytest.raises(ValueError):
        phase8.fold_data(X, man, "toy", 0)  # 0 marks test rows, not a CV fold


def test_tuning_pairs_are_seeded_and_distinct():
    a, b = phase8.tuning_pairs(), phase8.tuning_pairs()
    assert a == b and len(set(a)) == 20 and all(0 <= i < j < 20 for i, j in a)
    assert phase8.tuning_pairs(seed=3) != a
