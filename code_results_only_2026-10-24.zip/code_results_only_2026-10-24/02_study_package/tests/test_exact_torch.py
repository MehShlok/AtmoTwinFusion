"""Exact Pin-GTSVM in torch (Phase 8 checks v4/v5) on tiny data — CPU only, seconds."""

import numpy as np
import pytest

torch = pytest.importorskip("torch")
hazypark = pytest.importorskip("hazypark.pin_gtsvm")

from vitpin import exact_torch, phase8  # noqa: E402
from test_phase8 import fake  # noqa: E402


@pytest.mark.parametrize("c,tau", [(1.0, 0.5), (2.0 ** -5, 0.8), (32.0, 0.0), (32.0, 1.0)])
def test_dense_interior_point_matches_cvxopt(c, tau):
    rng = np.random.default_rng(0)
    M = rng.normal(size=(40, 25))
    Q = M @ M.T / 25 + 1e-3 * np.eye(40)  # PSD, moderately conditioned, like a twin-SVM dual
    ref, status = hazypark.solve_box_qp(Q, c, tau, {"abstol": 1e-11, "reltol": 1e-11, "feastol": 1e-11})
    x, info = exact_torch.solve_box_qp_dense(torch.from_numpy(Q), c, tau)
    assert status == "optimal" and info.converged
    assert np.abs(x.numpy() - ref).max() <= 1e-5 * c
    assert (x.numpy() >= -tau * c - 1e-12).all() and (x.numpy() <= c + 1e-12).all()


def test_dense_interior_point_float32_does_not_crash_and_float64_finish_converges():
    rng = np.random.default_rng(1)
    M = rng.normal(size=(60, 5))
    Q = torch.from_numpy(M @ M.T).float()  # rank 5: numerically indefinite in float32
    x, info = exact_torch.solve_box_qp_dense(Q, 32.0, 1.0)
    assert torch.isfinite(x).all() and info.iterations > 0
    Qd = Q.double().numpy()
    ref, _ = hazypark.solve_box_qp(Qd, 32.0, 1.0, {"abstol": 1e-11, "reltol": 1e-11, "feastol": 1e-11})

    def objective(v):  # Q has rank 5, so the optimal x is not unique: compare objective values
        return 0.5 * v @ Qd @ v - v.sum()

    for first in (5, 30):
        xf, infof = exact_torch.solve_box_qp_dense(Q, 32.0, 1.0, finish_dtype=torch.float64, first_iter=first)
        assert xf.dtype == torch.float64 and infof.converged
        assert abs(objective(xf.numpy()) - objective(ref)) <= 1e-6 * abs(objective(ref))


def test_qr_and_cholesky_builds_agree_in_float64():
    rng = np.random.default_rng(2)
    A, B = (torch.from_numpy(rng.normal(size=(9, 4))) for _ in range(2))
    ch = exact_torch.build_pair(A, B, 2.0, 0.05, "cholesky")
    qr = exact_torch.build_pair(A, B, 2.0, 0.05, "qr")
    for k in ("1", "2"):
        Qc, Qq = ch["Z" + k].T @ ch["Z" + k], qr["Z" + k].T @ qr["Z" + k]
        np.testing.assert_allclose(Qq.numpy(), Qc.numpy(), atol=1e-9)
        lam = torch.from_numpy(rng.uniform(-0.5, 1.0, 9))
        np.testing.assert_allclose(exact_torch._surface(qr["R" + k], qr["Z" + k], lam, 1.0).numpy(),
                                   exact_torch._surface(ch["R" + k], ch["Z" + k], lam, 1.0).numpy(), atol=1e-8)
    with pytest.raises(ValueError):
        exact_torch.build_pair(A, B, 2.0, 0.05, "lu")


def test_exact_fit_predict_equals_cvxopt_reference():
    """fp64 torch = the paper's method via CVXOPT (phase8.exact_reference): identical predictions."""
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    s = [(1.0, 0.5), (2.0 ** -5, 0.8), (32.0, 0.0), (32.0, 1.0)]
    ref = phase8.exact_reference(data, sigma, s, qp_options={"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10})
    logged = []
    out = exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision="fp64", log=logged.append)
    assert logged[-1].startswith("3/3 pairs") and all(i.converged for i in out["solve"])
    for setting in s:
        for pair, p in ref["pred"][setting].items():
            assert np.array_equal(out["pred"][setting][pair], p)
    low = exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision="fp32qr")
    agree = np.mean([np.mean(low["pred"][st][pr] == p) for st in s for pr, p in ref["pred"][st].items()])
    assert agree >= 0.95 and low["build_seconds"] >= 0  # real-size accuracy is judged on Kaggle (check v5)
    with pytest.raises(ValueError):
        exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision="fp16")


def test_load_reference_roundtrip(tmp_path):
    pred = {(1.0, 0.5): {(0, 1): np.array([0, 1, 1]), (2, 5): np.array([5, 2])},
            (0.03125, 0.8): {(0, 1): np.array([1, 1, 0])}}
    path = tmp_path / "reference_corners_toy_sigma1.0.npz"
    np.savez_compressed(path, **phase8.predictions_table(pred))
    back = phase8.load_reference(path)
    assert set(back) == set(pred)
    for s, by_pair in pred.items():
        for pair, p in by_pair.items():
            assert np.array_equal(back[s][pair], p)


def test_batched_solver_matches_single_solver():
    rng = np.random.default_rng(3)
    Qs = []
    for _ in range(2):
        M = rng.normal(size=(30, 22))
        Qs.append(M @ M.T / 22 + 1e-3 * np.eye(30))
    Qs = torch.from_numpy(np.stack(Qs))
    which, cs, taus = [0, 1, 0, 1, 0], [1.0, 2.0 ** -5, 32.0, 0.125, 1.0], [0.5, 0.8, 0.0, 1.0, 1.0]
    X, infos = exact_torch.solve_box_qp_batch(Qs, which, cs, taus)
    assert X.shape == (5, 30) and all(i.converged for i in infos)
    for p in range(5):
        x1, _ = exact_torch.solve_box_qp_dense(Qs[which[p]], cs[p], taus[p])
        np.testing.assert_allclose(X[p].numpy(), x1.numpy(), atol=1e-6 * cs[p])
    with pytest.raises(ValueError):
        exact_torch.solve_box_qp_batch(Qs, [0], [0.0], [0.5])
    with pytest.raises(ValueError):
        exact_torch.solve_box_qp_batch(Qs, [0], [1.0], [1.5])


def test_batched_float32_with_float64_finish_reaches_the_optimum():
    rng = np.random.default_rng(1)
    M = rng.normal(size=(60, 5))
    Qd = M @ M.T  # rank 5: numerically indefinite in float32
    X, infos = exact_torch.solve_box_qp_batch(torch.from_numpy(Qd).float()[None], [0, 0], [32.0, 1.0], [1.0, 0.5],
                                              finish_dtype=torch.float64, first_iter=5)
    assert X.dtype == torch.float64 and all(i.converged for i in infos)
    for p, (c, tau) in enumerate([(32.0, 1.0), (1.0, 0.5)]):
        ref, _ = hazypark.solve_box_qp(Qd, c, tau, {"abstol": 1e-11, "reltol": 1e-11, "feastol": 1e-11})
        obj = lambda v: 0.5 * v @ Qd @ v - v.sum()  # noqa: E731 - rank-deficient Q: compare objective values
        assert abs(obj(X[p].numpy()) - obj(ref)) <= 1e-6 * abs(obj(ref))


@pytest.mark.parametrize("precision", ["fp64", "fp32qr"])
def test_batched_fit_predict_equals_unbatched(precision):
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    s = [(1.0, 0.5), (2.0 ** -5, 0.8), (32.0, 0.0), (32.0, 1.0)]
    one = exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision=precision)
    logged = []
    many = exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision=precision, batch=12,
                                         log=logged.append)  # 12 QPs = 1 pair x 2 planes x 4 settings + a partial pair
    assert logged[-1].startswith("3/3 pairs") and len(many["solve"]) == len(one["solve"])
    for setting in s:
        for pair, p in one["pred"][setting].items():
            assert np.array_equal(many["pred"][setting][pair], p)
    if precision == "fp64":
        ref = phase8.exact_reference(data, sigma, s, qp_options={"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10})
        for setting in s:
            for pair, p in ref["pred"][setting].items():
                assert np.array_equal(many["pred"][setting][pair], p)


def test_batched_solver_isolates_a_failing_problem():
    """A problem that cannot be solved (NaN matrix) is frozen; the others in the batch still converge, exactly."""
    rng = np.random.default_rng(4)
    M = rng.normal(size=(30, 22))
    good = M @ M.T / 22 + 1e-3 * np.eye(30)
    Qs = torch.from_numpy(np.stack([good, np.full((30, 30), np.nan)]))
    X, infos = exact_torch.solve_box_qp_batch(Qs, [0, 1, 0], [1.0, 1.0, 32.0], [0.5, 0.5, 1.0])
    assert infos[0].converged and infos[2].converged and not infos[1].converged
    for p, (c, tau) in [(0, (1.0, 0.5)), (2, (32.0, 1.0))]:
        x1, single = exact_torch.solve_box_qp_dense(Qs[0], c, tau)
        np.testing.assert_allclose(X[p].numpy(), x1.numpy(), atol=1e-6 * c)
        assert infos[p].iterations <= single.iterations + 1  # its own count, not the batch's


def test_solve_index_names_every_qp():
    X, man = fake()
    data = phase8.class_set_data(X, man, "toy")
    sigma = phase8.median_sigma(data)
    s = [(1.0, 0.5), (32.0, 1.0)]
    for batch in (1, 12):
        out = exact_torch.exact_fit_predict(data, sigma, s, device="cpu", precision="fp32qr", batch=batch)
        assert len(out["solve_index"]) == len(out["solve"]) == 3 * 2 * 2
        assert {(i, j) for i, j, *_ in out["solve_index"]} == {(0, 1), (0, 2), (1, 2)}
        assert {q[-1] for q in out["solve_index"]} == {1, 2}
