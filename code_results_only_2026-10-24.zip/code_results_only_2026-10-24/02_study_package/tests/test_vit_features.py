"""Phase 7 extractor checks with randomly initialised models (no weight downloads, CPU only)."""

import numpy as np
import pandas as pd
import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("timm")

from PIL import Image  # noqa: E402

from vitpin.features import (  # noqa: E402
    BACKBONES,
    create_backbone,
    edge_metrics,
    embed,
    extract,
    load_image,
    manifest_fingerprint,
    sanity_accuracy,
)

EXPECTED = {  # name: (global dim, patch_mean dim or None)
    "dinov2_s14": (384, 384), "dinov2_b14": (768, 768), "dinov3_s16": (384, 384), "dinov3_b16": (768, 768),
    "siglip2_b16": (768, 768), "fastvit_sa12": (1024, None), "fastvit_sa24": (1024, None),
}


@pytest.mark.parametrize("name", sorted(BACKBONES))
def test_backbone_shapes(name):
    bb = create_backbone(name, pretrained=False)
    with torch.inference_mode():
        g, p = embed(bb, torch.randn(2, 3, 224, 224))
    assert g.shape == (2, EXPECTED[name][0]) and g.dtype == torch.float32
    assert (p is None) if EXPECTED[name][1] is None else p.shape == (2, EXPECTED[name][1])


def test_dinov3_uses_cls_not_timm_default_average():
    bb = create_backbone("dinov3_s16", pretrained=False)
    x = torch.randn(2, 3, 224, 224)
    with torch.inference_mode():
        feats = bb.model.forward_features(x)
        g, p = embed(bb, x)
    assert bb.prefix_tokens == 5  # CLS + 4 registers
    assert torch.equal(g, feats[:, 0].float())
    assert torch.allclose(p, feats[:, 5:].mean(1).float())  # registers excluded from the patch mean


def _jpeg(path, size=(224, 224)):
    Image.fromarray(np.random.default_rng(0).integers(0, 255, (*size[::-1], 3), dtype=np.uint8)).save(path)


def test_load_image(tmp_path):
    _jpeg(tmp_path / "a.jpg")
    t = load_image(tmp_path / "a.jpg", (0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    assert t.shape == (3, 224, 224) and -1.0 <= float(t.min()) and float(t.max()) <= 1.0
    _jpeg(tmp_path / "b.jpg", (200, 224))
    with pytest.raises(ValueError, match="expected 224x224"):
        load_image(tmp_path / "b.jpg", (0.5,) * 3, (0.5,) * 3)


def test_extract_keeps_order(tmp_path):
    paths = []
    for i in range(5):
        _jpeg(tmp_path / f"{i}.jpg")
        paths.append(str(tmp_path / f"{i}.jpg"))
    bb = create_backbone("dinov2_s14", pretrained=False)
    out = extract(bb, paths, device="cpu", batch_size=2, workers=0, log=lambda *_: None)
    assert out["global"].shape == (5, 384) and out["patch_mean"].shape == (5, 384)
    single = extract(bb, paths[3:4], device="cpu", batch_size=1, workers=0, log=lambda *_: None)
    np.testing.assert_allclose(out["global"][3], single["global"][0], rtol=1e-4, atol=1e-5)


def test_extract_time_limit(tmp_path):
    paths = []
    for i in range(3):
        _jpeg(tmp_path / f"{i}.jpg")
        paths.append(str(tmp_path / f"{i}.jpg"))
    bb = create_backbone("dinov2_s14", pretrained=False)
    with pytest.raises(TimeoutError, match="1/3 images"):
        extract(bb, paths, device="cpu", batch_size=1, workers=0, log=lambda *_: None, max_seconds=0)
    logged = []
    extract(bb, paths, device="cpu", batch_size=1, workers=0, log=logged.append, max_seconds=600)
    assert logged[0].startswith("dinov2_s14: 1/3") and logged[-1].startswith("dinov2_s14: 3/3")


@pytest.mark.parametrize("name", ["fastvit_sa12", "fastvit_sa24"])
def test_fastvit_is_reparameterised(name):
    model = create_backbone(name, pretrained=False).model
    blocks = [m for m in model.modules() if type(m).__name__ == "MobileOneBlock"]
    assert blocks and all(getattr(m, "reparam_conv", None) is not None for m in blocks)


def test_edge_metrics_cpu():
    m = edge_metrics(create_backbone("dinov2_s14", pretrained=False), device="cpu", cpu_repeats=2)
    assert 21 < m["params_m"] < 23 and m["gmacs"] > 1 and m["cpu_ms_b1"] > 0


def test_edge_metrics_siglip2_attention_pooling():
    """Regression (Phase 7 run v1): FlopCounterMode crashed on SigLIP 2's attention-pooling head."""
    bb = create_backbone("siglip2_b16", pretrained=False)
    assert not any(p.requires_grad for p in bb.model.parameters())
    assert edge_metrics(bb, device="cpu", cpu_repeats=1)["gmacs"] > 10


def test_manifest_fingerprint():
    m = pd.DataFrame({"path": ["a", "b"], "split": ["train", "test"], "cv_fold": [1, 0]})
    assert manifest_fingerprint(m) == manifest_fingerprint(m.copy())
    assert manifest_fingerprint(m) != manifest_fingerprint(m.assign(cv_fold=[2, 0]))


def test_sanity_accuracy_on_separable_features():
    rng = np.random.default_rng(0)
    rows = [{"class_set": "s", "wnid": w, "severity": 1, "split": sp} for w in ("a", "b") for sp in ["train"] * 30 + ["test"] * 10]
    m = pd.DataFrame(rows)
    feats = rng.normal(size=(len(m), 8)) + np.where((m.wnid == "a").to_numpy()[:, None], 3.0, -3.0)
    assert sanity_accuracy(feats, m)["s"] == 1.0
