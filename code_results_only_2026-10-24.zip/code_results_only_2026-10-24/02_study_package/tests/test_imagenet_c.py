import hashlib
import http.client
import io
import json
import tarfile

import pytest

from vitpin.class_sets import ClassSet
from vitpin.imagenet_c import (
    CORRUPTIONS,
    FAMILIES,
    SEVERITIES,
    _check_resumed,
    _ResumableReader,
    build_manifest,
    check_split,
    environment_report,
    find_root,
    verify_against_zenodo,
)

N = 10  # images per class in the synthetic copy (50 in the real dataset)
CLASSES = [ClassSet("toy_a", ("n00000001",), (1,), ("a",)), ClassSet("toy_b", ("n00000002",), (2,), ("b",))]
SOURCES = {"n00000001": range(100, 100 + N), "n00000002": range(500, 500 + N)}


def content(corruption, severity, wnid, sid):
    return f"{corruption}|{severity}|{wnid}|{sid}".encode()


@pytest.fixture
def copy_root(tmp_path):
    root = tmp_path / "input" / "imagenet-c" / "ImageNet-C"
    for corruption in CORRUPTIONS:
        for severity in SEVERITIES:
            for wnid, sids in SOURCES.items():
                folder = root / corruption / str(severity) / wnid
                folder.mkdir(parents=True)
                for sid in sids:
                    (folder / f"ILSVRC2012_val_{sid:08d}.JPEG").write_bytes(content(corruption, severity, wnid, sid))
    return root


def manifest_of(root, seed=0):
    return build_manifest(root, CLASSES, seed=seed, images_per_class=N, train_sources=5, cv_folds=5)


def test_find_root(copy_root, tmp_path):
    assert find_root(tmp_path / "input") == copy_root
    with pytest.raises(FileNotFoundError):
        find_root(tmp_path / "input" / "imagenet-c" / "ImageNet-C" / "fog")


def test_manifest_and_split(copy_root):
    m = manifest_of(copy_root)
    assert len(m) == 2 * len(CORRUPTIONS) * len(SEVERITIES) * N
    summary = check_split(m, train_sources=5, test_sources=5, cv_folds=5)
    assert summary["leakage"] == "none" and summary["source_images"] == 2 * N
    assert set(m.family) == set(FAMILIES)
    assert m.source_id.dtype.kind == "i"
    assert manifest_of(copy_root).equals(m)  # deterministic
    assert not manifest_of(copy_root, seed=1).split.equals(m.split)  # seed matters


def test_all_problems_are_reported(copy_root):
    folder = copy_root / "fog" / "3" / "n00000001"
    sorted(folder.iterdir())[0].unlink()  # one file missing
    (copy_root / "snow" / "1" / "n00000002" / "notes.txt").write_text("x")  # unexpected file
    with pytest.raises(ValueError) as err:
        manifest_of(copy_root)
    text = str(err.value)
    assert "fog/3/n00000001" in text and "snow/1/n00000002" in text and "same source images" in text


def test_leak_is_detected(copy_root):
    m = manifest_of(copy_root)
    leaked = m.copy()
    first = leaked.index[(leaked.split == "train")][0]
    sid = leaked.loc[first, "source_id"]
    leaked.loc[(leaked.source_id == sid) & (leaked.corruption == "fog"), ["split", "cv_fold"]] = ["test", 0]
    with pytest.raises(AssertionError, match="more than one split"):
        check_split(leaked, train_sources=5, test_sources=5, cv_folds=5)


@pytest.mark.parametrize("write_mode", ["w", "w:gz"], ids=["plain-tar", "gzip-tar"])  # Zenodo's files are gzip
def test_verify_against_official_archive(copy_root, tmp_path, write_mode):
    wnids = {"n00000001", "n00000002"}
    tar_path = tmp_path / "blur.tar"
    with tarfile.open(tar_path, write_mode) as tar:
        for corruption in FAMILIES["blur"]:
            for severity in SEVERITIES:
                for wnid, sids in [*SOURCES.items(), ("n09999999", range(3))]:  # an extra class is ignored
                    for sid in sids:
                        data = content(corruption, severity, wnid, sid)
                        if (corruption, severity, wnid, sid) == ("glass_blur", 2, "n00000001", 100):
                            data = b"tampered"
                        info = tarfile.TarInfo(f"./{corruption}/{severity}/{wnid}/ILSVRC2012_val_{sid:08d}.JPEG")
                        info.size = len(data)
                        tar.addfile(info, fileobj=io.BytesIO(data))
    (copy_root / "zoom_blur" / "5" / "n00000002" / "ILSVRC2012_val_00000500.JPEG").unlink()
    record = tmp_path / "record.json"
    record.write_text(json.dumps({"files": [{
        "key": "blur.tar", "size": tar_path.stat().st_size,
        "checksum": "md5:" + hashlib.md5(tar_path.read_bytes()).hexdigest(),
        "links": {"content": tar_path.as_uri()},
    }]}))
    report = verify_against_zenodo(copy_root, wnids, "blur", record_api=record.as_uri(), images_per_class=N)
    total = len(FAMILIES["blur"]) * len(SEVERITIES) * 2 * N
    assert report["md5_ok"] and report["size_ok"]
    assert report["official_files_compared"] == total
    assert report["mismatched"] == 1 and report["missing_in_copy"] == 1 and report["matched"] == total - 2
    assert report["official_groups"] == report["expected_groups"] == 4 * 5 * 2
    assert report["official_counts_ok"]


def test_bad_checksum_is_flagged(copy_root, tmp_path):
    tar_path = tmp_path / "blur.tar"
    with tarfile.open(tar_path, "w"):
        pass
    record = tmp_path / "record.json"
    record.write_text(json.dumps({"files": [{"key": "blur.tar", "size": 1, "checksum": "md5:" + "0" * 32,
                                             "links": {"content": tar_path.as_uri()}}]}))
    report = verify_against_zenodo(copy_root, {"n00000001"}, "blur", record_api=record.as_uri(), images_per_class=N)
    assert not report["md5_ok"] and not report["size_ok"] and not report["official_counts_ok"]


def test_non_archive_download_is_explained(copy_root, tmp_path):
    """Regression (Phase 6 v1 on Kaggle): an unreadable stream must say what was received, not just 'invalid header'."""
    fake = tmp_path / "blur.tar"
    fake.write_bytes(b"<!DOCTYPE html><html>not an archive</html>" * 20)
    record = tmp_path / "record.json"
    record.write_text(json.dumps({"files": [{"key": "blur.tar", "size": fake.stat().st_size, "checksum": "md5:" + "0" * 32,
                                             "links": {"self": fake.as_uri()}}]}))
    with pytest.raises(ValueError, match=r"not a readable tar archive \(first bytes: 3c 21 44 4f"):
        verify_against_zenodo(copy_root, {"n00000001"}, "blur", record_api=record.as_uri(), images_per_class=N)


class _CutConnection(io.BytesIO):
    """A connection that delivers at most ``limit`` bytes, then ends early or raises (like a dropped download)."""

    def __init__(self, data, limit, fail):
        super().__init__(data[:limit])
        self.fail = fail

    def read(self, size=-1):
        chunk = super().read(size)
        if not chunk and self.fail:
            raise http.client.IncompleteRead(b"")
        return chunk


@pytest.mark.parametrize("fail", [False, True], ids=["silent-end", "incomplete-read"])
def test_resumable_reader_reassembles_dropped_download(fail):
    """Regression (Phase 6 v2 on Kaggle): 'unexpected end of data' when the download was cut off."""
    data = bytes(range(256)) * 400  # 102,400 bytes
    opened = []

    def open_at(offset):
        opened.append(offset)
        return _CutConnection(data[offset:], 30_000, fail)  # every connection drops after 30,000 bytes

    reader = _ResumableReader(open_at, total=len(data), log=lambda *_: None, sleep=lambda _: None)
    out = b"".join(iter(lambda: reader.read(7_000), b""))
    assert out == data  # every byte exactly once, in order
    assert opened == [0, 30_000, 60_000, 90_000] and reader.reconnects == 3


def test_resumable_reader_gives_up():
    def open_at(offset):
        return io.BytesIO(b"")  # never delivers anything

    reader = _ResumableReader(open_at, total=10, max_reconnects=3, log=lambda *_: None, sleep=lambda _: None)
    with pytest.raises(OSError, match="stopped at byte 0 of 10 after 3 reconnects"):
        reader.read(5)


class _FakeResponse:
    def __init__(self, status, content_range):
        self.status, self.headers, self.closed = status, {"Content-Range": content_range}, False

    def close(self):
        self.closed = True


@pytest.mark.parametrize("status,content_range,ok", [
    (206, "bytes 1000-1999/2000", True),
    (200, "", False),                      # server ignored the Range request: resuming would corrupt the stream
    (206, "bytes 0-1999/2000", False),     # wrong start
])
def test_resume_only_when_server_confirms_offset(status, content_range, ok):
    resp = _FakeResponse(status, content_range)
    if ok:
        _check_resumed(resp, 1000)
    else:
        with pytest.raises(OSError, match="cannot resume"):
            _check_resumed(resp, 1000)
        assert resp.closed


def test_environment_report(tmp_path):
    info = environment_report(tmp_path)
    assert info["logical_cpus"] >= 1 and info["disk_free_gib"] >= 0
