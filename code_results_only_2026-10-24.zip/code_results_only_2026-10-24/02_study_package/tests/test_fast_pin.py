"""Phase 8: fast Pin-GTSVM checks against the exact solver (hazypark, CVXOPT) on small problems (CPU, seconds)."""

import os

import numpy as np
import pytest

torch = pytest.importorskip("torch")
hazypark = pytest.importorskip("hazypark.pin_gtsvm")

from vitpin.fast_pin import (  # noqa: E402
    OvOFast,
    OvOModel,
    class_landmarks,
    median_distance,
    pairs_of,
    predict_ovo,
    predict_pair,
    rbf,
    solve_box_qp_ipm,
)

T = torch.from_numpy


def blobs(k=3, n=30, d=6, sep=1.5, seed=0, n_test=0):
    """k overlapping Gaussian classes with n training rows each (noisy, so the box constraints are active); with
    ``n_test`` also a test set drawn around the same class centres."""
    rng = np.random.default_rng(seed)
    centres = rng.normal(0, sep, (k, d))
    X = np.vstack([centres[i] + rng.normal(0, 1, (n, d)) for i in range(k)])
    if not n_test:
        return X, np.repeat(np.arange(k), n)
    Xt = np.vstack([centres[i] + rng.normal(0, 1, (n_test, d)) for i in range(k)])
    return X, np.repeat(np.arange(k), n), Xt, np.repeat(np.arange(k), n_test)


def K_all(Xe, model: OvOFast):
    k, m_c, d = model.L.shape
    return rbf(T(Xe), model.L.reshape(k * m_c, d), model.sigma).numpy()


@pytest.mark.parametrize("c,tau", [(0.5, 0.0), (1.0, 0.5), (8.0, 1.0), (0.125, 0.1), (32.0, 1.0)])
def test_all_rows_as_landmarks_equals_exact_solver(c, tau):
    """m_c = "all": the basis of a pair is all its training rows, i.e. the exact method — same surfaces, same predictions."""
    X, y, Xt, _ = blobs(k=2, n=25, n_test=40)
    sigma = median_distance(X)
    A, B = X[y == 0], X[y == 1]
    exact = hazypark.PinGTSVM(c1=c, c2=c, tau=tau, kernel="rbf", sigma=sigma, eps=0.05,
                              qp_options={"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10}).fit(
        np.vstack([A, B]), np.r_[np.ones(len(A)), -np.ones(len(B))])
    model = OvOFast(X, y, class_landmarks(y, np.zeros_like(y), "all"), sigma)
    surf = model.fit([(c, tau)], tol=1e-11)[(c, tau)]
    assert all(i.converged for i in surf.solve)
    np.testing.assert_allclose(surf.W_i[0], exact.w1_, rtol=1e-4, atol=1e-6 * np.abs(exact.w1_).max())
    np.testing.assert_allclose(surf.b_i[0], exact.b1_, rtol=1e-4, atol=1e-6)
    # surface of class -1: same zero set, opposite orientation (the distance uses |.|)
    np.testing.assert_allclose(-surf.W_j[0], exact.w2_, rtol=1e-4, atol=1e-6 * np.abs(exact.w2_).max())
    np.testing.assert_allclose([surf.norm_i[0], surf.norm_j[0]], [exact.norm1_, exact.norm2_], rtol=1e-4)
    fast = predict_pair(K_all(Xt, model), surf, model.m_c, 0, 1)
    assert np.array_equal(np.where(fast == 0, 1, -1), exact.predict(Xt))


@pytest.mark.parametrize("tau", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("c", [0.125, 2.0, 32.0])
def test_ipm_reaches_the_cvxopt_optimum(c, tau):
    rng = np.random.default_rng(14)
    Z = rng.normal(0, 1, (3, 15, 60)) / 3
    x, info = solve_box_qp_ipm(T(Z), c, tau, tol=1e-10)
    assert info.converged and info.iterations < 80
    for p in range(3):
        Q = Z[p].T @ Z[p]
        ref, _ = hazypark.solve_box_qp(Q, c, tau, {"abstol": 1e-11, "reltol": 1e-11, "feastol": 1e-11})
        f = lambda v: 0.5 * v @ Q @ v - v.sum()  # noqa: E731
        assert f(x[p].numpy()) <= f(ref) + 1e-8 * max(1.0, abs(f(ref)))
        assert x[p].min() >= -tau * c - 1e-12 and x[p].max() <= c + 1e-12


def test_solution_satisfies_optimality_conditions():
    Z = T(np.random.default_rng(4).normal(0, 1, (2, 10, 30)))
    c, tau = 1.5, 0.5
    x, info = solve_box_qp_ipm(Z, c, tau, tol=1e-11)
    assert info.converged
    g = (Z.transpose(1, 2) @ (Z @ x[:, :, None]))[:, :, 0] - 1
    at_lo, at_hi = x <= -tau * c + 1e-7, x >= c - 1e-7
    interior = ~(at_lo | at_hi)
    assert (g[at_lo] >= -1e-6).all() and (g[at_hi] <= 1e-6).all() and (g[interior].abs() <= 1e-6).all()


def test_batched_pairs_equal_single_pairs_and_voting():
    X, y, Xt, yt = blobs(k=4, n=20, seed=5, n_test=15)
    lm = class_landmarks(y, np.zeros_like(y), 6)
    model = OvOFast(X, y, lm, median_distance(X))
    together = model.fit([(1.0, 0.5)], batch=4)[(1.0, 0.5)]
    alone = model.fit([(1.0, 0.5)], batch=1)[(1.0, 0.5)]
    np.testing.assert_allclose(together.W_i, alone.W_i, rtol=1e-6, atol=1e-9)
    np.testing.assert_allclose(together.W_j, alone.W_j, rtol=1e-6, atol=1e-9)
    K = K_all(Xt, model)
    assert (predict_ovo(K, together, model.m_c, 4) == yt).mean() > 0.5  # far above chance (0.25)
    sub = model.fit([(1.0, 0.5)], pairs=[(1, 3)])[(1.0, 0.5)]
    assert np.array_equal(predict_pair(K, sub, model.m_c, 1, 3), predict_pair(K, together, model.m_c, 1, 3))
    with pytest.raises(KeyError):
        sub.row(0, 1)


def test_several_settings_in_one_fit_equal_separate_fits():
    X, y = blobs(k=3, n=20, seed=9)
    model = OvOFast(X, y, class_landmarks(y, np.zeros_like(y), 5), median_distance(X))
    grid = model.fit([(0.25, 0.0), (4.0, 0.5)])
    for s in grid:
        np.testing.assert_allclose(grid[s].W_i, model.fit([s])[s].W_i, rtol=1e-8, atol=1e-12)


def test_per_class_landmarks_beat_shared_ones_at_equal_cost():
    """The design reason: a pair's basis made of its own classes approximates the exact pair model better than the
    same number of landmarks spread over all classes."""
    X, y, Xt, yt = blobs(k=6, n=40, d=8, sep=1.0, seed=21, n_test=30)
    sigma = median_distance(X) / 2
    exact = OvOFast(X, y, class_landmarks(y, np.zeros_like(y), "all"), sigma)
    s_exact = exact.fit([(1.0, 0.5)])[(1.0, 0.5)]
    own = OvOFast(X, y, class_landmarks(y, np.zeros_like(y), 4, seed=1), sigma)  # 8 own-class landmarks per pair
    s_own = own.fit([(1.0, 0.5)])[(1.0, 0.5)]
    agree = []
    for i, j in pairs_of(6):
        mask = (yt == i) | (yt == j)
        ref = predict_pair(K_all(Xt[mask], exact), s_exact, exact.m_c, i, j)
        agree.append((predict_pair(K_all(Xt[mask], own), s_own, own.m_c, i, j) == ref).mean())
    assert np.mean(agree) > 0.85


def test_model_save_load_predicts_the_same(tmp_path):
    X, y, Xt, _ = blobs(k=3, n=20, seed=10, n_test=5)
    model = OvOFast(X, y, class_landmarks(y, np.zeros_like(y), 4), median_distance(X))
    art = OvOModel(model.landmark_table(), model.sigma, model.fit([(1.0, 0.5)])[(1.0, 0.5)], np.array(["a", "b", "c"]))
    art.save(tmp_path / "m.npz")
    back = OvOModel.load(tmp_path / "m.npz")
    assert np.array_equal(art.predict(Xt), back.predict(Xt))
    with pytest.raises(ValueError):
        art.predict(Xt[:, :3])
    with pytest.raises(ValueError):
        art.predict(np.full_like(Xt, np.nan))


def test_class_landmarks():
    y = np.repeat(np.arange(20), 75)
    corruption = np.tile(np.repeat(np.arange(15), 5), 20)
    for m_c in (5, 15, 50):
        lm = class_landmarks(y, corruption, m_c, seed=1)
        assert lm.shape == (20, m_c) and len(np.unique(lm)) == 20 * m_c
        for k in range(20):
            assert (y[lm[k]] == k).all()
            sub = np.bincount(corruption[lm[k]], minlength=15)
            assert sub.max() - sub.min() <= 1  # spread over corruptions
    assert np.array_equal(class_landmarks(y, corruption, 15, seed=1), class_landmarks(y, corruption, 15, seed=1))
    assert not np.array_equal(class_landmarks(y, corruption, 15, seed=1), class_landmarks(y, corruption, 15, seed=2))
    assert class_landmarks(y, corruption, "all").shape == (20, 75)
    for bad in (0, 76, "some"):
        with pytest.raises(ValueError):
            class_landmarks(y, corruption, bad)


def test_median_distance():
    X = np.array([[0.0, 0], [3, 4], [6, 8]])  # distances 5, 10, 5
    assert median_distance(X) == 5.0
    with pytest.raises(ValueError):
        median_distance(np.zeros((3, 2)))


def test_input_validation():
    X, y = blobs(k=2, n=10)
    with pytest.raises(ValueError):
        solve_box_qp_ipm(T(np.ones((1, 2, 3))), 0.0, 0.5)
    with pytest.raises(ValueError):
        solve_box_qp_ipm(T(np.ones((1, 2, 3))), 1.0, 1.5)
    with pytest.raises(ValueError):
        rbf(T(X), T(X), -1.0)
    with pytest.raises(ValueError):  # unequal class sizes cannot be batched
        OvOFast(X[:-1], y[:-1], np.zeros((2, 1), dtype=int), 1.0)
    with pytest.raises(ValueError):
        OvOFast(np.full_like(X, np.nan), y, class_landmarks(y, np.zeros_like(y), 2), 1.0)


@pytest.mark.skipif(not (os.environ.get("KAGGLE_KERNEL_RUN_TYPE") and torch.cuda.is_available()),
                    reason="GPU tests run on Kaggle only (never on the user's PC)")
def test_gpu_equals_cpu():
    X, y = blobs(k=4, n=50, d=32, seed=12)
    lm = class_landmarks(y, np.zeros_like(y), 10)
    cpu = OvOFast(X, y, lm, median_distance(X)).fit([(2.0, 0.5)])[(2.0, 0.5)]
    gpu = OvOFast(X, y, lm, median_distance(X), device="cuda").fit([(2.0, 0.5)])[(2.0, 0.5)]
    np.testing.assert_allclose(gpu.W_i, cpu.W_i, rtol=1e-6, atol=1e-9)
