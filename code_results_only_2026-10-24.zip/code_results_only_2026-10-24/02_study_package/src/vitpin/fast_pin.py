"""Phase 8: fast Pin-GTSVM — reduced RBF kernel with per-class landmarks, low-rank interior-point solver, one-vs-one,
batched over class pairs (torch; float64 on GPU or CPU).

Model for the pair (i, j). Basis L_ij = the landmarks of class i followed by those of class j (2 m_c rows); the exact
method uses every training row of the two classes as its basis, the reduced kernel uses a subset (Lee & Mangasarian
2001). With m_c = all training rows of each class this IS the exact method of ``hazypark.pin_gtsvm`` (tested).

    H_i = [K(X_i, L_ij), e],   C_i = H_i' H_i + eps I = R_i R_i'          (Cholesky)
    surface of class i:  min_l 1/2 l' Q l - e' l,  -tau c <= l <= c,   Q = Z' Z,  Z = R_i^-1 H_j'
                         [w; b] = -R_i'^-1 (Z l)
    surface of class j:  the same with i and j swapped
    x goes to the class whose surface is nearer: |K(x, L_ij) w + b| / sqrt(w' K(L_ij, L_ij) w); ties go to i
    (as the exact port sends ties to class +1). c1 = c2 = c.

Solver: primal-dual interior point (Mehrotra predictor-corrector, as CVXOPT) on the dual box QP. Each Newton system
(Q + D) dx = rhs is solved with the Woodbury identity through one Cholesky of size 2 m_c + 1, so an iteration costs
O(n r^2) instead of O(n^3). The problem is rescaled to the unit box (l = c mu) so the regularisation cap below means the
same for every c. Phase 8 benchmark (Kaggle CPU, 2026-10-18): 13-29 iterations; FISTA needed 6-15x more time for the
same predictions and was removed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

_ZERO_NORM = 1e-12


def _torch():
    import torch

    return torch


# ---------------------------------------------------------------- inputs: kernel width and landmarks
def median_distance(X: np.ndarray, max_rows: int = 2000, seed: int = 0) -> float:
    """Median Euclidean distance between distinct rows (on a seeded sample of at most ``max_rows`` rows)."""
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2 or len(X) < 2 or not np.isfinite(X).all():
        raise ValueError("X must be a finite 2-D array with at least 2 rows")
    if len(X) > max_rows:
        X = X[np.sort(np.random.default_rng(seed).choice(len(X), max_rows, replace=False))]
    sq = np.einsum("ij,ij->i", X, X)
    d2 = sq[:, None] + sq[None, :] - 2.0 * X @ X.T
    d = np.sqrt(np.maximum(d2[np.triu_indices(len(X), k=1)], 0.0))
    med = float(np.median(d))
    if med <= 0:
        raise ValueError("median distance is 0 (duplicate rows?)")
    return med


def class_landmarks(y: np.ndarray, groups: np.ndarray, m_c, seed: int = 0) -> np.ndarray:
    """(k, m_c) row indices: for every class, ``m_c`` training rows spread round-robin over ``groups`` (e.g. corruption
    types), random within a group, seeded. ``m_c="all"``: every row of each class (the exact method)."""
    y, groups = np.asarray(y), np.asarray(groups)
    if y.shape != groups.shape or y.ndim != 1:
        raise ValueError("y and groups must be 1-D arrays of the same length")
    k = int(y.max()) + 1
    rows = [np.flatnonzero(y == c) for c in range(k)]
    if any(len(r) == 0 for r in rows) or len({len(r) for r in rows}) != 1:
        raise ValueError("every class 0..k-1 needs the same (non-zero) number of rows")
    if isinstance(m_c, str):
        if m_c != "all":
            raise ValueError(f"m_c must be a positive int or 'all', got {m_c!r}")
        return np.stack(rows)
    if not 0 < m_c <= len(rows[0]):
        raise ValueError(f"m_c must lie in [1, {len(rows[0])}], got {m_c}")
    rng = np.random.default_rng(seed)
    out = []
    for r in rows:
        pools = [rng.permutation(r[groups[r] == g]).tolist() for g in rng.permutation(np.unique(groups[r]))]
        take = []
        while len(take) < m_c:
            for p in pools:
                if p and len(take) < m_c:
                    take.append(p.pop())
        out.append(np.sort(take))
    return np.stack(out)


def rbf(X, Y, sigma: float):
    """exp(-||x - y||^2 / (2 sigma^2)) for torch tensors; batched when X is (B, n, d) and Y is (B, r, d)."""
    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError(f"sigma must be a positive finite number, got {sigma!r}")
    torch = _torch()
    sq = (X * X).sum(-1)[..., :, None] + (Y * Y).sum(-1)[..., None, :] - 2.0 * X @ Y.transpose(-1, -2)
    return torch.exp(-sq.clamp_min(0.0) / (2.0 * sigma**2))


# ---------------------------------------------------------------- solver
@dataclass
class SolveInfo:
    iterations: int
    max_residual: float  # projected-gradient residual of the returned solution
    converged: bool
    stalled: bool = False  # stopped because it made no progress (exact_torch batched solver)
    mu: float = float("nan")  # final complementarity of the last attempt (exact_torch batched solver)


def solve_box_qp_ipm(Z, c: float, tau: float, tol: float = 1e-8, max_iter: int = 200):
    """min 1/2 ||Z_p x_p||^2 - sum(x_p)  s.t. -tau c <= x_p <= c, for every problem p of the batch Z (P, r, n).

    Primal-dual interior point (Mehrotra predictor-corrector) with Woodbury solves of size r. Solved on the unit box
    (x = c mu, Z -> sqrt(c) Z). Converged when the dual residual max|Qmu - 1 - z_lo + z_hi| <= tol (1 + max|Qmu|) and
    the mean complementarity <= tol. D^-1 is capped at 1e9 (primal regularisation, Altman & Gondzio 1999) so the
    Cholesky stays stable near convergence; the stopping test uses the exact residuals. Use float64.
    """
    torch = _torch()
    if not (np.isfinite(c) and c > 0):
        raise ValueError(f"c must be positive, got {c!r}")
    if not 0.0 <= tau <= 1.0:
        raise ValueError(f"tau must lie in [0, 1], got {tau!r}")
    P, r, n = Z.shape
    Z = Z * np.sqrt(c)
    lo, hi = -tau, 1.0
    Zt = Z.transpose(1, 2)
    eye = torch.eye(r, dtype=Z.dtype, device=Z.device)
    x = torch.full((P, n), (lo + hi) / 2, dtype=Z.dtype, device=Z.device)
    zl, zu = torch.ones_like(x), torch.ones_like(x)
    active = torch.ones(P, 1, dtype=torch.bool, device=Z.device)

    def Qmul(v):
        return (Zt @ (Z @ v[:, :, None]))[:, :, 0]

    def max_step(v, dv):  # largest a <= 1 with v + a dv >= 0, per problem
        ratio = torch.where(dv < 0, -v / dv, torch.full_like(v, np.inf))
        return ratio.amin(1, keepdim=True).clamp(max=1.0)

    it = 0
    for it in range(1, max_iter + 1):
        sl, su = x - lo, hi - x
        Qx = Qmul(x)
        rd = Qx - 1.0 - zl + zu
        mu = (sl * zl + su * zu).sum(1, keepdim=True) / (2 * n)
        done = (rd.abs().amax(1, keepdim=True) <= tol * (1.0 + Qx.abs().amax(1, keepdim=True))) & (mu <= tol)
        active &= ~done
        if not bool(active.any()):
            break
        Dinv = (1.0 / (zl / sl + zu / su)).clamp(max=1e9)
        chol = torch.linalg.cholesky(eye + (Z * Dinv[:, None, :]) @ Zt)

        def newton(cl, cu):
            rhs = -rd + cl / sl - zl - cu / su + zu
            t = Dinv * rhs
            u = torch.cholesky_solve(Z @ t[:, :, None], chol)
            dx = t - Dinv * (Zt @ u)[:, :, 0]
            return dx, cl / sl - zl - (zl / sl) * dx, cu / su - zu + (zu / su) * dx

        def step(dx, dzl, dzu):
            return torch.minimum(torch.minimum(max_step(sl, dx), max_step(su, -dx)),
                                 torch.minimum(max_step(zl, dzl), max_step(zu, dzu)))

        zero = torch.zeros_like(x)
        dxa, dzla, dzua = newton(zero, zero)  # predictor (affine scaling)
        a = step(dxa, dzla, dzua)
        mu_aff = ((sl + a * dxa) * (zl + a * dzla) + (su - a * dxa) * (zu + a * dzua)).sum(1, keepdim=True) / (2 * n)
        sm = (mu_aff / mu).clamp(0.0, 1.0) ** 3 * mu
        dx, dzl, dzu = newton(sm - dxa * dzla, sm + dxa * dzua)  # corrector
        a = (0.995 * step(dx, dzl, dzu)).clamp(max=1.0) * active
        x, zl, zu = x + a * dx, zl + a * dzl, zu + a * dzu
    x = x.clamp(lo, hi)
    g = Qmul(x) - 1.0
    res = (x - (x - g).clamp(lo, hi)).abs().amax(1)
    return x * c, SolveInfo(it, float(res.max()), not bool(active.any()))


# ---------------------------------------------------------------- one-vs-one model
def pairs_of(k: int) -> list[tuple[int, int]]:
    return [(i, j) for i in range(k) for j in range(i + 1, k)]


@dataclass
class Surfaces:
    """Both surfaces of every fitted pair for one (sigma, c, tau). Row p belongs to pairs[p] = (i, j); the basis of
    pair (i, j) is landmarks[i] followed by landmarks[j] (so W has 2 m_c columns)."""

    pairs: np.ndarray  # (P, 2)
    W_i: np.ndarray  # (P, 2 m_c) surface of class i
    b_i: np.ndarray
    norm_i: np.ndarray
    W_j: np.ndarray  # surface of class j
    b_j: np.ndarray
    norm_j: np.ndarray
    c: float
    tau: float
    solve: list = field(default_factory=list)  # SolveInfo per batch

    def row(self, i: int, j: int) -> int:
        hit = np.flatnonzero((self.pairs[:, 0] == i) & (self.pairs[:, 1] == j))
        if not len(hit):
            raise KeyError(f"pair ({i}, {j}) was not fitted")
        return int(hit[0])


class OvOFast:
    """Per-class landmark Pin-GTSVM for one class set and one sigma. ``X`` training rows, ``y`` class indices
    0..k-1 (equal counts), ``landmarks`` (k, m_c) row indices from ``class_landmarks``."""

    def __init__(self, X: np.ndarray, y: np.ndarray, landmarks: np.ndarray, sigma: float, eps: float = 0.05,
                 device: str = "cpu"):
        torch = _torch()
        if not (np.isfinite(eps) and eps > 0):
            raise ValueError(f"eps must be positive, got {eps!r}")
        if not (np.isfinite(sigma) and sigma > 0):
            raise ValueError(f"sigma must be positive, got {sigma!r}")
        X = np.asarray(X, dtype=np.float64)
        if X.ndim != 2 or not np.isfinite(X).all():
            raise ValueError("X must be a finite 2-D array")
        y = np.asarray(y)
        self.k = int(y.max()) + 1
        rows = [np.flatnonzero(y == c) for c in range(self.k)]
        if any(len(r) == 0 for r in rows) or len({len(r) for r in rows}) != 1:
            raise ValueError("every class 0..k-1 needs the same (non-zero) number of rows")
        if landmarks.shape[0] != self.k:
            raise ValueError("landmarks must have one row of indices per class")
        self.sigma, self.eps, self.device = float(sigma), float(eps), device
        self.Xc = torch.from_numpy(np.stack([X[r] for r in rows])).to(device)  # (k, n_c, d)
        self.L = torch.from_numpy(X[landmarks]).to(device)  # (k, m_c, d)
        self.m_c = landmarks.shape[1]

    def _build(self, batch_pairs):
        """Z (2B, r, n) for the surfaces [class i of each pair..., class j of each pair...] and the pieces to recover w."""
        torch = _torch()
        I = torch.as_tensor([p[0] for p in batch_pairs], device=self.device)
        J = torch.as_tensor([p[1] for p in batch_pairs], device=self.device)
        basis = torch.cat([self.L[I], self.L[J]], 1)  # (B, 2 m_c, d)
        ones = torch.ones(len(batch_pairs), self.Xc.shape[1], 1, dtype=basis.dtype, device=self.device)
        Hi = torch.cat([rbf(self.Xc[I], basis, self.sigma), ones], 2)  # (B, n, r)
        Hj = torch.cat([rbf(self.Xc[J], basis, self.sigma), ones], 2)
        H = torch.cat([Hi, Hj])  # proximal class of each surface
        O = torch.cat([Hj, Hi])  # opposite class
        C = H.transpose(1, 2) @ H
        C.diagonal(dim1=1, dim2=2).add_(self.eps)
        R = torch.linalg.cholesky(C)
        Z = torch.linalg.solve_triangular(R, O.transpose(1, 2), upper=False)
        return Z, R, rbf(basis, basis, self.sigma)

    def fit(self, settings, pairs=None, batch: int = 16, tol: float = 1e-8, max_iter: int = 200) -> dict:
        """{(c, tau): Surfaces} for every setting; each batch of pairs is built once and solved for all settings."""
        torch = _torch()
        settings = [(float(c), float(t)) for c, t in settings]
        chosen = pairs_of(self.k) if pairs is None else [tuple(p) for p in pairs]
        parts = {s: {"W_i": [], "b_i": [], "n_i": [], "W_j": [], "b_j": [], "n_j": [], "solve": []} for s in settings}
        for start in range(0, len(chosen), batch):
            bp = chosen[start:start + batch]
            B = len(bp)
            Z, R, KLL = self._build(bp)
            K2 = torch.cat([KLL, KLL])
            for c, tau in settings:
                lam, info = solve_box_qp_ipm(Z, c, tau, tol=tol, max_iter=max_iter)
                u = -torch.linalg.solve_triangular(R.transpose(1, 2), Z @ lam[:, :, None], upper=True)[:, :, 0]
                w, b = u[:, :-1], u[:, -1]
                norm = torch.sqrt(((w[:, None, :] @ K2 @ w[:, :, None])[:, 0, 0]).clamp_min(0.0))
                p = parts[(c, tau)]
                for key, val in (("W_i", w[:B]), ("b_i", b[:B]), ("n_i", norm[:B]), ("W_j", w[B:]), ("b_j", b[B:]),
                                 ("n_j", norm[B:])):
                    p[key].append(val.cpu().numpy())
                p["solve"].append(info)
        out = {}
        for (c, tau), p in parts.items():
            out[(c, tau)] = Surfaces(np.asarray(chosen), *(np.concatenate(p[k]) for k in ("W_i", "b_i", "n_i")),
                                     *(np.concatenate(p[k]) for k in ("W_j", "b_j", "n_j")), c, tau, p["solve"])
        return out

    def landmark_table(self) -> np.ndarray:
        return self.L.cpu().numpy()


def _dist(K, w, b, norm):
    raw = np.abs(K @ w + b)
    return np.full_like(raw, np.inf) if norm < _ZERO_NORM else raw / norm


def pair_kernel(K_all: np.ndarray, m_c: int, i: int, j: int) -> np.ndarray:
    """Columns of K(X, all landmarks) (landmarks stored class by class) that form the basis of pair (i, j)."""
    return np.concatenate([K_all[:, i * m_c:(i + 1) * m_c], K_all[:, j * m_c:(j + 1) * m_c]], 1)


def predict_pair(K_all: np.ndarray, surf: Surfaces, m_c: int, i: int, j: int) -> np.ndarray:
    """Binary prediction for the pair (i, j): i where its surface is nearer or equally near, else j."""
    p = surf.row(i, j)
    K = pair_kernel(K_all, m_c, i, j)
    di = _dist(K, surf.W_i[p], surf.b_i[p], surf.norm_i[p])
    dj = _dist(K, surf.W_j[p], surf.b_j[p], surf.norm_j[p])
    return np.where(di <= dj, i, j)


def predict_ovo(K_all: np.ndarray, surf: Surfaces, m_c: int, k: int) -> np.ndarray:
    """One-vs-one voting over all pairs. Ties in votes go to the class with the larger summed margin (d_other - d_own),
    then to the lower class index."""
    n = len(K_all)
    votes, margin = np.zeros((n, k)), np.zeros((n, k))
    for i, j in pairs_of(k):
        p = surf.row(i, j)
        K = pair_kernel(K_all, m_c, i, j)
        di = _dist(K, surf.W_i[p], surf.b_i[p], surf.norm_i[p])
        dj = _dist(K, surf.W_j[p], surf.b_j[p], surf.norm_j[p])
        win = di <= dj
        votes[:, i] += win
        votes[:, j] += ~win
        with np.errstate(invalid="ignore"):
            gap = np.nan_to_num(dj - di, nan=0.0, posinf=1e6, neginf=-1e6)
        margin[:, i] += gap
        margin[:, j] -= gap
    best = votes == votes.max(1, keepdims=True)
    return np.argmax(np.where(best, margin, -np.inf), axis=1)


# ---------------------------------------------------------------- deployable artifact
@dataclass
class OvOModel:
    """What an edge device needs besides the ViT: the landmarks (class by class), sigma, the surfaces and class names
    (plain arrays; no solver needed)."""

    landmarks: np.ndarray  # (k, m_c, d)
    sigma: float
    surfaces: Surfaces
    classes: np.ndarray

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        k, m_c, d = self.landmarks.shape
        if X.ndim != 2 or X.shape[1] != d or not np.isfinite(X).all():
            raise ValueError(f"X must be finite with shape (n, {d})")
        torch = _torch()
        K = rbf(torch.from_numpy(X), torch.from_numpy(self.landmarks.reshape(k * m_c, d).astype(np.float64)),
                self.sigma).numpy()
        return self.classes[predict_ovo(K, self.surfaces, m_c, k)]

    def save(self, path: str | Path) -> None:
        s = self.surfaces
        np.savez(path, landmarks=self.landmarks, sigma=self.sigma, pairs=s.pairs, W_i=s.W_i, b_i=s.b_i,
                 norm_i=s.norm_i, W_j=s.W_j, b_j=s.b_j, norm_j=s.norm_j, c=s.c, tau=s.tau, classes=self.classes)

    @classmethod
    def load(cls, path: str | Path) -> "OvOModel":
        with np.load(path, allow_pickle=False) as z:
            s = Surfaces(z["pairs"], z["W_i"], z["b_i"], z["norm_i"], z["W_j"], z["b_j"], z["norm_j"], float(z["c"]),
                         float(z["tau"]))
            return cls(z["landmarks"], float(z["sigma"]), s, z["classes"])
