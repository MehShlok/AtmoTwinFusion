"""The paper's exact Pin-GTSVM (full RBF kernel on a pair's training rows) in torch, for a GPU — Phase 8 checks v4/v5.

Same mathematics as ``hazypark.pin_gtsvm`` (the corrected port; CVXOPT): for the pair (i, j), A = rows of class i
(label +1), B = rows of class j, D = [A; B], H = [K(A, D), e], G = [K(B, D), e];
    plane 1:  C1 = H'H + eps I = R1'R1,  Z1 = R1^-T G',  Q1 = Z1'Z1 (= G C1^-1 G'),  [w1; b1] = -R1^-1 (Z1 lam)
    plane 2:  C2 = G'G + eps I = R2'R2,  Z2 = R2^-T H',  Q2 = Z2'Z2 (= H C2^-1 H'),  [w2; b2] = +R2^-1 (Z2 gam)
    min 1/2 x'Qx - e'x  s.t.  -tau c <= x <= c   (dense primal-dual interior point, Mehrotra, as CVXOPT)
    x -> class i if |K(x, D) w1 + b1| / sqrt(w1'K(D, D)w1) <= the same for plane 2 (ties to i, as the port).

Precision modes (a T4 computes float64 ~30x slower than float32; C = H'H + eps I has condition ~1e8):
    "fp64"   : R by Cholesky of C in float64, interior point in float64 — the CVXOPT mathematics (tested equal);
    "fp32qr" : R from a float32 QR of [H; sqrt(eps) I] (never forms H'H, so R is the exact factor of a nearby positive
               definite matrix), interior point in float32 (at most 30 iterations); if it has not converged, the
               QP is solved again in float64 (a warm start from a float32 iterate stuck at the boundary is unreliable).
Check v4 showed that forming H'H in float32 is not positive definite (rounding ~0.3 > eps = 0.05) and that a float32
interior point stops short of the tolerance for most problems — hence the QR build and the float64 finish. Check v5
(Kaggle T4) validated fp32qr: 99.998 % of predictions identical to CVXOPT for both checked models.

Batched solving (``solve_box_qp_batch``, used by ``exact_fit_predict`` when batch > 1): one interior point advances P
problems (pairs x planes x (c, tau) settings) together — one batched Cholesky per iteration instead of P separate
Python loops — with per-problem step lengths, convergence and freezing; same iterates as the single solver.
"""

from __future__ import annotations

import time

import numpy as np

from .fast_pin import SolveInfo, pairs_of, rbf

PRECISIONS = {"fp64": ("float64", "cholesky"), "fp32qr": ("float32", "qr")}
TOL = {"float64": 1e-8, "float32": 1e-5}


def _torch():
    import torch

    return torch


def _ipm(Qc, x, zl, zu, lo, hi, tol, max_iter):
    """Mehrotra predictor-corrector iterations on the unit box from (x, zl, zu). Returns (x, zl, zu, iterations,
    converged); stops early, keeping the last finite iterate, when the precision of Qc's dtype is exhausted."""
    torch = _torch()
    n = Qc.shape[0]
    scale = float(Qc.diagonal().abs().max()) + 1.0
    floor0 = (1e-12 if Qc.dtype == torch.float64 else 1e-6) * scale  # primal regularisation (Altman & Gondzio 1999)
    dmax = (1e20 if Qc.dtype == torch.float64 else 1e10) * scale  # a variable pinned at a bound: d -> inf otherwise
    it = 0
    for it in range(1, max_iter + 1):
        sl, su = (x - lo).clamp_min(1e-30), (hi - x).clamp_min(1e-30)
        Qx = Qc @ x
        rd = Qx - 1.0 - zl + zu
        mu = float((sl * zl + su * zu).sum() / (2 * n))
        if float(rd.abs().max()) <= tol * (1.0 + float(Qx.abs().max())) and mu <= tol:
            return x, zl, zu, it, True
        if not mu > 0.0:  # complementarity exhausted at this precision (or not finite)
            break
        d = torch.nan_to_num(zl / sl + zu / su, nan=dmax, posinf=dmax).clamp(max=dmax)
        floor = floor0
        for _ in range(6):
            M = Qc.clone()
            M.diagonal().add_(d.clamp(min=floor))
            L, info = torch.linalg.cholesky_ex(M)
            if int(info) == 0:
                break
            floor *= 100.0
        else:
            break  # Newton matrix not positive definite at this precision: stop here

        def newton(cl, cu):
            rhs = -rd + cl / sl - zl - cu / su + zu
            dx = torch.cholesky_solve(rhs[:, None], L)[:, 0]
            return dx, cl / sl - zl - (zl / sl) * dx, cu / su - zu + (zu / su) * dx

        def max_step(v, dv):  # largest a <= 1 with v + a dv >= 0
            neg = dv < 0
            return min(1.0, float((-v[neg] / dv[neg]).min())) if bool(neg.any()) else 1.0

        def step(dx, dzl, dzu):
            return min(max_step(sl, dx), max_step(su, -dx), max_step(zl, dzl), max_step(zu, dzu))

        zero = torch.zeros_like(x)
        dxa, dzla, dzua = newton(zero, zero)  # predictor (affine scaling)
        a = step(dxa, dzla, dzua)
        mu_aff = float(((sl + a * dxa) * (zl + a * dzla) + (su - a * dxa) * (zu + a * dzua)).sum() / (2 * n))
        sm = min(max(mu_aff / mu, 0.0), 1.0) ** 3 * mu
        dx, dzl, dzu = newton(sm - dxa * dzla, sm + dxa * dzua)  # corrector
        a = min(0.995 * step(dx, dzl, dzu), 1.0)
        nx, nzl, nzu = x + a * dx, zl + a * dzl, zu + a * dzu
        if not (bool(torch.isfinite(nx).all()) and bool(torch.isfinite(nzl).all()) and bool(torch.isfinite(nzu).all())):
            break
        x, zl, zu = nx, nzl, nzu
    return x, zl, zu, it, False


def solve_box_qp_dense(Q, c: float, tau: float, tol: float | None = None, max_iter: int = 100, finish_dtype=None,
                       first_iter: int = 30):
    """min 1/2 x'Qx - e'x  s.t.  -tau c <= x <= c for one dense symmetric PSD ``Q`` (n, n) — primal-dual interior point
    (Mehrotra) on the unit box (x = c mu, Q -> c Q), one Cholesky of (cQ + diag(d)) per iteration, d floored and capped
    so a float32 run cannot crash. With ``finish_dtype`` (e.g. torch.float64) the iterations run in Q's dtype for at
    most ``first_iter`` steps; if they have not converged, the problem is solved again from the start in
    ``finish_dtype`` (a warm start from a float32 iterate stuck at the boundary does not converge reliably — tested).
    Returns (x in the final dtype, SolveInfo with the total iterations of both attempts)."""
    torch = _torch()
    if not (np.isfinite(c) and c > 0):
        raise ValueError(f"c must be positive, got {c!r}")
    if not 0.0 <= tau <= 1.0:
        raise ValueError(f"tau must lie in [0, 1], got {tau!r}")
    lo, hi = -tau, 1.0
    Qc = Q * c
    x = torch.full((Q.shape[0],), (lo + hi) / 2, dtype=Q.dtype, device=Q.device)
    zl, zu = torch.ones_like(x), torch.ones_like(x)
    first = max_iter if finish_dtype is None else min(first_iter, max_iter)
    tol0 = (TOL[str(Q.dtype).replace("torch.", "")] if tol is None else tol)
    x, zl, zu, it, converged = _ipm(Qc, x, zl, zu, lo, hi, tol0, first)
    if finish_dtype is not None and not converged and finish_dtype != Q.dtype:
        Qc = Qc.to(finish_dtype)
        x = torch.full((Q.shape[0],), (lo + hi) / 2, dtype=finish_dtype, device=Q.device)
        zl, zu = torch.ones_like(x), torch.ones_like(x)
        tol1 = TOL[str(finish_dtype).replace("torch.", "")] if tol is None else tol
        x, zl, zu, it2, converged = _ipm(Qc, x, zl, zu, lo, hi, tol1, max_iter)
        it += it2
    x = x.clamp(lo, hi)
    g = Qc @ x - 1.0
    res = float((x - (x - g).clamp(lo, hi)).abs().max())
    return x * c, SolveInfo(it, res, converged)


def _ipm_batch(Qs, which, c, lo, tol, max_iter, stall_iter: int = 10):
    """Batched Mehrotra iterations: problem p solves min 1/2 x'(c_p Q_{which_p})x - e'x on [lo_p, 1] (unit box).

    Only unsolved problems are worked on: the batch shrinks as problems converge, stall (merit max(residual, mu) not
    10 % better than its best for ``stall_iter`` iterations) or fail (Newton matrix indefinite after regularisation,
    or a non-finite step), so one hard problem never keeps the others' factorisations running (check v6).
    Returns (x (P, n), converged (P,), iterations (P,), stalled (P,), final mu (P,))."""
    torch = _torch()
    P, n = len(which), Qs.shape[-1]
    dev, dt = Qs.device, Qs.dtype
    x = ((lo + 1.0) / 2)[:, None].expand(P, n).clone()
    zl, zu = torch.ones_like(x), torch.ones_like(x)
    conv = torch.zeros(P, dtype=torch.bool, device=dev)
    stalled = torch.zeros_like(conv)
    iters = torch.zeros(P, dtype=torch.long, device=dev)
    mu_last = torch.full((P,), float("nan"), dtype=dt, device=dev)
    best = torch.full((P,), float("inf"), dtype=dt, device=dev)
    since = torch.zeros(P, dtype=torch.long, device=dev)
    inf = torch.tensor(float("inf"), dtype=dt, device=dev)
    act = torch.arange(P, device=dev)  # the unsolved problems
    Qc = Qs[which] * c[:, None, None]  # rows follow act
    scale = Qc.diagonal(dim1=1, dim2=2).abs().amax(1) + 1.0
    floor0 = (1e-12 if dt == torch.float64 else 1e-6) * scale
    dmax = (1e20 if dt == torch.float64 else 1e10) * scale

    def max_step(v, dv):  # per problem: largest a <= 1 with v + a dv >= 0
        return torch.where(dv < 0, -v / dv, inf).amin(1).clamp(max=1.0)

    for _ in range(max_iter):
        xa, zla, zua, loa = x[act], zl[act], zu[act], lo[act][:, None]
        sl, su = (xa - loa).clamp_min(1e-30), (1.0 - xa).clamp_min(1e-30)
        Qx = torch.bmm(Qc, xa[:, :, None])[:, :, 0]
        rd = Qx - 1.0 - zla + zua
        mu = (sl * zla + su * zua).sum(1) / (2 * n)
        rres = rd.abs().amax(1) / (1.0 + Qx.abs().amax(1))
        mu_last[act] = mu
        done = (rres <= tol) & (mu <= tol)
        merit = torch.maximum(rres, mu)
        improved = merit < 0.9 * best[act]
        best[act] = torch.where(improved, merit, best[act])
        since[act] = torch.where(improved, torch.zeros_like(since[act]), since[act] + 1)
        stuck = (since[act] >= stall_iter) & ~done
        conv[act] = conv[act] | done
        stalled[act] = stalled[act] | stuck
        keep = ~done & ~stuck & (mu > 0)
        if not bool(keep.all()):  # shrink the batch to the unsolved problems
            act, Qc, scale, floor0, dmax = act[keep], Qc[keep], scale[keep], floor0[keep], dmax[keep]
            xa, zla, zua, loa, sl, su, rd, mu = (v[keep] for v in (xa, zla, zua, loa, sl, su, rd, mu))
        if len(act) == 0:
            break
        iters[act] += 1
        d = zla / sl + zua / su
        d = torch.where(torch.isfinite(d), d, dmax[:, None]).clamp(max=dmax[:, None])
        floor = floor0.clone()
        for _ in range(6):
            M = Qc.clone()
            M.diagonal(dim1=1, dim2=2).add_(torch.maximum(d, floor[:, None]))
            L, info = torch.linalg.cholesky_ex(M)
            failed = info > 0
            if not bool(failed.any()):
                break
            floor = torch.where(failed, floor * 100.0, floor)
        del M

        def newton(cl, cu):
            rhs = -rd + cl / sl - zla - cu / su + zua
            dx = torch.cholesky_solve(rhs[:, :, None], L)[:, :, 0]
            return dx, cl / sl - zla - (zla / sl) * dx, cu / su - zua + (zua / su) * dx

        def step(dx, dzl, dzu):
            return torch.minimum(torch.minimum(max_step(sl, dx), max_step(su, -dx)),
                                 torch.minimum(max_step(zla, dzl), max_step(zua, dzu)))

        zero = torch.zeros_like(xa)
        dxa, dzla, dzua = newton(zero, zero)  # predictor (affine scaling)
        a = step(dxa, dzla, dzua)[:, None]
        mu_aff = ((sl + a * dxa) * (zla + a * dzla) + (su - a * dxa) * (zua + a * dzua)).sum(1) / (2 * n)
        sm = ((mu_aff / mu.clamp_min(1e-300)).clamp(0.0, 1.0) ** 3 * mu)[:, None]
        dx, dzl, dzu = newton(sm - dxa * dzla, sm + dxa * dzua)  # corrector
        a = (0.995 * step(dx, dzl, dzu)).clamp(max=1.0)[:, None]
        nx, nzl, nzu = xa + a * dx, zla + a * dzl, zua + a * dzu
        ok = (info == 0) & torch.isfinite(nx).all(1) & torch.isfinite(nzl).all(1) & torch.isfinite(nzu).all(1)
        upd = act[ok]
        x[upd], zl[upd], zu[upd] = nx[ok], nzl[ok], nzu[ok]
        if not bool(ok.all()):  # failed at this precision: freeze at the last finite iterate
            act, Qc, scale, floor0, dmax = act[ok], Qc[ok], scale[ok], floor0[ok], dmax[ok]
    return torch.maximum(x, lo[:, None]).clamp(max=1.0), conv, iters, stalled, mu_last


def solve_box_qp_batch(Qs, which, cs, taus, tol: float | None = None, max_iter: int = 100, finish_dtype=None,
                       first_iter: int = 30, finish_iter: int = 60):
    """Problem p: min 1/2 x'Q x - e'x s.t. -tau_p c_p <= x <= c_p with Q = Qs[which[p]] (Qs: (B, n, n)), all P solved
    together. With ``finish_dtype`` the problems not converged after ``first_iter`` iterations in Qs' dtype are solved
    again from the start in ``finish_dtype`` (at most ``finish_iter`` iterations). Returns (X (P, n) in the final dtype,
    [SolveInfo] per problem, with ``stalled`` and the final ``mu``)."""
    torch = _torch()
    cs = torch.as_tensor(cs, dtype=Qs.dtype, device=Qs.device)
    taus = torch.as_tensor(taus, dtype=Qs.dtype, device=Qs.device)
    which = torch.as_tensor(which, dtype=torch.long, device=Qs.device)
    if not (bool(torch.isfinite(cs).all()) and bool((cs > 0).all())):
        raise ValueError("every c must be positive and finite")
    if not bool(((taus >= 0) & (taus <= 1)).all()):
        raise ValueError("every tau must lie in [0, 1]")
    tol0 = TOL[str(Qs.dtype).replace("torch.", "")] if tol is None else tol
    first = max_iter if finish_dtype is None else min(first_iter, max_iter)
    x, conv, iters, stalled, mu = _ipm_batch(Qs, which, cs, -taus, tol0, first)
    out_dtype, Qf = Qs.dtype, Qs
    if finish_dtype is not None and finish_dtype != Qs.dtype:
        out_dtype = finish_dtype
        x, mu = x.to(finish_dtype), mu.to(finish_dtype)
        redo = torch.nonzero(~conv).flatten()
        if len(redo):
            Qf = Qs.to(finish_dtype)
            tol1 = TOL[str(finish_dtype).replace("torch.", "")] if tol is None else tol
            x2, conv2, it2, st2, mu2 = _ipm_batch(Qf, which[redo], cs[redo].to(finish_dtype),
                                                  -taus[redo].to(finish_dtype), tol1, finish_iter)
            x[redo], conv[redo], iters[redo], stalled[redo], mu[redo] = x2, conv2, iters[redo] + it2, st2, mu2
    csf, lof = cs.to(out_dtype)[:, None], -taus.to(out_dtype)[:, None]
    Qo = Qf.to(out_dtype)
    g = torch.stack([Qo[w] @ (x[p] * cs.to(out_dtype)[p]) for p, w in enumerate(which.tolist())]) - 1.0
    res = (x - torch.maximum(x - g, lof).clamp(max=1.0)).abs().amax(1)
    infos = [SolveInfo(int(i), float(r), bool(v), bool(st), float(m)) for i, r, v, st, m in
             zip(iters.tolist(), res.tolist(), conv.tolist(), stalled.tolist(), mu.tolist())]
    return x * csf, infos


def build_pair(A, B, sigma: float, eps: float, method: str = "cholesky"):
    """Both planes of the exact method for one pair, in the dtype of A and B. Returns {"R1", "Z1", "R2", "Z2", "D",
    "gram"} with C = R'R (R upper triangular) and Z = R^-T O' (see the module docstring)."""
    torch = _torch()
    if method not in ("cholesky", "qr"):
        raise ValueError(f"method must be 'cholesky' or 'qr', got {method!r}")
    D = torch.cat([A, B])
    KA, KB = rbf(A, D, sigma), rbf(B, D, sigma)
    H = torch.cat([KA, torch.ones(len(A), 1, dtype=A.dtype, device=A.device)], 1)
    G = torch.cat([KB, torch.ones(len(B), 1, dtype=B.dtype, device=B.device)], 1)
    r = H.shape[1]

    def factor(P):
        if method == "cholesky":
            C = P.T @ P
            C.diagonal().add_(eps)
            return torch.linalg.cholesky(C).T  # R = L'
        stacked = torch.cat([P, np.sqrt(eps) * torch.eye(r, dtype=P.dtype, device=P.device)])
        return torch.linalg.qr(stacked, mode="r").R  # R'R = P'P + eps I, without forming P'P

    def plane(P, O):
        R = factor(P)
        Z = torch.linalg.solve_triangular(R.T, O.T.contiguous(), upper=False)
        return R, Z

    R1, Z1 = plane(H, G)
    R2, Z2 = plane(G, H)
    return {"R1": R1, "Z1": Z1, "R2": R2, "Z2": Z2, "D": D, "gram": torch.cat([KA, KB])}


def _surface(R, Z, lam, sign):
    torch = _torch()
    return sign * torch.linalg.solve_triangular(R, (Z @ lam)[:, None], upper=True)[:, 0]


def _distance(K, wb, gram):
    w, b = wb[:-1], wb[-1]
    norm = float((w @ (gram @ w)).clamp_min(0.0).sqrt())
    raw = (K @ w + b).abs()
    return raw / norm if norm >= 1e-12 else raw.new_full(raw.shape, float("inf"))


def exact_fit_predict(data, sigma: float, settings, pairs=None, device: str = "cuda", precision: str = "fp64",
                      eps: float = 0.05, log=None, batch: int = 1, max_pairs: int = 4) -> dict:
    """The exact method for ``pairs`` (default: all) of one class set (``phase8.ClassSetData``) at every (c, tau) of
    ``settings``. Returns {"pred": {(c, tau): {(i, j): class indices of the pair's test rows}}, "seconds",
    "build_seconds", "solve_seconds", "solve": [SolveInfo], "solve_index": [(i, j, c, tau, plane)]} — the same "pred"
    layout as ``phase8.exact_reference``; "solve_index" names the QP behind each SolveInfo. ``batch`` > 1: up to ``batch`` QPs (pairs x 2 planes x settings) are solved together (``solve_box_qp_batch``), with
    at most ``max_pairs`` pairs held in memory at once (a float32 pair holds ~0.5 GB at 2 x 2,625 training rows)."""
    if batch > 1:
        return _exact_fit_predict_batched(data, sigma, settings, pairs, device, precision, eps, log, batch, max_pairs)
    torch = _torch()
    if precision not in PRECISIONS:
        raise ValueError(f"precision must be one of {sorted(PRECISIONS)}, got {precision!r}")
    dtype_name, method = PRECISIONS[precision]
    bdt = getattr(torch, dtype_name)
    finish = torch.float64 if bdt != torch.float64 else None
    sync = torch.cuda.synchronize if str(device).startswith("cuda") else (lambda: None)
    t0 = time.time()
    Xtr = torch.from_numpy(np.ascontiguousarray(data.Xtr)).to(device, bdt)
    Xte = torch.from_numpy(np.ascontiguousarray(data.Xte)).to(device, bdt)
    ytr, yte = data.ytr, data.yte
    chosen = pairs_of(int(ytr.max()) + 1) if pairs is None else [tuple(p) for p in pairs]
    pred, infos, index, t_build, t_solve = {s: {} for s in settings}, [], [], 0.0, 0.0
    for n, (i, j) in enumerate(chosen, 1):
        sync()
        tb = time.time()
        prob = build_pair(Xtr[torch.from_numpy(ytr == i)], Xtr[torch.from_numpy(ytr == j)], sigma, eps, method)
        Q1, Q2 = prob["Z1"].T @ prob["Z1"], prob["Z2"].T @ prob["Z2"]
        Ke = rbf(Xte[torch.from_numpy((yte == i) | (yte == j))], prob["D"], sigma)
        sync()
        ts = time.time()
        t_build += ts - tb
        for c, tau in settings:
            lam, info1 = solve_box_qp_dense(Q1, c, tau, finish_dtype=finish)
            gam, info2 = solve_box_qp_dense(Q2, c, tau, finish_dtype=finish)
            infos += [info1, info2]
            index += [(i, j, c, tau, 1), (i, j, c, tau, 2)]
            d1 = _distance(Ke, _surface(prob["R1"], prob["Z1"], lam.to(bdt), -1.0), prob["gram"])
            d2 = _distance(Ke, _surface(prob["R2"], prob["Z2"], gam.to(bdt), 1.0), prob["gram"])
            pred[(c, tau)][(i, j)] = np.where((d1 <= d2).cpu().numpy(), i, j)
        sync()
        t_solve += time.time() - ts
        del prob, Ke, Q1, Q2
        if log and (n % 10 == 0 or n == len(chosen)):
            log(f"{n}/{len(chosen)} pairs, {time.time() - t0:.0f} s (build {t_build:.0f} s, solve {t_solve:.0f} s)")
    return {"pred": pred, "seconds": time.time() - t0, "build_seconds": t_build, "solve_seconds": t_solve,
            "solve": infos, "solve_index": index}


def _exact_fit_predict_batched(data, sigma, settings, pairs, device, precision, eps, log, batch, max_pairs):
    torch = _torch()
    if precision not in PRECISIONS:
        raise ValueError(f"precision must be one of {sorted(PRECISIONS)}, got {precision!r}")
    dtype_name, method = PRECISIONS[precision]
    bdt = getattr(torch, dtype_name)
    finish = torch.float64 if bdt != torch.float64 else None
    sync = torch.cuda.synchronize if str(device).startswith("cuda") else (lambda: None)
    t0 = time.time()
    Xtr = torch.from_numpy(np.ascontiguousarray(data.Xtr)).to(device, bdt)
    Xte = torch.from_numpy(np.ascontiguousarray(data.Xte)).to(device, bdt)
    ytr, yte = data.ytr, data.yte
    chosen = pairs_of(int(ytr.max()) + 1) if pairs is None else [tuple(p) for p in pairs]
    settings = list(settings)
    per_pair = 2 * len(settings)
    chunk = max(1, min(max_pairs, batch // per_pair))  # pairs per batched solve
    pred, infos, index, t_build, t_solve, done = {s: {} for s in settings}, [], [], 0.0, 0.0, 0
    for start in range(0, len(chosen), chunk):
        group = chosen[start:start + chunk]
        sync()
        tb = time.time()
        probs, Qs = [], []
        for i, j in group:
            prob = build_pair(Xtr[torch.from_numpy(ytr == i)], Xtr[torch.from_numpy(ytr == j)], sigma, eps, method)
            prob["Ke"] = rbf(Xte[torch.from_numpy((yte == i) | (yte == j))], prob["D"], sigma)
            Qs += [prob["Z1"].T @ prob["Z1"], prob["Z2"].T @ prob["Z2"]]
            probs.append(prob)
        sizes = {q.shape for q in Qs}
        sync()
        ts = time.time()
        t_build += ts - tb
        # problem list: (pair index in group, plane 0/1, setting index); planes of equal size are solved together
        X = {}
        for shape in sizes:
            members = [(g, pl, k) for g in range(len(group)) for pl in (0, 1) for k in range(len(settings))
                       if Qs[2 * g + pl].shape == shape]
            stack_ids = sorted({2 * g + pl for g, pl, _ in members})
            stack = torch.stack([Qs[q] for q in stack_ids])
            pos = {q: t for t, q in enumerate(stack_ids)}
            for b in range(0, len(members), batch):
                part = members[b:b + batch]
                xs, inf_ = solve_box_qp_batch(stack, [pos[2 * g + pl] for g, pl, _ in part],
                                              [settings[k][0] for _, _, k in part], [settings[k][1] for _, _, k in part],
                                              finish_dtype=finish)
                for m, (g, pl, k) in enumerate(part):
                    X[(g, pl, k)] = (xs[m], inf_[m])
            del stack
        for g, (i, j) in enumerate(group):
            prob = probs[g]
            for k, s in enumerate(settings):
                (lam, info1), (gam, info2) = X[(g, 0, k)], X[(g, 1, k)]
                infos += [info1, info2]
                index += [(i, j, s[0], s[1], 1), (i, j, s[0], s[1], 2)]
                d1 = _distance(prob["Ke"], _surface(prob["R1"], prob["Z1"], lam.to(bdt), -1.0), prob["gram"])
                d2 = _distance(prob["Ke"], _surface(prob["R2"], prob["Z2"], gam.to(bdt), 1.0), prob["gram"])
                pred[s][(i, j)] = np.where((d1 <= d2).cpu().numpy(), i, j)
        sync()
        t_solve += time.time() - ts
        del probs, Qs, X
        prev, done = done, done + len(group)
        if log and (done // 10 > prev // 10 or done == len(chosen)):
            log(f"{done}/{len(chosen)} pairs, {time.time() - t0:.0f} s (build {t_build:.0f} s, solve {t_solve:.0f} s)")
    return {"pred": pred, "seconds": time.time() - t0, "build_seconds": t_build, "solve_seconds": t_solve,
            "solve": infos, "solve_index": index}
