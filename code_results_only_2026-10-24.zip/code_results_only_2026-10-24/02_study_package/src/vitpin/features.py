"""Phase 7: frozen-backbone feature extraction for the 7 approved models, plus edge metrics.

Choices (docs/research_vits.md, Documentation/15):
* Input 224 x 224 with no resize or crop: ImageNet-C images are stored at 224 x 224, and the usual resize+centre-crop
  would cut image borders (DINOv2's default 518 px would upsample 5x for no new information).
* Normalisation: each model's own mean/std from its timm pretrained config.
* Two vectors per image: ``global`` = the CLS token where the model has one (as in the DINOv2/DINOv3 linear probes),
  otherwise the model's own pooled embedding (SigLIP 2 attention pooling, FastViT average pooling); ``patch_mean`` =
  mean of the patch tokens (prefix/register tokens excluded). For CNN-style feature maps (FastViT) the patch mean equals
  the pooled vector and is not stored twice.
* FastViT is used in its deployed (structurally reparameterised) form: the parallel training branches are folded into
  single convolutions. Same function (max difference ~1e-8 on random weights), fewer kernels, faster at batch 1.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

BACKBONES = {
    "dinov2_s14": "vit_small_patch14_dinov2.lvd142m",
    "dinov2_b14": "vit_base_patch14_dinov2.lvd142m",
    "dinov3_s16": "vit_small_patch16_dinov3.lvd1689m",
    "dinov3_b16": "vit_base_patch16_dinov3.lvd1689m",
    "siglip2_b16": "vit_base_patch16_siglip_224.v2_webli",
    "fastvit_sa12": "fastvit_sa12.apple_in1k",
    "fastvit_sa24": "fastvit_sa24.apple_in1k",
}
IMAGE_SIZE = 224


@dataclass
class Backbone:
    name: str
    timm_id: str
    model: object
    mean: tuple
    std: tuple
    has_cls: bool
    prefix_tokens: int


def create_backbone(name: str, pretrained: bool = True) -> Backbone:
    import timm

    if name not in BACKBONES:
        raise ValueError(f"unknown backbone {name!r}; choose from {sorted(BACKBONES)}")
    timm_id = BACKBONES[name]
    kwargs = {} if timm_id.startswith("fastvit") else {"img_size": IMAGE_SIZE}
    model = timm.create_model(timm_id, pretrained=pretrained, num_classes=0, **kwargs).eval()
    if timm_id.startswith("fastvit"):
        from timm.utils.model import reparameterize_model

        model = reparameterize_model(model)
    # Frozen backbone. Also required by torch's FlopCounterMode: weights that require grad crash it under
    # inference_mode (SigLIP 2 attention pooling; Phase 7 run v1 on Kaggle).
    model.requires_grad_(False)
    cfg = model.pretrained_cfg
    return Backbone(name, timm_id, model, tuple(cfg["mean"]), tuple(cfg["std"]),
                    getattr(model, "cls_token", None) is not None, int(getattr(model, "num_prefix_tokens", 0) or 0))


def embed(bb: Backbone, x):
    """Return (global, patch_mean or None) as float32 tensors for a normalised batch ``x``."""
    feats = bb.model.forward_features(x)
    if feats.ndim == 4:  # CNN-style map (FastViT): pooled embedding only
        return bb.model.forward_head(feats, pre_logits=True).float(), None
    patches = feats[:, bb.prefix_tokens:]
    glob = feats[:, 0] if bb.has_cls else bb.model.forward_head(feats, pre_logits=True)
    return glob.float(), patches.mean(dim=1).float()


def load_image(path: str | Path, mean, std):
    """Read an ImageNet-C JPEG as a normalised 3 x 224 x 224 tensor; other sizes are an error (none are expected)."""
    import torch
    from PIL import Image

    with Image.open(path) as img:
        img = img.convert("RGB")
        if img.size != (IMAGE_SIZE, IMAGE_SIZE):
            raise ValueError(f"{path}: expected {IMAGE_SIZE}x{IMAGE_SIZE}, got {img.size}")
        arr = np.asarray(img, dtype=np.float32) / 255.0
    t = torch.from_numpy(arr).permute(2, 0, 1)
    return (t - torch.tensor(mean).view(3, 1, 1)) / torch.tensor(std).view(3, 1, 1)


class _Images:
    """Map-style dataset at module level, so worker processes can receive it under any start method
    (spawn on Windows, forkserver on Linux from Python 3.14)."""

    def __init__(self, paths, mean, std):
        self.paths, self.mean, self.std = list(paths), mean, std

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        return load_image(self.paths[i], self.mean, self.std)


def _log(msg: str) -> None:
    print(msg, flush=True)  # flushed at once, so progress shows in Kaggle's live log


def extract(bb: Backbone, paths: list[str], device: str = "cuda", batch_size: int = 128, workers: int = 4,
            amp: bool = True, log=_log, max_seconds: float | None = None) -> dict[str, np.ndarray]:
    """Features for ``paths`` in the given order (= manifest order).

    ``max_seconds``: stop with ``TimeoutError`` once exceeded, so a stalled run fails fast instead of using GPU hours.
    """
    import torch
    from torch.utils.data import DataLoader

    loader = DataLoader(_Images(paths, bb.mean, bb.std), batch_size=batch_size, num_workers=workers, shuffle=False,
                        pin_memory=device.startswith("cuda"),
                        timeout=300 if workers else 0)  # no batch for 5 min = stalled input: fail, don't hang
    model = bb.model.to(device)
    out_g, out_p, done, t0 = [], [], 0, time.time()
    with torch.inference_mode(), torch.autocast(device_type=device.split(":")[0], dtype=torch.float16,
                                                enabled=amp and device.startswith("cuda")):
        for batch in loader:
            g, p = embed(bb, batch.to(device, non_blocking=True))
            out_g.append(g.cpu().numpy())
            if p is not None:
                out_p.append(p.cpu().numpy())
            done += len(batch)
            elapsed = time.time() - t0
            if done == len(batch) or done % (batch_size * 100) < batch_size or done == len(paths):
                log(f"{bb.name}: {done:,}/{len(paths):,} images, {done / elapsed:.0f} img/s, {elapsed:.0f} s")
            if max_seconds is not None and elapsed > max_seconds and done < len(paths):
                raise TimeoutError(f"{bb.name}: {done:,}/{len(paths):,} images after {elapsed:.0f} s "
                                   f"(limit {max_seconds:.0f} s) - stopped to save GPU time")
    result = {"global": np.concatenate(out_g).astype(np.float32)}
    if out_p:
        result["patch_mean"] = np.concatenate(out_p).astype(np.float32)
    for key, arr in result.items():
        if arr.shape[0] != len(paths) or not np.isfinite(arr).all():
            raise RuntimeError(f"{bb.name}/{key}: wrong shape {arr.shape} or non-finite values")
    return result


def edge_metrics(bb: Backbone, device: str = "cuda", gpu_repeats: int = 50, cpu_repeats: int = 20) -> dict:
    """Parameters, size, MACs (one 224 image) and batch-1 latency on GPU (fp16) and CPU (fp32)."""
    import torch
    from torch.utils.flop_counter import FlopCounterMode

    model = bb.model
    params = sum(p.numel() for p in model.parameters())
    x = torch.zeros(1, 3, IMAGE_SIZE, IMAGE_SIZE)
    model = model.to("cpu").float()
    with torch.inference_mode(), FlopCounterMode(display=False) as counter:
        embed(bb, x)
    out = {"backbone": bb.name, "timm_id": bb.timm_id, "params_m": round(params / 1e6, 2),
           "size_mb_fp32": round(params * 4 / 2**20, 1), "gmacs": round(counter.get_total_flops() / 2 / 1e9, 2)}

    def timed(dev, repeats, warmup, amp):
        m, xi = model.to(dev), x.to(dev)
        with torch.inference_mode(), torch.autocast(device_type=dev, dtype=torch.float16, enabled=amp):
            for _ in range(warmup):
                embed(bb, xi)
            if dev == "cuda":
                torch.cuda.synchronize()
            times = []
            for _ in range(repeats):
                t = time.perf_counter()
                embed(bb, xi)
                if dev == "cuda":
                    torch.cuda.synchronize()
                times.append((time.perf_counter() - t) * 1000)
        return round(float(np.median(times)), 2)

    out["cpu_ms_b1"] = timed("cpu", cpu_repeats, 3, False)
    out["cpu_threads"] = torch.get_num_threads()
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        out["gpu_ms_b1_fp16"] = timed("cuda", gpu_repeats, 10, True)
        out["gpu_peak_mb_b1"] = round(torch.cuda.max_memory_allocated() / 2**20, 1)
        out["gpu"] = torch.cuda.get_device_name(0)
    model.to("cpu")
    return out


def manifest_fingerprint(manifest: pd.DataFrame) -> str:
    """SHA-256 of the manifest content (path, split, fold) in row order — independent of CSV formatting."""
    import hashlib

    text = "\n".join(manifest.path + "|" + manifest.split + "|" + manifest.cv_fold.astype(str))
    return hashlib.sha256(text.encode()).hexdigest()


def sanity_accuracy(features: np.ndarray, manifest: pd.DataFrame, severity: int = 1) -> dict:
    """Logistic regression on train vs test images of one severity, per class set (catches a broken extractor)."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler

    out = {}
    for class_set, rows in manifest[manifest.severity == severity].groupby("class_set"):
        tr, te = rows[rows.split == "train"], rows[rows.split == "test"]
        scaler = StandardScaler().fit(features[tr.index])
        clf = LogisticRegression(max_iter=2000).fit(scaler.transform(features[tr.index]), tr.wnid)
        out[class_set] = round(float(clf.score(scaler.transform(features[te.index]), te.wnid)), 4)
    return out
