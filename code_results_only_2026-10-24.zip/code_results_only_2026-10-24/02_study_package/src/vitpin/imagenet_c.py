"""ImageNet-C indexing, integrity checks and the leakage-safe split (Phase 6).

Layout (official evaluation script and the Kaggle copy): ``<root>/<corruption>/<severity>/<wnid>/ILSVRC2012_val_<8 digits>.JPEG``.
Every class has the same 50 validation (source) images in all 15 x 5 corrupted versions, so train/test are split by
source image (docs/rulebook.md P1). The third-party Kaggle copy is compared byte-for-byte with the official Zenodo
archive (record 2235448, CC BY 4.0), whose MD5 is checked while streaming. Note: the official archives are
gzip-compressed despite the ``.tar`` name (first bytes ``1f 8b``, checked 2026-10-16), so they are opened with
automatic compression detection; the MD5 is computed on the bytes as downloaded, as Zenodo computes it.
"""

from __future__ import annotations

import hashlib
import http.client
import json
import os
import platform
import re
import shutil
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

from .class_sets import ClassSet

FAMILIES = {
    "noise": ("gaussian_noise", "shot_noise", "impulse_noise"),
    "blur": ("defocus_blur", "glass_blur", "motion_blur", "zoom_blur"),
    "weather": ("snow", "frost", "fog", "brightness"),
    "digital": ("contrast", "elastic_transform", "pixelate", "jpeg_compression"),
}
CORRUPTIONS = tuple(c for names in FAMILIES.values() for c in names)
FAMILY_OF = {c: f for f, names in FAMILIES.items() for c in names}
SEVERITIES = (1, 2, 3, 4, 5)
ZENODO_RECORD_API = "https://zenodo.org/api/records/2235448"
_SOURCE_NAME = re.compile(r"ILSVRC2012_val_(\d{8})\.JPEG")
MANIFEST_COLUMNS = ["path", "class_set", "wnid", "class_index", "corruption", "family", "severity", "source_id",
                    "split", "cv_fold"]


# ---------------------------------------------------------------- locating the data
def find_root(search_dir: str | Path, max_depth: int = 4) -> Path:
    """The unique folder below ``search_dir`` that contains all 15 corruption folders."""
    search_dir = Path(search_dir)
    found, frontier = [], [(search_dir, 0)]
    while frontier:
        folder, depth = frontier.pop()
        try:
            subdirs = {p.name: p for p in folder.iterdir() if p.is_dir()}
        except OSError:
            continue
        if all(c in subdirs for c in CORRUPTIONS):
            found.append(folder)
            continue
        if depth < max_depth:
            frontier.extend((p, depth + 1) for p in subdirs.values())
    if len(found) != 1:
        raise FileNotFoundError(f"expected exactly one ImageNet-C root under {search_dir}, found {[str(f) for f in found]}")
    return found[0]


# ---------------------------------------------------------------- manifest and split
def build_manifest(root: str | Path, class_sets: list[ClassSet], seed: int = 0, images_per_class: int = 50,
                   train_sources: int = 35, cv_folds: int = 5) -> pd.DataFrame:
    """One row per image of the given classes, with a 70/30 split and CV folds by source image.

    All problems are collected and raised together, so one run reports everything that is wrong.
    """
    root = Path(root)
    if not 0 < train_sources < images_per_class or train_sources % cv_folds:
        raise ValueError("train_sources must lie in (0, images_per_class) and be divisible by cv_folds")
    wnids = [w for cs in class_sets for w in cs.wnids]
    if len(set(wnids)) != len(wnids):
        raise ValueError("class sets overlap")
    problems, rows = [], []
    for cs in class_sets:
        for wnid, index in zip(cs.wnids, cs.indices):
            versions = {}
            for corruption in CORRUPTIONS:
                for severity in SEVERITIES:
                    folder = root / corruption / str(severity) / wnid
                    names = sorted(p.name for p in folder.iterdir()) if folder.is_dir() else []
                    bad = [n for n in names if not _SOURCE_NAME.fullmatch(n)]
                    if not names:
                        problems.append(f"missing folder {corruption}/{severity}/{wnid}")
                    elif len(names) != images_per_class or bad:
                        problems.append(f"{corruption}/{severity}/{wnid}: {len(names)} files, {len(bad)} unexpected names")
                    versions[(corruption, severity)] = names
            sources = sorted({n for names in versions.values() for n in names})
            if any(set(names) != set(sources) for names in versions.values() if names):
                problems.append(f"{wnid}: the corrupted versions do not share the same source images")
            if len(sources) != images_per_class:
                problems.append(f"{wnid}: {len(sources)} distinct source images, expected {images_per_class}")
                continue
            order = np.random.default_rng([seed, index]).permutation(len(sources))
            split_of = {}
            for rank, i in enumerate(order):
                name = sources[i]
                split_of[name] = ("train", rank % cv_folds + 1) if rank < train_sources else ("test", 0)
            for (corruption, severity), names in versions.items():
                for name in names:
                    split, fold = split_of[name]
                    rows.append((f"{corruption}/{severity}/{wnid}/{name}", cs.name, wnid, index, corruption,
                                 FAMILY_OF[corruption], severity, int(_SOURCE_NAME.fullmatch(name).group(1)), split, fold))
    if problems:
        shown = "\n  ".join(problems[:30])
        raise ValueError(f"{len(problems)} problem(s) in the ImageNet-C copy:\n  {shown}")
    return pd.DataFrame(rows, columns=MANIFEST_COLUMNS)


def check_split(manifest: pd.DataFrame, train_sources: int = 35, test_sources: int = 15, cv_folds: int = 5) -> dict:
    """Leakage test: no source image in two splits or two folds; exact per-class counts. Raises on failure."""
    per_source = manifest.groupby(["wnid", "source_id"]).agg(splits=("split", "nunique"), folds=("cv_fold", "nunique"))
    leaks = per_source[(per_source.splits != 1) | (per_source.folds != 1)]
    if len(leaks):
        raise AssertionError(f"{len(leaks)} source images appear in more than one split or fold")
    if manifest.groupby("source_id")["wnid"].nunique().max() != 1:
        raise AssertionError("a source image ID appears under two classes")
    counts = (manifest.drop_duplicates(["wnid", "source_id"]).groupby(["wnid", "split"]).size()
              .unstack(fill_value=0).reindex(columns=["train", "test"], fill_value=0))
    if not ((counts["train"] == train_sources).all() and (counts["test"] == test_sources).all()):
        raise AssertionError("per-class train/test source counts are wrong")
    train = manifest[manifest.split == "train"].drop_duplicates(["wnid", "source_id"])
    fold_sizes = train.groupby(["wnid", "cv_fold"]).size()
    if fold_sizes.nunique() != 1 or train.cv_fold.nunique() != cv_folds:
        raise AssertionError("CV folds are unbalanced")
    return {
        "images": int(len(manifest)),
        "classes": int(manifest.wnid.nunique()),
        "source_images": int(manifest.drop_duplicates(["wnid", "source_id"]).shape[0]),
        "train_images": int((manifest.split == "train").sum()),
        "test_images": int((manifest.split == "test").sum()),
        "per_class_sources": {"train": train_sources, "test": test_sources},
        "cv_folds": cv_folds,
        "leakage": "none",
    }


# ---------------------------------------------------------------- integrity vs the official archive
def sha256_file(path: str | Path, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while block := fh.read(chunk):
            digest.update(block)
    return digest.hexdigest()


class _ResumableReader:
    """Read a remote file of known size, reconnecting from the current byte offset if the connection drops.

    Phase 6 v2 on Kaggle failed with "unexpected end of data": the multi-GB Zenodo download was cut off mid-stream.
    ``open_at(offset)`` must return a file-like object positioned at ``offset``; every byte is delivered exactly once.
    """

    def __init__(self, open_at, total: int, max_reconnects: int = 30, progress_every: int = 1 << 29,
                 log=print, sleep=time.sleep):
        self.open_at, self.total, self.max_reconnects = open_at, total, max_reconnects
        self.progress_every, self.log, self.sleep = progress_every, log, sleep
        self.offset, self.reconnects, self.start = 0, 0, time.time()
        self._next_report = progress_every
        self.raw = open_at(0)

    def read(self, size=-1):
        while True:
            try:
                data = self.raw.read(size)
            except (http.client.IncompleteRead, http.client.HTTPException, OSError, urllib.error.URLError):
                data = b""
            if data:
                self.offset += len(data)
                if self.offset >= self._next_report:
                    self.log(f"downloaded {self.offset / 2**30:.2f} / {self.total / 2**30:.2f} GiB, "
                             f"{self.reconnects} reconnects, {time.time() - self.start:.0f} s")
                    self._next_report += self.progress_every
                return data
            if self.offset >= self.total:
                return b""  # genuine end of file
            self._reconnect()

    def _reconnect(self) -> None:
        self.reconnects += 1
        if self.reconnects > self.max_reconnects:
            raise OSError(f"download stopped at byte {self.offset:,} of {self.total:,} after {self.max_reconnects} reconnects")
        try:
            self.raw.close()
        except Exception:  # noqa: BLE001 - the connection is already broken
            pass
        self.sleep(min(60, 2 ** min(self.reconnects, 6)))
        self.log(f"connection dropped at byte {self.offset:,}; reconnect {self.reconnects}")
        self.raw = self.open_at(self.offset)

    def close(self) -> None:
        self.raw.close()


def _check_resumed(resp, offset: int) -> None:
    """A resumed request is only safe if the server really starts at ``offset`` (HTTP 206 + matching Content-Range)."""
    if offset == 0:
        return
    content_range = resp.headers.get("Content-Range", "")
    if resp.status != 206 or not content_range.startswith(f"bytes {offset}-"):
        resp.close()
        raise OSError(f"server cannot resume at byte {offset:,} (status {resp.status}, Content-Range {content_range!r})")


def _opener(url: str, timeout: int):
    """``open_at(offset)`` for http(s) (Range requests) and file:// URLs (tests)."""
    if url.startswith("file:"):
        path = urllib.request.url2pathname(urllib.parse.urlparse(url).path)

        def open_file(offset):
            fh = open(path, "rb")
            fh.seek(offset)
            return fh

        return open_file

    def open_http(offset):
        req = urllib.request.Request(url, headers={"Range": f"bytes={offset}-"} if offset else {})
        resp = urllib.request.urlopen(req, timeout=timeout)
        _check_resumed(resp, offset)
        return resp

    return open_http


class _HashingReader:
    """File-like wrapper that MD5-hashes and counts every byte read (for tarfile stream mode)."""

    def __init__(self, raw):
        self.raw, self.md5, self.bytes, self.head = raw, hashlib.md5(), 0, b""

    def read(self, size=-1):
        data = self.raw.read(size)
        self.md5.update(data)
        self.bytes += len(data)
        if len(self.head) < 16:
            self.head += data[: 16 - len(self.head)]  # kept for a readable error if the download is not an archive
        return data

    def drain(self, chunk: int = 1 << 22) -> None:
        while self.read(chunk):
            pass


def verify_against_zenodo(root: str | Path, wnids: set[str], archive: str = "blur",
                          record_api: str = ZENODO_RECORD_API, timeout: int = 120, images_per_class: int = 50,
                          log=print) -> dict:
    """Stream ``<archive>.tar`` from Zenodo, check its MD5/size, and compare every file of ``wnids`` byte-for-byte."""
    root = Path(root)
    with urllib.request.urlopen(record_api, timeout=timeout) as resp:
        record = json.load(resp)
    entry = next((f for f in record["files"] if f["key"] == f"{archive}.tar"), None)
    if entry is None:
        raise ValueError(f"{archive}.tar not found in the Zenodo record")
    algo, expected_md5 = entry["checksum"].split(":", 1)
    if algo != "md5":
        raise ValueError(f"unexpected checksum type {algo}")
    url = entry["links"].get("content") or entry["links"]["self"]
    start = time.time()
    matched, mismatched, missing, official = 0, [], [], defaultdict(int)
    download = _ResumableReader(_opener(url, timeout), total=int(entry["size"]), log=log)
    try:
        reader = _HashingReader(download)
        try:
            tar = tarfile.open(fileobj=reader, mode="r|*")  # "*": plain, gzip, bz2 or xz, detected from the stream
        except tarfile.ReadError as exc:
            raise ValueError(f"{archive}.tar is not a readable tar archive (first bytes: {reader.head.hex(' ')})") from exc
        with tar:
            for member in tar:
                if not member.isfile():
                    continue
                parts = Path(member.name.lstrip("./")).parts
                hit = [i for i, p in enumerate(parts) if p in CORRUPTIONS]
                if not hit or len(parts) < hit[0] + 4:
                    continue
                corruption, severity, wnid, name = parts[hit[0]: hit[0] + 4]
                if wnid not in wnids:
                    continue
                official[(corruption, severity, wnid)] += 1
                data = tar.extractfile(member).read()
                local = root / corruption / severity / wnid / name
                if not local.is_file():
                    missing.append(f"{corruption}/{severity}/{wnid}/{name}")
                elif hashlib.sha256(data).hexdigest() == sha256_file(local):
                    matched += 1
                else:
                    mismatched.append(f"{corruption}/{severity}/{wnid}/{name}")
        reader.drain()  # hash any trailing bytes so the MD5 covers the whole file
    finally:
        download.close()
    stream_md5 = reader.md5.hexdigest()
    expected_groups = len(FAMILIES[archive]) * len(SEVERITIES) * len(wnids) if archive in FAMILIES else None
    return {
        "archive": f"{archive}.tar",
        "zenodo_md5": expected_md5,
        "stream_md5": stream_md5,
        "md5_ok": stream_md5 == expected_md5,
        "bytes": reader.bytes,
        "size_ok": reader.bytes == entry["size"],
        "reconnects": download.reconnects,
        "official_files_compared": matched + len(mismatched) + len(missing),
        "matched": matched,
        "mismatched": len(mismatched),
        "missing_in_copy": len(missing),
        "examples_mismatched": mismatched[:20],
        "examples_missing": missing[:20],
        "official_groups": len(official),
        "expected_groups": expected_groups,
        "official_counts_ok": bool(official) and set(official.values()) == {images_per_class}
                              and (expected_groups is None or len(official) == expected_groups),
        "seconds": round(time.time() - start, 1),
    }


# ---------------------------------------------------------------- environment record
def environment_report(work_dir: str | Path = ".") -> dict:
    cpu = platform.processor()
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.is_file():  # Linux (Kaggle): platform.processor() is often empty
        cpu = next((ln.split(":", 1)[1].strip() for ln in cpuinfo.read_text().splitlines() if ln.startswith("model name")), cpu)
    info = {"python": platform.python_version(), "platform": platform.platform(), "cpu": cpu,
            "logical_cpus": os.cpu_count(), "numpy": np.__version__, "pandas": pd.__version__}
    if hasattr(os, "sysconf") and "SC_PHYS_PAGES" in os.sysconf_names:
        info["ram_gib"] = round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30, 1)
    usage = shutil.disk_usage(work_dir)
    info["disk_free_gib"] = round(usage.free / 2**30, 1)
    try:
        import torch

        info["torch"] = torch.__version__
        info["gpu"] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    except ImportError:
        info["torch"] = None
    return info
