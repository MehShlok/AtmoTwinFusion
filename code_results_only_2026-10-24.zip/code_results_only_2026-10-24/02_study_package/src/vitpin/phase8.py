"""Phase 8 accuracy gate on Kaggle (CPU, float64): is the fast per-class-landmark Pin-GTSVM close enough to the
exact method of the source paper?

Reference (check v3): the paper's method itself — Pin-GTSVM with the full RBF kernel on the pair's training rows, the
corrected dual (Tanveer et al. 2019), eps = 0.05 as in the original MATLAB code — solved by CVXOPT through ``hazypark``
(the Task 1 port), i.e. by code independent of the fast solver (``exact_reference``). ``fit_predict(..., "all")`` gives
the same predictions (tested) and was the GPU reference of check v2, which needed a P100 that Kaggle no longer offers.
Check (approved 2026-10-17): all 190 pairs of both class sets at sigma = median distance x {1/4, 1, 4} (c = 1,
tau = 0.5), plus 10 pairs per class set over the corner settings. Check v3 widens the corners to the extremes of the
paper's own grid (Sec. 5.9: c1 = c2 in {2^-5 ... 2^5}, tau in {0.5, 0.8, 1}) plus the hinge case tau = 0 (RQ2): c in
{2^-5, 2^-3, 1, 2^5} x tau in {0, 0.5, 0.8, 1} — stricter than approved, never looser. Landmarks per class are tried
in ascending order; the smallest passing size is kept. Gate: pooled over the checked predictions, >= 99 % identical
and |accuracy difference| <= 0.5 points, for both parts of the check.

Used by kaggle/notebooks/phase8_check_v3_<config>.ipynb; tested on tiny data in tests/test_phase8.py.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import pandas as pd

from .fast_pin import OvOFast, class_landmarks, median_distance, pairs_of, predict_ovo, predict_pair, rbf

SIGMA_MULTS = (0.25, 1.0, 4.0)
MAIN_SETTING = (1.0, 0.5)  # (c, tau) for the all-pairs check
CORNER_SETTINGS = tuple((c, tau) for c in (2.0 ** -5, 0.125, 1.0, 32.0) for tau in (0.0, 0.5, 0.8, 1.0))
LANDMARKS_PER_CLASS = (50, 150, 500)
GATE_AGREEMENT, GATE_ACC_POINTS = 0.99, 0.5
# Grid for screening and the main runs (approved by the user 2026-10-20): sigma = median training distance x
# SIGMA_MULTS_GRID; c in {2^-5, 2^-3, 2^-1, 2^1, 2^3, 2^5} (the paper's range, Sec. 5.9); tau in {0, 0.5, 0.8, 1} (the
# paper's tau values + the hinge case, RQ2); validation on 3 of the 5 predefined CV folds of the Phase 6 split.
SIGMA_MULTS_GRID = (0.25, 0.5, 1.0, 2.0, 4.0)
GRID_SETTINGS = tuple((c, tau) for c in (2.0 ** -5, 2.0 ** -3, 2.0 ** -1, 2.0, 8.0, 32.0) for tau in (0.0, 0.5, 0.8, 1.0))
GRID_CV_FOLDS = (1, 2, 3)
EPS = 0.05


@dataclass
class ClassSetData:
    name: str
    Xtr: np.ndarray
    ytr: np.ndarray  # class index 0..k-1
    groups_tr: np.ndarray  # corruption name per training row (landmark spreading)
    Xte: np.ndarray
    yte: np.ndarray
    wnids: list


def class_set_data(features: np.ndarray, manifest: pd.DataFrame, class_set: str) -> ClassSetData:
    """Rows of one class set, standardised with the training split's mean and std (test rows never used for it)."""
    rows = manifest[manifest.class_set == class_set]
    if rows.empty:
        raise ValueError(f"no rows for class set {class_set!r}")
    wnids = sorted(rows.wnid.unique())
    index = {w: k for k, w in enumerate(wnids)}
    tr, te = rows[rows.split == "train"], rows[rows.split == "test"]
    Xtr, Xte = features[tr.index].astype(np.float64), features[te.index].astype(np.float64)
    mean, std = Xtr.mean(0), Xtr.std(0)
    std[std < 1e-12] = 1.0
    return ClassSetData(class_set, (Xtr - mean) / std, tr.wnid.map(index).to_numpy(), tr.corruption.to_numpy(),
                        (Xte - mean) / std, te.wnid.map(index).to_numpy(), wnids)


def fold_data(features: np.ndarray, manifest: pd.DataFrame, class_set: str, fold: int) -> ClassSetData:
    """Cross-validation view of one class set: "train" = training-split rows outside predefined CV fold,
    "test" = training-split rows in it (the test split is never touched). Standardised with the fold's training rows.
    Folds group whole source images (Phase 6 split), so no source image is on both sides."""
    rows = manifest[(manifest.class_set == class_set) & (manifest.split == "train")]
    if rows.empty:
        raise ValueError(f"no training rows for class set {class_set!r}")
    if fold not in set(rows.cv_fold.unique()):
        raise ValueError(f"fold {fold!r} is not a CV fold of the training split")
    view = rows.assign(split=np.where(rows.cv_fold == fold, "test", "train"))
    return class_set_data(features, view, class_set)


def tuning_pairs(k: int = 20, n_pairs: int = 20, seed: int = 2) -> list:
    """The seeded sample of class pairs on which the shared hyperparameters are tuned (approved 2026-10-21: 20 pairs
    per class set instead of all 190)."""
    all_pairs = pairs_of(k)
    return [all_pairs[t] for t in np.sort(np.random.default_rng(seed).choice(len(all_pairs), n_pairs, replace=False))]


def median_sigma(data: ClassSetData) -> float:
    return median_distance(data.Xtr, max_rows=2000, seed=0)


def fit_predict(data: ClassSetData, sigma: float, m_c, settings, pairs=None, device: str = "cpu", batch: int = 16,
                seed: int = 0) -> dict:
    """Fit the per-class-landmark model (``m_c`` landmarks per class, or "all" = exact) for ``pairs`` (default: all)
    and predict each pair's test rows. Returns {"pred": {(c, tau): {(i, j): predictions}}, "ovo_acc": {(c, tau):
    k-class accuracy, only when all pairs are fitted}, "seconds", "solver": {(c, tau): [SolveInfo]}}."""
    import torch

    t0 = time.time()
    lm = class_landmarks(data.ytr, data.groups_tr, m_c, seed)
    model = OvOFast(data.Xtr, data.ytr, lm, sigma, eps=EPS, device=device)
    surfaces = model.fit(settings, pairs=pairs, batch=batch)
    k, mc, d = model.L.shape
    K = rbf(torch.from_numpy(data.Xte).to(device), model.L.reshape(k * mc, d), sigma).cpu().numpy()
    chosen = pairs_of(k) if pairs is None else [tuple(p) for p in pairs]
    res = {"pred": {}, "ovo_acc": {}, "solver": {}}
    for s, surf in surfaces.items():
        res["solver"][s] = surf.solve
        res["pred"][s] = {(i, j): predict_pair(K[(data.yte == i) | (data.yte == j)], surf, mc, i, j) for i, j in chosen}
        if pairs is None:
            res["ovo_acc"][s] = float((predict_ovo(K, surf, mc, k) == data.yte).mean())
    res["seconds"] = time.time() - t0
    return res


def exact_reference(data: ClassSetData, sigma: float, settings, pairs=None, log=None, qp_options=None) -> dict:
    """The paper's exact method for ``pairs`` (default: all), via ``hazypark`` (CVXOPT, full kernel on the pair's
    training rows, class i = +1; same steps as ``hazypark.PinGTSVM.fit/predict``, one kernel build shared by all
    ``settings``). Returns {"pred": {(c, tau): {(i, j): class indices of the pair's test rows}}, "seconds",
    "not_optimal": number of QPs CVXOPT did not report optimal}."""
    from hazypark.pin_gtsvm import build_twin_problems, rbf_kernel, solve_box_qp, surface_distance, surface_norm

    t0 = time.time()
    chosen = pairs_of(int(data.ytr.max()) + 1) if pairs is None else [tuple(p) for p in pairs]
    pred, not_optimal = {s: {} for s in settings}, 0
    for n, (i, j) in enumerate(chosen, 1):
        A, B = data.Xtr[data.ytr == i], data.Xtr[data.ytr == j]
        problems = build_twin_problems(A, B, "rbf", sigma, EPS)
        K = rbf_kernel(data.Xte[(data.yte == i) | (data.yte == j)], problems.basis, sigma)
        for c, tau in settings:
            lam, st1 = solve_box_qp(problems.plane1.Q, c, tau, qp_options)
            gam, st2 = solve_box_qp(problems.plane2.Q, c, tau, qp_options)
            not_optimal += (st1 != "optimal") + (st2 != "optimal")
            u, v = problems.plane1.recover @ lam, problems.plane2.recover @ gam
            d1 = surface_distance(K, u[:-1], u[-1], surface_norm(u[:-1], problems.gram))
            d2 = surface_distance(K, v[:-1], v[-1], surface_norm(v[:-1], problems.gram))
            pred[(c, tau)][(i, j)] = np.where(d1 <= d2, i, j)
        if log and (n % 10 == 0 or n == len(chosen)):
            log(f"{n}/{len(chosen)} pairs, {time.time() - t0:.0f} s")
    return {"pred": pred, "seconds": time.time() - t0, "not_optimal": int(not_optimal)}


def compare(data: ClassSetData, reference: dict, fast: dict, labels: dict) -> pd.DataFrame:
    """One row per (setting, pair): test rows, identical predictions, correct (fast), correct (reference)."""
    rows = []
    for (c, tau), by_pair in reference.items():
        for (i, j), p_ref in by_pair.items():
            truth = data.yte[(data.yte == i) | (data.yte == j)]
            p_fast = fast[(c, tau)][(i, j)]
            rows.append({**labels, "c": c, "tau": tau, "i": i, "j": j, "n_test": len(truth),
                         "agree": int((p_fast == p_ref).sum()), "correct_fast": int((p_fast == truth).sum()),
                         "correct_exact": int((p_ref == truth).sum())})
    return pd.DataFrame(rows)


def gate(comparisons: pd.DataFrame) -> dict:
    """Pooled agreement and accuracy difference (points) with pass/fail against the approved thresholds."""
    n = int(comparisons.n_test.sum()) if len(comparisons) else 0
    if n == 0:
        return {"n_test": 0, "passed": False}
    agreement = comparisons.agree.sum() / n
    diff = 100.0 * (comparisons.correct_fast.sum() - comparisons.correct_exact.sum()) / n
    worst = comparisons.assign(a=comparisons.agree / comparisons.n_test).sort_values("a").iloc[0]
    return {"n_test": n, "pairs_checked": int(len(comparisons)), "agreement": round(float(agreement), 5),
            "accuracy_fast": round(float(comparisons.correct_fast.sum() / n), 5),
            "accuracy_exact": round(float(comparisons.correct_exact.sum() / n), 5),
            "accuracy_diff_points": round(float(diff), 3),
            "worst_pair_agreement": round(float(worst.a), 4), "worst_pair": [int(worst.i), int(worst.j)],
            "passed": bool(agreement >= GATE_AGREEMENT and abs(diff) <= GATE_ACC_POINTS)}


def load_reference(path) -> dict:
    """Inverse of ``predictions_table`` for a saved ``reference_*.npz``: {(c, tau): {(i, j): class indices}}."""
    out = {}
    with np.load(path) as z:
        for key in z.files:
            c, tau, pair = key.split("|")
            i, j = (int(v) for v in pair.split("-"))
            out.setdefault((float(c[2:]), float(tau[4:])), {})[(i, j)] = z[key].astype(np.int64)
    if not out:
        raise ValueError(f"{path}: no predictions")
    return out


def predictions_table(pred: dict) -> dict:
    """Flatten {(c, tau): {(i, j): array}} into npz-ready {"c=..|tau=..|i-j": array} (int8 class indices)."""
    return {f"c={c}|tau={tau}|{i}-{j}": p.astype(np.int8) for (c, tau), by_pair in pred.items()
            for (i, j), p in by_pair.items()}
