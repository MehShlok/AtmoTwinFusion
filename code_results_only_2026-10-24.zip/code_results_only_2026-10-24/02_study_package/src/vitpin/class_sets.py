"""Load and validate the study's class sets (JSON files written offline by ``study/scripts/select_classes.py``)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

CLASS_SET_DIR = Path(__file__).resolve().parents[2] / "configs" / "class_sets"
_WNID = re.compile(r"n\d{8}")


@dataclass(frozen=True)
class ClassSet:
    name: str
    wnids: tuple[str, ...]  # ImageNet WordNet IDs, in ImageNet index order (also the ImageNet-C folder names)
    indices: tuple[int, ...]  # ImageNet-1k class indices (0-999)
    names: tuple[str, ...]

    def __len__(self) -> int:
        return len(self.wnids)


def load_class_set(name_or_path: str | Path) -> ClassSet:
    """Load ``similar20`` / ``dissimilar20`` by name, or any class-set JSON by path."""
    path = Path(name_or_path)
    if path.suffix != ".json":
        path = CLASS_SET_DIR / f"{name_or_path}.json"
    if not path.is_file():
        raise FileNotFoundError(f"class-set file not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    classes = data.get("classes")
    if not isinstance(classes, list) or not classes:
        raise ValueError(f"{path}: 'classes' must be a non-empty list")
    wnids = tuple(c["wnid"] for c in classes)
    indices = tuple(int(c["index"]) for c in classes)
    names = tuple(str(c["name"]) for c in classes)
    if not all(_WNID.fullmatch(w) for w in wnids):
        raise ValueError(f"{path}: malformed WordNet ID")
    if len(set(wnids)) != len(wnids) or len(set(indices)) != len(indices):
        raise ValueError(f"{path}: duplicate classes")
    if not all(0 <= i < 1000 for i in indices):
        raise ValueError(f"{path}: ImageNet-1k index out of range")
    if list(indices) != sorted(indices):
        raise ValueError(f"{path}: classes must be listed in ImageNet index order")
    return ClassSet(str(data.get("name", path.stem)), wnids, indices, names)
