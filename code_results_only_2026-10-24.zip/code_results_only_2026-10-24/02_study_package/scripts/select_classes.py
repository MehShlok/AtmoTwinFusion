"""Select the two 20-class ImageNet subsets used in the study (offline tool; not needed at run time).

Similar-20   : WordNet 3.0. Among the most specific nodes holding >= 20 ImageNet-1k classes, take the node whose 20
               most mutually similar classes have the highest mean Wu-Palmer similarity (greedy: repeatedly drop the
               class least similar to the rest). Wu-Palmer uses the deepest shared ancestor (longest path from the
               root). nltk's wup_similarity picks a shallower ancestor when a synset has several parents ('dog' is
               both 'canine' and 'domestic_animal'), which ranks two terriers below go-kart vs. trailer truck.
Dissimilar-20: BREEDS hierarchy (Santurkar, Tsipras & Madry, ICLR 2021: ImageNet regrouped by visual similarity).
               Farthest-first traversal (Gonzalez 1985) on 1 - Wu-Palmer similarity, excluding the BREEDS group that
               contains Similar-20, with no two classes sharing a BREEDS level-4 node.
Ties are broken by WordNet ID, so the output is deterministic.

Setup (once): pip install nltk; python -c "import nltk; nltk.download('wordnet', download_dir=r'D:\\ResearchPaper2\\.cache\\nltk_data')"
              and set NLTK_DATA to that folder. Source lists are downloaded into --cache on first use.

    python study/scripts/select_classes.py           # write study/configs/class_sets/*.json (never overwrites)
    python study/scripts/select_classes.py --check   # regenerate and compare with the saved files
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.request
from collections import deque
from itertools import combinations
from pathlib import Path

import numpy as np

K = 20
LEVEL = 4
TIMM_INFO = "https://raw.githubusercontent.com/huggingface/pytorch-image-models/main/timm/data/_info/"
BREEDS_URL = "https://raw.githubusercontent.com/MadryLab/BREEDS-Benchmarks/master/imagenet_class_hierarchy/modified/"
OUT_DIR = Path(__file__).resolve().parents[1] / "configs" / "class_sets"


# ---------------------------------------------------------------- inputs
def fetch(url: str, path: Path) -> str:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(url, timeout=60) as resp:
            data = resp.read()
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
    return path.read_text(encoding="utf-8")


def load_imagenet(cache: Path) -> tuple[list[str], dict[str, str]]:
    wnids = fetch(TIMM_INFO + "imagenet_synsets.txt", cache / "imagenet_meta" / "imagenet_synsets.txt").split()
    if len(wnids) != 1000 or len(set(wnids)) != 1000 or wnids != sorted(wnids):
        raise ValueError("expected the 1000 ImageNet-1k WordNet IDs in sorted (index) order")
    if not all(re.fullmatch(r"n\d{8}", w) for w in wnids):
        raise ValueError("malformed WordNet ID in the ImageNet list")
    lemmas = fetch(TIMM_INFO + "imagenet_synset_to_lemma.txt", cache / "imagenet_meta" / "imagenet_synset_to_lemma.txt")
    names = dict(line.split("\t", 1) for line in lemmas.splitlines() if line.strip())  # covers ImageNet-21k
    missing = set(wnids) - set(names)
    if missing:
        raise ValueError(f"{len(missing)} ImageNet-1k IDs have no name")
    return wnids, {w: names[w] for w in wnids}


# ---------------------------------------------------------------- WordNet (Similar-20)
def wordnet_similarity(wnids):
    try:
        from nltk.corpus import wordnet as wn

        wn.ensure_loaded()
    except LookupError as exc:
        raise SystemExit(f"WordNet corpus missing; see the setup note at the top of this script ({exc})") from None
    if wn.get_version() != "3.0":
        raise SystemExit(f"ImageNet IDs are WordNet 3.0 offsets, found WordNet {wn.get_version()}")
    syn = {w: wn.synset_from_pos_and_offset("n", int(w[1:])) for w in wnids}
    anc = {w: {h for path in s.hypernym_paths() for h in path} for w, s in syn.items()}
    depth = {}

    def d(x):
        if x not in depth:
            depth[x] = x.max_depth() + 1
        return depth[x]

    def sim(a, b):
        if a == b:
            return 1.0
        lcs = max(anc[a] & anc[b], key=lambda c: (d(c), c.name()))
        return 2.0 * d(lcs) / (d(syn[a]) + d(syn[b]))

    return sim, anc


def most_similar_k(members, sim, k=K):
    chosen = sorted(members)
    while len(chosen) > k:
        chosen.remove(min(chosen, key=lambda w: (np.mean([sim(w, o) for o in chosen if o != w]), w)))
    return chosen


def select_similar(wnids, sim, anc, k=K):
    below = {}
    for w in wnids:
        for node in anc[w]:
            below.setdefault(node, set()).add(w)
    big = {n: ws for n, ws in below.items() if len(ws) >= k}
    minimal = [n for n, ws in big.items() if not any(m is not n and big[m] < ws for m in big)]
    families = []
    for node in minimal:
        members = most_similar_k(big[node], sim, k)
        pair_sims = [sim(a, b) for a, b in combinations(members, 2)]
        families.append((-float(np.mean(pair_sims)), -min(pair_sims), node.name(), members))
    families.sort()
    return families[0][2], families[0][3]


# ---------------------------------------------------------------- BREEDS (Dissimilar-20)
def load_breeds(cache: Path, wnids):
    edges = [line.split() for line in fetch(BREEDS_URL + "class_hierarchy.txt", cache / "breeds" / "class_hierarchy.txt").splitlines() if line.strip()]
    if not edges or any(len(e) != 2 for e in edges):
        raise ValueError("malformed BREEDS hierarchy")
    parents, children = {}, {}
    for p, c in edges:
        parents.setdefault(c, set()).add(p)
        children.setdefault(p, set()).add(c)
    roots = set(children) - set(parents)
    if len(roots) != 1 or any(len(ps) != 1 for ps in parents.values()):
        raise ValueError("BREEDS hierarchy is expected to be a tree with one root")
    root = roots.pop()
    depth, queue = {root: 0}, deque([root])
    while queue:
        n = queue.popleft()
        for c in children.get(n, ()):
            depth[c] = depth[n] + 1
            queue.append(c)
    covered = [w for w in wnids if w in depth]  # BREEDS omits some ambiguous classes

    def ancestors(n):
        out = [n]
        while n in parents:
            n = next(iter(parents[n]))
            out.append(n)
        return out

    anc = {w: ancestors(w) for w in covered}

    def sim(a, b):
        if a == b:
            return 1.0
        shared = set(anc[a]) & set(anc[b])
        return 2.0 * max(depth[n] for n in shared) / (depth[a] + depth[b])

    level = {w: next((n for n in anc[w] if depth[n] == LEVEL), None) for w in covered}
    return covered, anc, sim, level, depth


def select_dissimilar(covered, anc, sim, level, depth, similar, k=K):
    shared = set.intersection(*(set(anc[w]) for w in similar))
    group = max(shared, key=lambda n: (depth[n], n))  # deepest BREEDS node containing all of Similar-20
    pool = [w for w in covered if group not in anc[w]]
    dist = np.array([[1.0 - sim(a, b) for b in pool] for a in pool])
    picked = [max(range(len(pool)), key=lambda i: (dist[i].mean(), -i))]
    while len(picked) < k:
        used = {level[pool[i]] for i in picked}
        ok = [i for i in range(len(pool)) if i not in picked and (level[pool[i]] is None or level[pool[i]] not in used)]
        if not ok:
            raise RuntimeError("cannot pick classes from distinct BREEDS level-4 groups")
        picked.append(max(ok, key=lambda i: (dist[i, picked].min(), dist[i, picked].mean(), -i)))
    return [pool[i] for i in picked], group


# ---------------------------------------------------------------- output
def stats(ws, sim):
    s = [sim(a, b) for a, b in combinations(ws, 2)]
    return {"min": round(min(s), 4), "mean": round(float(np.mean(s)), 4), "max": round(max(s), 4)}


def build(cache: Path) -> dict[str, dict]:
    wnids, names = load_imagenet(cache)
    wn_sim, wn_anc = wordnet_similarity(wnids)
    family, similar = select_similar(wnids, wn_sim, wn_anc)
    covered, b_anc, b_sim, level, depth = load_breeds(cache, wnids)
    if not set(similar) <= set(covered):
        raise ValueError("Similar-20 contains classes missing from BREEDS")
    dissimilar, group = select_dissimilar(covered, b_anc, b_sim, level, depth, similar)
    common = {"selected_by": "study/scripts/select_classes.py", "wordnet": "3.0",
              "breeds": BREEDS_URL, "imagenet_ids": TIMM_INFO + "imagenet_synsets.txt"}
    sets = {
        "similar20": (similar, f"20 most mutually similar classes under WordNet node '{family}'"),
        "dissimilar20": (dissimilar, f"20 classes spread apart on BREEDS (excluding BREEDS node {group}; distinct level-{LEVEL} groups)"),
    }
    return {
        name: {
            "name": name,
            "description": desc,
            **common,
            "similarity": {"wordnet": stats(ws, wn_sim), "breeds": stats(ws, b_sim)},
            "classes": [{"index": wnids.index(w), "wnid": w, "name": names[w]} for w in sorted(ws, key=wnids.index)],
        }
        for name, (ws, desc) in sets.items()
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Select the Similar-20 and Dissimilar-20 ImageNet class sets.")
    parser.add_argument("--cache", type=Path, default=Path(r"D:\ResearchPaper2\.cache"), help="download/cache folder")
    parser.add_argument("--out", type=Path, default=OUT_DIR, help="folder for the class-set JSON files")
    parser.add_argument("--check", action="store_true", help="compare with the saved files instead of writing")
    args = parser.parse_args()
    result = build(args.cache)
    if args.check:
        bad = [n for n, data in result.items()
               if not (args.out / f"{n}.json").exists() or json.loads((args.out / f"{n}.json").read_text(encoding="utf-8")) != data]
        print("class sets reproduced exactly" if not bad else f"MISMATCH: {bad}")
        sys.exit(1 if bad else 0)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, data in result.items():
        path = args.out / f"{name}.json"
        if path.exists():
            sys.exit(f"error: {path} exists; delete it deliberately or use --check")
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"wrote {path}: {len(data['classes'])} classes, similarity {data['similarity']}")


if __name__ == "__main__":
    main()
