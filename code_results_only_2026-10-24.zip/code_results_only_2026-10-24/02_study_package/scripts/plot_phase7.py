"""Comparative graphs for Phase 7 (feature extraction) from the downloaded summary files.

    python study/scripts/plot_phase7.py results/phase7/phase7_v1            # folder with edge_metrics.csv etc.

Writes figures, the data behind each figure (CSV) and captions into ``<input>/figures/`` (refuses to overwrite).
Colours: reference categorical palette slots 1-4 in fixed order, validated (CVD/normal-vision pass; two slots have
low contrast, so every bar carries a printed value and each figure ships with its data table).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
import pandas as pd  # noqa: E402

SLOTS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]  # blue, orange, aqua, yellow (fixed order)
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
ORDER = ["fastvit_sa12", "fastvit_sa24", "dinov2_s14", "dinov3_s16", "dinov2_b14", "dinov3_b16", "siglip2_b16"]
LABEL = {"fastvit_sa12": "FastViT-SA12", "fastvit_sa24": "FastViT-SA24", "dinov2_s14": "DINOv2-S",
         "dinov3_s16": "DINOv3-S", "dinov2_b14": "DINOv2-B", "dinov3_b16": "DINOv3-B", "siglip2_b16": "SigLIP2-B"}
FAMILY = {"fastvit": "FastViT (supervised, edge)", "dinov2": "DINOv2 (self-supervised)",
          "dinov3": "DINOv3 (self-supervised)", "siglip2": "SigLIP 2 (image-text)"}
SETS = {"similar20": "Similar-20 (terriers)", "dissimilar20": "Dissimilar-20 (unrelated classes)"}


def style(ax, title, xlabel=None, ylabel=None):
    ax.set_facecolor(SURFACE)
    ax.set_title(title, color=INK, fontsize=11, loc="left")
    if xlabel:
        ax.set_xlabel(xlabel, color=INK2)
    if ylabel:
        ax.set_ylabel(ylabel, color=INK2)
    ax.tick_params(colors=INK2, labelsize=9)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def bar_labels(ax, bars, fmt):
    for b in bars:
        ax.annotate(fmt.format(b.get_height()), (b.get_x() + b.get_width() / 2, b.get_height()),
                    xytext=(0, 2), textcoords="offset points", ha="center", va="bottom", fontsize=7, color=INK2)


def grouped_bars(ax, df, groups, colors, names, legend=True):
    width = 0.38
    x = range(len(df))
    for i, (col, color) in enumerate(zip(groups, colors)):
        bars = ax.bar([v + (i - 0.5) * width for v in x], df[col], width=width, color=color,
                      edgecolor=SURFACE, linewidth=2, label=names[col])
        bar_labels(ax, bars, "{:.2f}")
    ax.set_xticks(list(x), [LABEL[b] for b in df.backbone], rotation=20, ha="right")
    if legend:
        ax.legend(frameon=False, fontsize=9, labelcolor=INK, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.25))


def save(fig, out: Path, name: str, data: pd.DataFrame, caption: str, captions: list):
    fig.savefig(out / f"{name}.png", dpi=200, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)
    data.to_csv(out / f"{name}_data.csv", index=False)
    captions.append(f"**{name}.png** — {caption} Data: `{name}_data.csv`.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("folder", type=Path, help="folder containing edge_metrics.csv and sanity_severity1.csv")
    args = parser.parse_args()
    out = args.folder / "figures"
    if out.exists():
        sys.exit(f"error: {out} exists - figures are never overwritten; move or rename it first")
    edge = pd.read_csv(args.folder / "edge_metrics.csv")
    sanity = pd.read_csv(args.folder / "sanity_severity1.csv")
    rank = {b: i for i, b in enumerate(ORDER)}
    edge = edge.sort_values("backbone", key=lambda s: s.map(rank)).reset_index(drop=True)
    glob = sanity[sanity.vector == "global"].sort_values("backbone", key=lambda s: s.map(rank)).reset_index(drop=True)
    out.mkdir(parents=True)
    captions = []
    plt.rcParams.update({"font.family": "DejaVu Sans"})

    # 1. sanity accuracy per backbone, both class sets
    fig, ax = plt.subplots(figsize=(9, 4.2))
    grouped_bars(ax, glob, list(SETS), SLOTS[:2], SETS)
    style(ax, "Quick sanity accuracy (severity 1, frozen features, linear classifier)", ylabel="Test accuracy")
    ax.set_ylim(0, 1.08)
    save(fig, out, "fig1_sanity_accuracy", glob[["backbone", *SETS]],
         "Accuracy of a logistic-regression check on the mildest damage level, per backbone (global vector), for "
         "both class sets. Higher is better; it only checks that each extractor works, not the final method.", captions)

    # 2. accuracy versus compute, small multiples per class set
    merged = glob.merge(edge, on="backbone")
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), sharey=False)
    for ax, (col, title) in zip(axes, SETS.items()):
        for fam, color in zip(FAMILY, SLOTS):
            rows = merged[merged.backbone.str.startswith(fam)]
            ax.scatter(rows.gmacs, rows[col], s=60, color=color, edgecolor=SURFACE, linewidth=2, label=FAMILY[fam], zorder=3)
            for _, r in rows.iterrows():  # DINOv2 labels below the point, others above: avoids S/B neighbours colliding
                below = r.backbone.startswith("dinov2")
                ax.annotate(LABEL[r.backbone], (r.gmacs, r[col]), xytext=(5, -11 if below else 4),
                            textcoords="offset points", fontsize=8, color=INK2)
        ax.set_xscale("log")
        ax.set_xticks([1, 2, 5, 10, 20], ["1", "2", "5", "10", "20"])
        ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
        style(ax, title, xlabel="Compute per image (GMACs, log scale)", ylabel="Sanity accuracy")
    handles, names = axes[0].get_legend_handles_labels()  # one legend under both panels: never covers points
    fig.legend(handles, names, frameon=False, fontsize=9, labelcolor=INK, ncol=4, loc="upper center",
               bbox_to_anchor=(0.5, 0.0))
    save(fig, out, "fig2_accuracy_vs_compute", merged[["backbone", "gmacs", "params_m", *SETS]],
         "Sanity accuracy against compute per 224×224 image. Points further up and to the left give more accuracy "
         "for less compute — the edge-device trade-off.", captions)

    # 3. latency (separate panels: never two scales on one axis)
    lat_cols = [c for c in ("gpu_ms_b1_fp16", "cpu_ms_b1") if c in edge]
    titles = {"gpu_ms_b1_fp16": "GPU latency, batch 1, fp16 (ms)", "cpu_ms_b1": "CPU latency, batch 1, fp32 (ms)"}
    fig, axes = plt.subplots(1, len(lat_cols), figsize=(5 * len(lat_cols), 4.2), squeeze=False)
    for ax, col in zip(axes[0], lat_cols):
        bars = ax.bar([LABEL[b] for b in edge.backbone], edge[col], color=SLOTS[0], edgecolor=SURFACE, linewidth=2)
        bar_labels(ax, bars, "{:.1f}")
        ax.tick_params(axis="x", rotation=30)
        style(ax, titles[col], ylabel="Milliseconds per image")
    save(fig, out, "fig3_latency", edge[["backbone", *lat_cols, "params_m", "gmacs"]],
         "Time to process one image on Kaggle's hardware (proxy for edge devices); lower is better. The hardware is "
         "named in environment.json.", captions)

    # 4. global vs patch-mean vector, where both exist
    both = sanity.pivot_table(index="backbone", columns="vector", values=list(SETS)).dropna()
    if not both.empty:
        fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
        rows_out = []
        for ax, (col, title) in zip(axes, SETS.items()):
            df = both[col].reset_index().sort_values("backbone", key=lambda s: s.map(rank)).reset_index(drop=True)
            grouped_bars(ax, df, ["global", "patch_mean"], SLOTS[2:4],
                         {"global": "Summary vector (CLS / pooled)", "patch_mean": "Average of patch vectors"},
                         legend=ax is axes[0])
            style(ax, title, ylabel="Sanity accuracy")
            ax.set_ylim(0, 1.08)
            rows_out.append(df.assign(class_set=col))
        axes[0].get_legend().set_bbox_to_anchor((1.1, -0.25))  # one legend, centred under both panels
        save(fig, out, "fig4_global_vs_patch_mean", pd.concat(rows_out),
             "Summary vector versus the average of patch vectors, per backbone and class set.", captions)

    (out / "captions.md").write_text("# Phase 7 figures\n\n" + "\n\n".join(captions) + "\n", encoding="utf-8")
    print(f"wrote {len(captions)} figures to {out}")


if __name__ == "__main__":
    main()
