"""Build the code bundle uploaded to Kaggle as a private dataset (runs locally in seconds).

    python kaggle/build_bundle.py            ->  kaggle/dist/researchpaper2-code_v<N>.zip  (next free N)

Bundles are never overwritten: the first bundle is ``researchpaper2-code.zip`` (= v1) and every later build gets the
next version number. Each zip holds python_port/ and study/ (sources, configs, tests, scripts) plus BUNDLE.json with
the version, build time, the git commit it was built from and a SHA-256 per file. Building from uncommitted code is
refused (``--allow-dirty`` overrides), so every bundle can be traced to an exact code version.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "researchpaper2-code"
PARTS = {
    "python_port": ["pyproject.toml", "README.md", "requirements.txt", "requirements-torch.txt", "src", "configs", "tests", "scripts"],
    "study": ["pyproject.toml", "README.md", "src", "configs", "tests", "scripts"],
}
SKIP_DIRS = {"__pycache__", ".pytest_cache"}
DIST = ROOT / "kaggle" / "dist"


def files_to_bundle(root: Path = ROOT) -> list[Path]:
    out = []
    for top, entries in PARTS.items():
        for entry in entries:
            path = root / top / entry
            if path.is_file():
                out.append(path)
            elif path.is_dir():
                out.extend(p for p in sorted(path.rglob("*"))
                           if p.is_file() and not (set(p.relative_to(root).parts) & SKIP_DIRS)
                           and not any(part.endswith(".egg-info") for part in p.relative_to(root).parts))
            else:
                raise FileNotFoundError(f"bundle entry missing: {path}")
    return out


def next_version(dist: Path) -> int:
    """v1 is the original unsuffixed zip; later bundles are ``<NAME>_v<N>.zip``."""
    versions = [1] if (dist / f"{NAME}.zip").exists() else []
    for p in dist.glob(f"{NAME}_v*.zip"):
        match = re.fullmatch(rf"{re.escape(NAME)}_v(\d+)\.zip", p.name)
        if match:
            versions.append(int(match.group(1)))
    return max(versions, default=0) + 1


def git_state(root: Path = ROOT) -> dict:
    try:
        commit = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
        status = subprocess.run(["git", "-C", str(root), "status", "--porcelain"], capture_output=True, text=True, check=True).stdout
    except (OSError, subprocess.CalledProcessError):
        return {"git_commit": None, "git_dirty": None}
    return {"git_commit": commit, "git_dirty": bool(status.strip())}


def build(dist: Path = DIST, root: Path = ROOT, allow_dirty: bool = False) -> Path:
    state = git_state(root)
    if state["git_dirty"] and not allow_dirty:
        raise SystemExit("error: uncommitted changes - commit them first so the bundle is traceable (or use --allow-dirty)")
    files = files_to_bundle(root)
    version = next_version(dist)
    out = dist / f"{NAME}_v{version}.zip"
    manifest = {
        "version": version,
        "built_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        **state,
        "files": {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    }
    dist.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            zf.write(p, p.relative_to(root).as_posix())
        zf.writestr("BUNDLE.json", json.dumps(manifest, indent=2))
    if out.exists():  # cannot happen with next_version, but never overwrite
        tmp.unlink()
        raise FileExistsError(out)
    tmp.rename(out)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the next versioned Kaggle code bundle.")
    parser.add_argument("--allow-dirty", action="store_true", help="build even with uncommitted changes")
    args = parser.parse_args()
    out = build(allow_dirty=args.allow_dirty)
    print(f"wrote {out} ({out.stat().st_size / 1024:.0f} KiB)")


if __name__ == "__main__":
    main()
