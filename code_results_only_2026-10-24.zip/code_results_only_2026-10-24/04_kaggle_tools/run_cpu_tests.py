"""Run all project tests on CPU only, separately from the GPU notebooks (they no longer spend GPU time on tests).

    python kaggle/run_cpu_tests.py                 # local PC (quick) or a Kaggle CPU session
    python kaggle/run_cpu_tests.py --report-dir results/test_reports

The GPU is hidden from the tests. A JUnit report is written to a new numbered file (never overwritten).
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SUITES = ["python_port/tests", "study/tests", "kaggle/tests"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--report-dir", type=Path, default=ROOT / "results" / "test_reports")
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    n = 1
    while (report := args.report_dir / f"{date.today().isoformat()}_cpu_tests_{n}.xml").exists():
        n += 1
    env = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}
    suites = [str(ROOT / s) for s in SUITES if (ROOT / s).is_dir()]
    cmd = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *suites, f"--junitxml={report}"]
    result = subprocess.run(cmd, env=env)
    print(f"report: {report}")
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
