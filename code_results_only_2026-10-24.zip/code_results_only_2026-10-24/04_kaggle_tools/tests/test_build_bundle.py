import importlib.util
import json
import zipfile
from pathlib import Path

import pytest

_SPEC = importlib.util.spec_from_file_location("build_bundle", Path(__file__).resolve().parents[1] / "build_bundle.py")
bb = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(bb)


def test_next_version(tmp_path):
    assert bb.next_version(tmp_path) == 1
    (tmp_path / f"{bb.NAME}.zip").write_bytes(b"v1")
    assert bb.next_version(tmp_path) == 2
    for name in (f"{bb.NAME}_v2.zip", f"{bb.NAME}_v5.zip", f"{bb.NAME}_v3.zip.tmp", "other_v9.zip", f"{bb.NAME}_vX.zip"):
        (tmp_path / name).write_bytes(b"x")
    assert bb.next_version(tmp_path) == 6


def test_builds_never_overwrite_and_record_version(tmp_path):
    dist = tmp_path / "dist"
    first = bb.build(dist=dist, allow_dirty=True)
    second = bb.build(dist=dist, allow_dirty=True)
    assert first.name == f"{bb.NAME}_v1.zip" and second.name == f"{bb.NAME}_v2.zip"
    assert first.exists() and second.exists()
    with zipfile.ZipFile(second) as zf:
        meta = json.loads(zf.read("BUNDLE.json"))
        assert meta["version"] == 2 and "git_commit" in meta and "git_dirty" in meta
        assert set(meta["files"]) <= set(zf.namelist())


def test_dirty_tree_is_refused(tmp_path, monkeypatch):
    monkeypatch.setattr(bb, "git_state", lambda root=bb.ROOT: {"git_commit": "abc", "git_dirty": True})
    with pytest.raises(SystemExit, match="uncommitted"):
        bb.build(dist=tmp_path)
