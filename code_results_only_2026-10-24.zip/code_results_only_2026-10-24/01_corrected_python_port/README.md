# hazypark — Python port of arXiv:2501.13422

Corrected Python port of the MATLAB code in `../codefilesattached/` (the originals are not modified).
Pipeline: ImageNet CNN features → Pin-GTSVM (RBF or linear) → busy (+1) / free (−1).

## MATLAB → Python map

| MATLAB | Python |
|---|---|
| `Feature_Extraction (1).m` (ResNet-50 `fc1000`, PKLot UFPR05→PUCPR) | `configs/resnet50_pklot_ufpr05_to_pucpr.yaml` |
| `Feature_Extraction_Alexnet.m` (AlexNet `fc7`, Hazy) | `configs/alexnet_hazy.yaml` |
| `FEATURE_EXTRACTION_GOOGLENET (1).m` (GoogLeNet `pool5-drop_7x7_s1`, CNRPark B→A) | `configs/googlenet_cnrpark_b_to_a.yaml` |
| `imageDatastore` + `extract_features` | `hazypark/data.py`, `hazypark/features.py` |
| `pinGTSVM_RBF_1.m` | `hazypark/pin_gtsvm.py` (`PinGTSVM`) |
| nested grid-search loops | `hazypark/grid.py` (same results; paper grid: 21 kernel builds instead of 7,623 and 11× fewer QP solves) |
| `cvpartition` 5-fold CV | `hazypark/experiment.py` (stratified, seeded) |
| confusion matrix / precision / recall / F1 / specificity | `hazypark/metrics.py` (+ balanced accuracy, MCC) |

## Corrections vs. MATLAB (user decision: "corrected only")

1. Pin-GTSVM dual per Tanveer et al. 2019 (τ meaning of the cited method): objective `½λᵀQλ − eᵀλ`, box `−τc ≤ λ ≤ c`.
   MATLAB used `−τeᵀλ`, no lower bound and upper bound `(1−τ)c`, so τ = 1 collapsed to w = 0.
   Verified in `tests/test_pin_gtsvm.py::test_dual_solution_matches_primal` against an independently solved primal.
2. Nearest-surface rule uses `|K(x,D)w + b| / ‖w‖` (MATLAB did not normalise).
3. Linear kernel uses all test columns (MATLAB dropped the last one → dimension error).
4. False-positive / false-negative files come from the selected model (MATLAB used the last grid point).
5. Hyperparameters are selected by stratified, seeded CV on the training set (`cv_select`).
   The paper's tune-on-test result is still produced (`test_select`) and labelled as biased.
6. Undefined metrics are NaN, not 0; corrupt images fail fast; feature files and runs are never overwritten.

Features are **not numerically identical** to MATLAB: torchvision weights differ from MATLAB's Caffe weights
(see `features.py` header). Expect small accuracy differences from the paper even before the corrections.

## Usage (from `D:\ResearchPaper2`)

```bash
.venv/Scripts/python -m pip install -r python_port/requirements.txt -e python_port
.venv/Scripts/python -m pip install --no-cache-dir -r python_port/requirements-torch.txt
.venv/Scripts/python -m pytest python_port/tests
.venv/Scripts/python -m hazypark.cli all --config python_port/configs/alexnet_hazy.yaml
```

Replace the `SET_ME` dataset paths in the configs first. Outputs go to `results/<experiment>/`:
`features/*.npz` (cached features) and `runs/<UTC time>/` (`summary.json`, `cv_grid.csv`, `test_grid_paper_protocol.csv`, `config.yaml`).
