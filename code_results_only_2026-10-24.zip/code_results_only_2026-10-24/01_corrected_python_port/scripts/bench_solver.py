"""Time the exact Pin-GTSVM solver (RBF) at given problem sizes and save a CSV.

Each size is "n_pos:n_neg:dim". Data are seeded random Gaussians, so the timings measure
the solver (kernel build, Cholesky, QPs), not the features.

    python python_port/scripts/bench_solver.py --out results/benchmarks/exact_solver.csv 2625:2625:768
"""

from __future__ import annotations

import argparse
import csv
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import scipy

from hazypark.pin_gtsvm import build_twin_problems, solve_box_qp

FIELDS = ["utc_time", "n_pos", "n_neg", "dim", "sigma", "build_s", "qp1_s", "qp2_s", "fit_s", "qp1_status", "qp2_status",
          "cpu", "logical_cpus", "python", "numpy", "scipy"]


def parse_size(text: str) -> tuple[int, int, int]:
    parts = text.split(":")
    if len(parts) != 3 or not all(p.isdigit() and int(p) > 0 for p in parts):
        raise argparse.ArgumentTypeError(f"size must be n_pos:n_neg:dim with positive integers, got {text!r}")
    return tuple(int(p) for p in parts)


def run(n_pos: int, n_neg: int, dim: int, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    A = rng.normal(size=(n_pos, dim)) + 0.3
    B = rng.normal(size=(n_neg, dim)) - 0.3
    sigma = float(np.sqrt(dim))  # keeps kernel values away from 0/1 for unit-variance data
    t0 = time.perf_counter()
    problems = build_twin_problems(A, B, "rbf", sigma, 0.05)
    t1 = time.perf_counter()
    _, s1 = solve_box_qp(problems.plane1.Q, 1.0, 0.5)
    t2 = time.perf_counter()
    _, s2 = solve_box_qp(problems.plane2.Q, 1.0, 0.5)
    t3 = time.perf_counter()
    return {
        "utc_time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "n_pos": n_pos, "n_neg": n_neg, "dim": dim, "sigma": round(sigma, 4),
        "build_s": round(t1 - t0, 3), "qp1_s": round(t2 - t1, 3), "qp2_s": round(t3 - t2, 3), "fit_s": round(t3 - t0, 3),
        "qp1_status": s1, "qp2_status": s2,
        "cpu": platform.processor(), "logical_cpus": os.cpu_count(),
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("sizes", nargs="+", type=parse_size, help="n_pos:n_neg:dim")
    parser.add_argument("--out", required=True, type=Path, help="CSV file to create (never overwritten)")
    args = parser.parse_args()
    if args.out.exists():
        parser.exit(2, f"error: {args.out} already exists; choose a new file name\n")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for n_pos, n_neg, dim in args.sizes:
        row = run(n_pos, n_neg, dim)
        rows.append(row)
        print(f"{n_pos}+{n_neg} x {dim}: build {row['build_s']}s, QPs {row['qp1_s']}s + {row['qp2_s']}s "
              f"[{row['qp1_status']}/{row['qp2_status']}] -> fit {row['fit_s']}s")
    with args.out.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"saved {args.out}")


if __name__ == "__main__":
    main()
