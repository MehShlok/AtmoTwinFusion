"""CNN feature extraction; Python equivalent of MATLAB ``activations(net, img, layer)``.

Layer mapping (MATLAB -> torchvision):
  resnet50  'fc1000'               -> model.fc output, 1000-d (pre-softmax logits)
  resnet50  'avg_pool' (option)    -> model.avgpool output, 2048-d (usual feature layer)
  alexnet   'fc7'                  -> model.classifier[4] output, 4096-d, before relu7
  googlenet 'pool5-drop_7x7_s1'    -> model.avgpool output, 1024-d (dropout is identity at inference)
  googlenet 'loss3-classifier'     -> model.fc output, 1000-d (the layer the paper's text names)

Known, unavoidable differences from MATLAB (features will not be numerically identical):
  * MATLAB's AlexNet/GoogLeNet/ResNet-50 weights are the original Caffe releases;
    torchvision's are independently trained (its GoogLeNet also adds BatchNorm).
  * MATLAB normalises with the training mean image; torchvision models expect the
    ImageNet per-channel mean/std used below.
  * MATLAB AlexNet takes 227x227 input; torchvision AlexNet takes 224x224.
Preprocessing otherwise follows MATLAB ``imresize``: a direct (aspect-distorting) resize
to the network size with bicubic interpolation and antialiasing.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .data import LabelledImages, find_unreadable, load_rgb

log = logging.getLogger(__name__)

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
INPUT_SIZE = 224


@dataclass(frozen=True)
class LayerSpec:
    model: str
    layer: str
    dim: int
    module_path: str  # attribute path of the hooked torchvision module
    matlab_layer: str


LAYERS = {
    ("resnet50", "fc1000"): LayerSpec("resnet50", "fc1000", 1000, "fc", "fc1000"),
    ("resnet50", "avgpool"): LayerSpec("resnet50", "avgpool", 2048, "avgpool", "avg_pool"),
    ("alexnet", "fc7"): LayerSpec("alexnet", "fc7", 4096, "classifier.4", "fc7"),
    ("googlenet", "pool5"): LayerSpec("googlenet", "pool5", 1024, "avgpool", "pool5-drop_7x7_s1"),
    ("googlenet", "loss3-classifier"): LayerSpec("googlenet", "loss3-classifier", 1000, "fc", "loss3-classifier"),
}


def get_layer_spec(model: str, layer: str) -> LayerSpec:
    try:
        return LAYERS[(model, layer)]
    except KeyError:
        raise ValueError(f"unsupported model/layer {model}/{layer}; choose from {sorted(LAYERS)}") from None


def _build_model(model: str, pretrained: bool):
    from torchvision import models

    if model == "resnet50":
        return models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None)
    if model == "alexnet":
        return models.alexnet(weights=models.AlexNet_Weights.IMAGENET1K_V1 if pretrained else None)
    if model == "googlenet":
        if pretrained:
            return models.googlenet(weights=models.GoogLeNet_Weights.IMAGENET1K_V1)
        return models.googlenet(weights=None, aux_logits=False, init_weights=False)
    raise ValueError(f"unknown model {model!r}")


def build_extractor(model: str, layer: str, pretrained: bool = True):
    """Return (torch module mapping images -> (n, dim) features, LayerSpec)."""
    import torch
    from torch import nn

    spec = get_layer_spec(model, layer)
    net = _build_model(model, pretrained).eval()

    class HookedExtractor(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = net
            self._out = None
            net.get_submodule(spec.module_path).register_forward_hook(self._capture)

        def _capture(self, _module, _inputs, output):
            self._out = output

        def forward(self, x):
            self._out = None
            self.net(x)
            if self._out is None:
                raise RuntimeError(f"hook on {spec.module_path} did not fire")
            return torch.flatten(self._out, 1)

    return HookedExtractor().eval(), spec


def build_transform():
    from torchvision import transforms

    return transforms.Compose(
        [
            transforms.Resize((INPUT_SIZE, INPUT_SIZE), interpolation=transforms.InterpolationMode.BICUBIC, antialias=True),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


def _paths_digest(paths) -> str:
    return hashlib.sha256("\n".join(str(p) for p in paths).encode()).hexdigest()


def extract_features(
    images: LabelledImages,
    model: str,
    layer: str,
    out_file: str | Path,
    batch_size: int = 32,
    num_workers: int = 2,
    device: str = "auto",
    overwrite: bool = False,
) -> Path:
    """Extract features for ``images`` and save them to ``out_file`` (.npz).

    An existing file with matching metadata is reused. A file with different metadata is
    never overwritten unless ``overwrite=True`` (protects earlier extraction runs).
    """
    import torch
    import torchvision
    from torch.utils.data import DataLoader, Dataset

    out_file = Path(out_file)
    spec = get_layer_spec(model, layer)
    meta = {
        "model": model,
        "layer": layer,
        "matlab_layer": spec.matlab_layer,
        "dim": spec.dim,
        "input_size": INPUT_SIZE,
        "normalisation": {"mean": IMAGENET_MEAN, "std": IMAGENET_STD},
        "n_images": len(images.paths),
        "paths_sha256": _paths_digest(images.paths),
        "torch": torch.__version__,
        "torchvision": torchvision.__version__,
    }
    if out_file.exists():
        existing = load_features(out_file)[3]
        same = all(existing.get(k) == v for k, v in meta.items() if k not in ("torch", "torchvision"))
        if same and not overwrite:
            log.info("reusing cached features %s", out_file)
            return out_file
        if not overwrite:
            raise FileExistsError(f"{out_file} exists with different metadata; pass overwrite=True to replace it")

    bad = find_unreadable(images.paths)
    if bad:
        listing = "\n".join(f"  {p}: {err}" for p, err in bad[:20])
        raise ValueError(f"{len(bad)} unreadable image(s); fix or remove them first:\n{listing}")

    dev = torch.device("cuda" if device == "auto" and torch.cuda.is_available() else ("cpu" if device == "auto" else device))
    extractor, _ = build_extractor(model, layer)
    extractor.to(dev)
    transform = build_transform()

    class _Images(Dataset):
        def __len__(self):
            return len(images.paths)

        def __getitem__(self, i):
            return transform(load_rgb(images.paths[i]))

    loader = DataLoader(_Images(), batch_size=batch_size, num_workers=num_workers, shuffle=False, pin_memory=dev.type == "cuda")
    chunks = []
    with torch.inference_mode():
        for batch in loader:
            chunks.append(extractor(batch.to(dev, non_blocking=True)).float().cpu().numpy())
    feats = np.concatenate(chunks).astype(np.float32)
    if feats.shape != (len(images.paths), spec.dim):
        raise RuntimeError(f"expected features of shape {(len(images.paths), spec.dim)}, got {feats.shape}")
    if not np.all(np.isfinite(feats)):
        raise RuntimeError("extracted features contain NaN/inf")
    meta["device"] = str(dev)

    out_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_file.with_name(out_file.name + ".tmp.npz")
    np.savez(tmp, X=feats, y=images.labels, paths=np.array([str(p) for p in images.paths]), meta=json.dumps(meta))
    tmp.replace(out_file)  # atomic: a crash never leaves a half-written feature file
    log.info("saved %s features %s to %s", model, feats.shape, out_file)
    return out_file


def load_features(path: str | Path) -> tuple[np.ndarray, np.ndarray, list[str], dict]:
    with np.load(path, allow_pickle=False) as data:
        X, y = data["X"], data["y"].astype(int)
        paths = data["paths"].tolist()
        meta = json.loads(str(data["meta"]))
    if X.shape[0] != y.shape[0] or X.shape[0] != len(paths):
        raise ValueError(f"{path}: features, labels and paths have inconsistent lengths")
    return X, y, paths, meta
