"""Binary classification metrics with the MATLAB conventions (busy = +1 is positive).

Undefined ratios (e.g. precision when nothing is predicted positive) are returned as NaN
rather than silently replaced by 0, so they are visible in reports. Balanced accuracy and
the Matthews correlation coefficient are added because the test sets are imbalanced
(Chicco & Jurman, BMC Genomics 21:6, 2020).
"""

from __future__ import annotations

import math

import numpy as np

POS, NEG = 1, -1


def _ratio(num: float, den: float) -> float:
    return num / den if den else math.nan


def confusion_counts(y_true, y_pred) -> dict[str, int]:
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    if y_true.shape != y_pred.shape:
        raise ValueError(f"y_true has {y_true.size} labels but y_pred has {y_pred.size}")
    if y_true.size == 0:
        raise ValueError("cannot score an empty prediction set")
    for name, arr in (("y_true", y_true), ("y_pred", y_pred)):
        bad = set(np.unique(arr).tolist()) - {POS, NEG}
        if bad:
            raise ValueError(f"{name} contains labels other than +1/-1: {sorted(bad)}")
    return {
        "tp": int(np.sum((y_pred == POS) & (y_true == POS))),
        "fp": int(np.sum((y_pred == POS) & (y_true == NEG))),
        "tn": int(np.sum((y_pred == NEG) & (y_true == NEG))),
        "fn": int(np.sum((y_pred == NEG) & (y_true == POS))),
    }


def binary_metrics(y_true, y_pred) -> dict[str, float]:
    c = confusion_counts(y_true, y_pred)
    tp, fp, tn, fn = c["tp"], c["fp"], c["tn"], c["fn"]
    n = tp + fp + tn + fn
    precision = _ratio(tp, tp + fp)
    recall = _ratio(tp, tp + fn)
    specificity = _ratio(tn, tn + fp)
    f1 = _ratio(2 * tp, 2 * tp + fp + fn)
    mcc_den = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return {
        **c,
        "n": n,
        "errors": fp + fn,
        "accuracy": (tp + tn) / n,
        "precision": precision,
        "recall": recall,
        "specificity": specificity,
        "f1": f1,
        "balanced_accuracy": 0.5 * (recall + specificity),
        "mcc": _ratio(tp * tn - fp * fn, mcc_den),
    }


def accuracy_rows(y_true, predictions: np.ndarray) -> np.ndarray:
    """Accuracy of every row of a (n_combinations, n) prediction matrix."""
    y_true = np.asarray(y_true).ravel()
    if predictions.ndim != 2 or predictions.shape[1] != y_true.size:
        raise ValueError(f"predictions must have shape (k, {y_true.size}), got {predictions.shape}")
    return (predictions == y_true[None, :]).mean(axis=1)
