"""Command line entry point.

    python -m hazypark.cli extract  --config python_port/configs/<exp>.yaml
    python -m hazypark.cli classify --config python_port/configs/<exp>.yaml
    python -m hazypark.cli all      --config python_port/configs/<exp>.yaml
"""

from __future__ import annotations

import argparse
import logging

from .experiment import load_config, run_classify, run_extract


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="hazypark", description="CNN features + Pin-GTSVM (port of arXiv:2501.13422)")
    parser.add_argument("stage", choices=("extract", "classify", "all"))
    parser.add_argument("--config", required=True, help="experiment YAML file")
    parser.add_argument("--output-root", help="override output_root from the config")
    parser.add_argument("--overwrite-features", action="store_true", help="replace cached features with different metadata")
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        cfg = load_config(args.config)
        if args.output_root:
            cfg["output_root"] = args.output_root
        if args.stage in ("extract", "all"):
            run_extract(cfg, overwrite=args.overwrite_features)
        if args.stage in ("classify", "all"):
            run_classify(cfg, config_path=args.config)
    except (FileNotFoundError, FileExistsError, ValueError) as exc:  # user-fixable problems: no traceback
        parser.exit(2, f"error: {exc}\n")


if __name__ == "__main__":
    main()
