"""Experiment runner: feature extraction + Pin-GTSVM evaluation under two protocols.

``cv_select`` (main, unbiased): hyperparameters chosen by stratified, seeded k-fold CV on
    the training set only; the test set is scored once with the chosen model.
``test_select`` (paper protocol, for comparison only): every grid point is scored on the
    test set and the best is reported, as in the MATLAB scripts. This is optimistically
    biased (selection on the test set) and is labelled as such in every output.

Ties in the selection score are broken towards the smoother/simpler model: lower CV
standard deviation, then larger sigma, then smaller c1 + c2, then grid order.
"""

from __future__ import annotations

import json
import logging
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

from .data import load_split
from .grid import evaluate_grid, expand_values
from .metrics import accuracy_rows, binary_metrics
from .pin_gtsvm import PinGTSVM

log = logging.getLogger(__name__)

PROTOCOLS = ("cv_select", "test_select")
_REQUIRED = {
    "name": str,
    "features": dict,
    "data": dict,
    "classifier": dict,
    "evaluation": dict,
}


# --------------------------------------------------------------------------- config
def load_config(path: str | Path) -> dict:
    path = Path(path)
    with path.open(encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    if not isinstance(cfg, dict):
        raise ValueError(f"{path}: config must be a mapping")
    for key, typ in _REQUIRED.items():
        if not isinstance(cfg.get(key), typ):
            raise ValueError(f"{path}: '{key}' is missing or not a {typ.__name__}")
    for split in ("train", "test"):
        folders = cfg["data"].get(split)
        if not isinstance(folders, dict) or set(folders) != {"busy", "free"}:
            raise ValueError(f"{path}: data.{split} must have exactly 'busy' and 'free' folders")
    clf = cfg["classifier"]
    if clf.get("kernel", "rbf") not in ("rbf", "linear"):
        raise ValueError(f"{path}: classifier.kernel must be 'rbf' or 'linear'")
    needed = {"c1", "c2", "tau"} | ({"sigma"} if clf.get("kernel", "rbf") == "rbf" else set())
    missing = needed - set(clf.get("grid", {}))
    if missing:
        raise ValueError(f"{path}: classifier.grid is missing {sorted(missing)}")
    for name in needed:
        expand_values(clf["grid"][name])  # raises on malformed specs
    protocols = cfg["evaluation"].get("protocols", list(PROTOCOLS))
    if not protocols or set(protocols) - set(PROTOCOLS):
        raise ValueError(f"{path}: evaluation.protocols must be a non-empty subset of {PROTOCOLS}")
    cfg.setdefault("output_root", "results")
    return cfg


def feature_file(cfg: dict, split: str) -> Path:
    f = cfg["features"]
    return Path(cfg["output_root"]) / cfg["name"] / "features" / f"{split}_{f['model']}_{f['layer']}.npz"


# --------------------------------------------------------------------------- extraction
def run_extract(cfg: dict, overwrite: bool = False) -> dict[str, Path]:
    from .features import extract_features

    f = cfg["features"]
    unset = [f"data.{s}.{c}" for s in ("train", "test") for c in ("busy", "free") if "SET_ME" in str(cfg["data"][s][c])]
    if unset:
        raise ValueError(f"dataset paths not set in the config: {', '.join(unset)}")
    out = {}
    for split in ("train", "test"):
        images = load_split(cfg["data"][split]["busy"], cfg["data"][split]["free"])
        log.info("%s: %d busy, %d free", split, int((images.labels == 1).sum()), int((images.labels == -1).sum()))
        out[split] = extract_features(
            images,
            f["model"],
            f["layer"],
            feature_file(cfg, split),
            batch_size=f.get("batch_size", 32),
            num_workers=f.get("num_workers", 2),
            device=f.get("device", "auto"),
            overwrite=overwrite,
        )
    return out


# --------------------------------------------------------------------------- evaluation
def _scale(X_fit, *others, enabled: bool):
    if not enabled:
        return (X_fit, *others)
    scaler = StandardScaler().fit(X_fit)  # fitted on training rows only (no leakage)
    return (scaler.transform(X_fit), *(scaler.transform(X) for X in others))


def cv_grid(X, y, grid, kernel, eps, folds, seed, standardize, qp_options=None) -> pd.DataFrame:
    """Mean/std k-fold CV accuracy of every grid combination (training data only)."""
    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    per_fold, params = [], None
    for k, (tr, va) in enumerate(skf.split(X, y), start=1):
        X_tr, X_va = _scale(X[tr], X[va], enabled=standardize)
        res = evaluate_grid(X_tr, y[tr], X_va, grid, kernel, eps, qp_options)
        per_fold.append(accuracy_rows(y[va], res.predictions))
        params = params or res.params
        log.info("CV fold %d/%d done in %.1fs", k, folds, res.seconds)
    acc = np.vstack(per_fold).T  # (n_combinations, folds)
    df = pd.DataFrame(params)
    for k in range(folds):
        df[f"fold{k + 1}_accuracy"] = acc[:, k]
    df["cv_mean_accuracy"] = acc.mean(axis=1)
    df["cv_std_accuracy"] = acc.std(axis=1, ddof=1)  # sample std, as MATLAB std()
    return df


def select_best(df: pd.DataFrame, score: str, std: str | None = None) -> pd.Series:
    ranked = df.assign(_neg_score=-df[score], _csum=df["c1"] + df["c2"], _neg_sigma=-df["sigma"].astype(float))
    keys = ["_neg_score"] + ([std] if std else []) + ["_neg_sigma", "_csum"]
    return ranked.sort_values(keys, kind="mergesort", na_position="last").iloc[0][df.columns]


def fit_and_score(params: dict, kernel: str, eps: float, X_tr, y_tr, X_te, y_te, paths_te, qp_options=None) -> dict:
    model = PinGTSVM(c1=params["c1"], c2=params["c2"], tau=params["tau"], kernel=kernel,
                     sigma=params.get("sigma"), eps=eps, qp_options=qp_options)
    t0 = time.perf_counter()
    model.fit(X_tr, y_tr)
    t1 = time.perf_counter()
    pred = model.predict(X_te)
    t2 = time.perf_counter()
    fp = [paths_te[i] for i in np.flatnonzero((pred == 1) & (y_te == -1))]
    fn = [paths_te[i] for i in np.flatnonzero((pred == -1) & (y_te == 1))]
    return {
        "params": {k: (None if v is None or (isinstance(v, float) and np.isnan(v)) else float(v)) for k, v in params.items()},
        "metrics": binary_metrics(y_te, pred),
        "fit_seconds": t1 - t0,
        "predict_seconds": t2 - t1,
        "qp_status": list(model.qp_status_),
        "false_positives": fp,
        "false_negatives": fn,
    }


def environment_info() -> dict:
    import cvxopt
    import scipy
    import sklearn

    info = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "scikit-learn": sklearn.__version__,
        "cvxopt": cvxopt.__version__,
        "pandas": pd.__version__,
    }
    try:
        import torch

        info["torch"] = torch.__version__
        info["cuda_device"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except ImportError:
        info["torch"] = None
    return info


def run_classify(cfg: dict, config_path: str | Path | None = None) -> Path:
    from .features import load_features

    for split in ("train", "test"):
        if not feature_file(cfg, split).exists():
            raise FileNotFoundError(f"{feature_file(cfg, split)} not found; run the 'extract' stage first")
    X_tr, y_tr, _, meta_tr = load_features(feature_file(cfg, "train"))
    X_te, y_te, paths_te, meta_te = load_features(feature_file(cfg, "test"))
    if X_tr.shape[1] != X_te.shape[1]:
        raise ValueError(f"train/test feature dims differ: {X_tr.shape[1]} vs {X_te.shape[1]}")
    X_tr, X_te = X_tr.astype(np.float64), X_te.astype(np.float64)

    clf, ev = cfg["classifier"], cfg["evaluation"]
    kernel, eps, grid = clf.get("kernel", "rbf"), float(clf.get("eps", 0.05)), clf["grid"]
    standardize, qp_options = bool(clf.get("standardize", False)), clf.get("qp_options")
    protocols = ev.get("protocols", list(PROTOCOLS))

    run_dir = Path(cfg["output_root"]) / cfg["name"] / "runs" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir.mkdir(parents=True, exist_ok=False)  # never overwrite an earlier run
    (run_dir / "config.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")

    X_tr_s, X_te_s = _scale(X_tr, X_te, enabled=standardize)
    summary = {
        "name": cfg["name"],
        "config_file": str(config_path) if config_path else None,
        "n_train": {"busy": int((y_tr == 1).sum()), "free": int((y_tr == -1).sum())},
        "n_test": {"busy": int((y_te == 1).sum()), "free": int((y_te == -1).sum())},
        "feature_meta": {"train": meta_tr, "test": meta_te},
        "kernel": kernel,
        "eps": eps,
        "standardize": standardize,
        "environment": environment_info(),
        "protocols": {},
    }

    if "cv_select" in protocols:
        folds, seed = int(ev.get("cv_folds", 5)), int(ev.get("seed", 42))
        df = cv_grid(X_tr, y_tr, grid, kernel, eps, folds, seed, standardize, qp_options)
        df.to_csv(run_dir / "cv_grid.csv", index=False)
        best = select_best(df, "cv_mean_accuracy", "cv_std_accuracy")
        result = fit_and_score(best[["c1", "c2", "tau", "sigma"]].to_dict(), kernel, eps, X_tr_s, y_tr, X_te_s, y_te, paths_te, qp_options)
        result.update(
            cv_folds=folds, seed=seed,
            cv_mean_accuracy=float(best["cv_mean_accuracy"]), cv_std_accuracy=float(best["cv_std_accuracy"]),
            note="hyperparameters selected by stratified k-fold CV on the training set; test set used once",
        )
        summary["protocols"]["cv_select"] = result

    if "test_select" in protocols:
        res = evaluate_grid(X_tr_s, y_tr, X_te_s, grid, kernel, eps, qp_options)
        df = pd.DataFrame(res.params)
        df["test_accuracy"] = accuracy_rows(y_te, res.predictions)
        df.to_csv(run_dir / "test_grid_paper_protocol.csv", index=False)
        best = select_best(df, "test_accuracy")
        result = fit_and_score(best[["c1", "c2", "tau", "sigma"]].to_dict(), kernel, eps, X_tr_s, y_tr, X_te_s, y_te, paths_te, qp_options)
        result.update(
            grid_seconds=res.seconds,
            note="PAPER PROTOCOL: best of the grid scored on the test set (optimistically biased; comparison only)",
        )
        summary["protocols"]["test_select"] = result

    with (run_dir / "summary.json").open("w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, default=str)
    log.info("results written to %s", run_dir)
    return run_dir
