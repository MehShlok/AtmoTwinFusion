"""Image listing and validation; Python equivalent of MATLAB ``imageDatastore``.

MATLAB used ``imageDatastore(folder, 'IncludeSubfolders', true)`` per class folder and
labelled busy = +1, free = -1. Files are listed recursively in sorted order so feature
rows, labels and file paths always stay aligned.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, UnidentifiedImageError

POS, NEG = 1, -1
# Common subset of MATLAB's imformats; matched case-insensitively.
IMAGE_EXTENSIONS = frozenset({".bmp", ".gif", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".ppm", ".pgm", ".pbm", ".pnm"})


@dataclass(frozen=True)
class LabelledImages:
    paths: list[Path]
    labels: np.ndarray  # int8, +1 busy / -1 free

    def __post_init__(self):
        if len(self.paths) != len(self.labels):
            raise ValueError("paths and labels must have the same length")


def list_images(folder: str | Path) -> list[Path]:
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"image folder does not exist: {folder}")
    paths = sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if not paths:
        raise ValueError(f"no images with extensions {sorted(IMAGE_EXTENSIONS)} found under {folder}")
    return paths


def load_split(busy_folder: str | Path, free_folder: str | Path) -> LabelledImages:
    """Busy images first, then free images, exactly as the MATLAB scripts concatenate them."""
    busy, free = list_images(busy_folder), list_images(free_folder)
    overlap = set(busy) & set(free)
    if overlap:
        raise ValueError(f"{len(overlap)} files appear in both busy and free folders, e.g. {next(iter(overlap))}")
    labels = np.concatenate([np.full(len(busy), POS, np.int8), np.full(len(free), NEG, np.int8)])
    return LabelledImages(busy + free, labels)


def load_rgb(path: str | Path) -> Image.Image:
    """Open an image as 3-channel RGB (grayscale/palette/alpha images are converted)."""
    with Image.open(path) as img:
        return img.convert("RGB")


def find_unreadable(paths: list[Path]) -> list[tuple[Path, str]]:
    """Fully decode every image; return (path, error) for each one that fails.

    Run before feature extraction so a corrupt file stops the job early instead of
    after GPU time has been spent, and so no file is silently dropped (which would
    misalign features and labels).
    """
    bad = []
    for path in paths:
        try:
            with Image.open(path) as img:
                img.load()
        except (OSError, UnidentifiedImageError, ValueError) as exc:
            bad.append((path, f"{type(exc).__name__}: {exc}"))
    return bad
