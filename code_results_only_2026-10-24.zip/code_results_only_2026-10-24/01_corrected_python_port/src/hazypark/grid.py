"""Fast exhaustive grid evaluation for Pin-GTSVM.

The kernel, the Cholesky factors and both dual Hessians depend only on sigma, and each
plane depends only on its own (c, tau). So for every sigma the expensive matrices are
built once, plane 1 is solved for each (c1, tau) and plane 2 for each (c2, tau), and all
c1 x c2 combinations are scored by combining the two distance vectors. For the paper's
grid (11 x 11 x 21 x 3 = 7623 combinations) this needs 21 x 66 QP solves instead of
7623 x 2. Results are identical to fitting ``PinGTSVM`` per combination (tested).
"""

from __future__ import annotations

import itertools
import time
from dataclasses import dataclass

import numpy as np

from .pin_gtsvm import (
    NEG,
    POS,
    build_twin_problems,
    eval_kernel,
    solve_box_qp,
    surface_distance,
    surface_norm,
    validate_params,
    validate_xy,
)


@dataclass
class GridResult:
    params: list[dict]  # one dict per combination, same order as rows of ``predictions``
    predictions: np.ndarray  # (n_combinations, n_eval) int8 labels in {+1, -1}
    qp_status: list[tuple[str, str]]
    seconds: float


def expand_values(spec) -> list[float]:
    """A list of numbers, or {"log2": [lo, hi]} meaning 2**lo ... 2**hi (integer steps)."""
    if isinstance(spec, dict):
        if set(spec) != {"log2"} or len(spec["log2"]) != 2:
            raise ValueError(f"grid spec must be a list or {{'log2': [lo, hi]}}, got {spec!r}")
        lo, hi = (int(v) for v in spec["log2"])
        if lo > hi:
            raise ValueError(f"log2 range is empty: {spec!r}")
        return [float(2.0**p) for p in range(lo, hi + 1)]
    values = [float(v) for v in spec]
    if not values:
        raise ValueError("grid value list is empty")
    return values


def evaluate_grid(
    X_train,
    y_train,
    X_eval,
    grid: dict,
    kernel: str = "rbf",
    eps: float = 0.05,
    qp_options: dict | None = None,
) -> GridResult:
    """Predict ``X_eval`` for every combination of ``grid`` = {c1, c2, tau[, sigma]}."""
    start = time.perf_counter()
    X_train, y_train = validate_xy(X_train, y_train)
    X_eval = np.asarray(X_eval, dtype=np.float64)
    if X_eval.ndim != 2 or X_eval.shape[1] != X_train.shape[1]:
        raise ValueError(f"X_eval must have shape (n, {X_train.shape[1]}), got {X_eval.shape}")
    c1s, c2s, taus = (expand_values(grid[k]) for k in ("c1", "c2", "tau"))
    sigmas = expand_values(grid["sigma"]) if kernel == "rbf" else [None]
    for c1, c2, tau, sigma in itertools.product(c1s, c2s, taus, sigmas):
        validate_params(c1, c2, tau, kernel, sigma, eps)

    A, B = X_train[y_train == POS], X_train[y_train == NEG]
    params, preds, statuses = [], [], []
    for sigma in sigmas:
        problems = build_twin_problems(A, B, kernel, sigma, eps)
        K_eval = eval_kernel(problems, X_eval)
        for tau in taus:
            d1, s1 = _plane_distances(problems.plane1, problems.gram, K_eval, c1s, tau, qp_options)
            d2, s2 = _plane_distances(problems.plane2, problems.gram, K_eval, c2s, tau, qp_options)
            for i, c1 in enumerate(c1s):
                for j, c2 in enumerate(c2s):
                    params.append({"c1": c1, "c2": c2, "tau": tau, "sigma": sigma})
                    preds.append(np.where(d1[i] <= d2[j], POS, NEG).astype(np.int8))
                    statuses.append((s1[i], s2[j]))
    return GridResult(params, np.vstack(preds), statuses, time.perf_counter() - start)


def _plane_distances(plane, gram, K_eval, cs, tau, qp_options):
    distances, statuses = [], []
    for c in cs:
        dual, status = solve_box_qp(plane.Q, c, tau, qp_options)
        coef = plane.recover @ dual
        w, b = coef[:-1], float(coef[-1])
        distances.append(surface_distance(K_eval, w, b, surface_norm(w, gram)))
        statuses.append(status)
    return distances, statuses


__all__ = ["GridResult", "evaluate_grid", "expand_values", "NEG", "POS"]
