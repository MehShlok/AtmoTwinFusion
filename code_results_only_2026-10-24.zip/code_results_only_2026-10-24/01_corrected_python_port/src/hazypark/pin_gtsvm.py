"""Pinball-loss general twin SVM (Pin-GTSVM): corrected Python port of ``pinGTSVM_RBF_1.m``.

Formulation (Tanveer, Sharma & Suganthan, Information Sciences 494, 2019; the dual
follows the Pin-TWSVM derivation restated in arXiv:2107.06744, eqs. 2-7)::

    H = [K(A, D), e],  G = [K(B, D), e],  D = [A; B]      (RBF kernel)
    H = [A, e],        G = [B, e]                        (linear kernel)

    plane 1 (proximal to class +1 = A):
        min_u  1/2 ||H u||^2 + eps/2 ||u||^2 + c1 * sum_i L_tau(1 + G_i u)
        dual:  min_l  1/2 l' G (H'H + eps I)^-1 G' l - e' l    s.t.  -tau*c1 <= l <= c1
               u = -(H'H + eps I)^-1 G' l

    plane 2 (proximal to class -1 = B): roles of H and G swapped,
               v = (G'G + eps I)^-1 H' g,   -tau*c2 <= g <= c2

with the pinball loss L_tau(t) = t for t >= 0 and -tau*t for t < 0 (tau = 0 gives the
hinge-loss TWSVM of Jayadeva et al. 2007). A sample is assigned to the class whose
surface is nearer, using the normalised distance |K(x, D) w + b| / ||w||, where
||w||^2 = w' K(D, D) w (RBF) or w'w (linear).

Corrections relative to the MATLAB source (see README.md):
  * dual linear term is -e (MATLAB used -tau*e);
  * box is [-tau*c, c] (MATLAB had no lower bound and upper bound (1-tau)*c, which makes
    tau = 1 collapse to w = 0);
  * distances are normalised by ||w|| (MATLAB compared |f(x)| directly);
  * linear-kernel prediction uses every feature column (MATLAB dropped the last one);
  * (H'H + eps I) is Cholesky-factorised instead of pinv (same result, stable and faster).
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np
from cvxopt import matrix, solvers, sparse, spmatrix
from scipy.linalg import cho_factor, cho_solve
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.exceptions import ConvergenceWarning
from sklearn.utils.validation import check_is_fitted

POS, NEG = 1, -1
KERNELS = ("rbf", "linear")
_DEFAULT_QP_OPTIONS = {"show_progress": False, "abstol": 1e-7, "reltol": 1e-6, "feastol": 1e-7, "maxiters": 100}
_ZERO_NORM = 1e-12


def rbf_kernel(X: np.ndarray, Y: np.ndarray, sigma: float) -> np.ndarray:
    """Gaussian kernel exp(-||x - y||^2 / (2 sigma^2)), as in the paper (Sec. 3.7.2)."""
    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError(f"sigma must be a positive finite number, got {sigma!r}")
    X = np.asarray(X, dtype=np.float64)
    Y = np.asarray(Y, dtype=np.float64)
    sq = np.einsum("ij,ij->i", X, X)[:, None] + np.einsum("ij,ij->i", Y, Y)[None, :] - 2.0 * (X @ Y.T)
    np.maximum(sq, 0.0, out=sq)  # remove tiny negatives from floating-point cancellation
    return np.exp(-sq / (2.0 * sigma**2))


def _augment(M: np.ndarray) -> np.ndarray:
    return np.hstack([M, np.ones((M.shape[0], 1))])


@dataclass(frozen=True)
class PlaneProblem:
    """Dual QP of one plane: Hessian ``Q`` and the map ``recover`` from duals to [w; b]."""

    Q: np.ndarray
    recover: np.ndarray


@dataclass(frozen=True)
class TwinProblems:
    """Everything that depends only on (training data, kernel, sigma, eps)."""

    plane1: PlaneProblem
    plane2: PlaneProblem
    basis: np.ndarray | None  # D = [A; B] for RBF, None for linear
    gram: np.ndarray | None  # K(D, D) for RBF, None for linear
    sigma: float | None


def _plane(proximal: np.ndarray, opposite: np.ndarray, eps: float, sign: float) -> PlaneProblem:
    ptp = proximal.T @ proximal
    ptp[np.diag_indices_from(ptp)] += eps
    factor = cho_factor(ptp, lower=True, check_finite=False)
    S = cho_solve(factor, opposite.T, check_finite=False)  # (P'P + eps I)^-1 Q'
    Q = opposite @ S
    Q = 0.5 * (Q + Q.T)
    return PlaneProblem(Q=Q, recover=sign * S)


def build_twin_problems(A: np.ndarray, B: np.ndarray, kernel: str, sigma: float | None, eps: float) -> TwinProblems:
    """Build both dual QPs. A = class +1 samples, B = class -1 samples."""
    if kernel not in KERNELS:
        raise ValueError(f"kernel must be one of {KERNELS}, got {kernel!r}")
    if not np.isfinite(eps) or eps <= 0:
        raise ValueError(f"eps must be a positive finite number, got {eps!r}")
    if kernel == "rbf":
        D = np.vstack([A, B])
        KA, KB = rbf_kernel(A, D, sigma), rbf_kernel(B, D, sigma)
        gram = np.vstack([KA, KB])
        H, G = _augment(KA), _augment(KB)
        basis = D
    else:
        H, G = _augment(A), _augment(B)
        basis = gram = None
        sigma = None
    return TwinProblems(
        plane1=_plane(H, G, eps, sign=-1.0),
        plane2=_plane(G, H, eps, sign=+1.0),
        basis=basis,
        gram=gram,
        sigma=sigma,
    )


def solve_box_qp(Q: np.ndarray, c: float, tau: float, qp_options: dict | None = None) -> tuple[np.ndarray, str]:
    """Solve  min 1/2 x'Qx - e'x  s.t.  -tau*c <= x <= c  with CVXOPT's interior-point method."""
    n = Q.shape[0]
    options = {**_DEFAULT_QP_OPTIONS, **(qp_options or {})}
    identity = spmatrix(1.0, range(n), range(n))
    h = np.concatenate([np.full(n, float(c)), np.full(n, float(tau) * float(c))])
    sol = solvers.qp(
        matrix(np.ascontiguousarray(Q, dtype=np.float64)),
        matrix(-np.ones(n)),
        sparse([identity, -identity]),
        matrix(h),
        options=options,
    )
    status = sol["status"]
    if status != "optimal":
        warnings.warn(f"QP solver status '{status}' (n={n}, c={c}, tau={tau})", ConvergenceWarning, stacklevel=2)
    x = np.clip(np.asarray(sol["x"]).ravel(), -tau * c, c)
    return x, status


def surface_norm(w: np.ndarray, gram: np.ndarray | None) -> float:
    """||w|| in the feature space: sqrt(w'K w) for RBF, Euclidean norm for linear."""
    sq = float(w @ gram @ w) if gram is not None else float(w @ w)
    return float(np.sqrt(max(sq, 0.0)))


def surface_distance(K_eval: np.ndarray, w: np.ndarray, b: float, norm: float) -> np.ndarray:
    """|K_eval w + b| / ||w||; +inf when the surface is degenerate (||w|| ~ 0)."""
    raw = np.abs(K_eval @ w + b)
    if norm < _ZERO_NORM:
        return np.full_like(raw, np.inf)
    return raw / norm


def eval_kernel(problems: TwinProblems, X: np.ndarray) -> np.ndarray:
    """Kernel rows for evaluation samples (without the bias column)."""
    if problems.basis is None:
        return np.asarray(X, dtype=np.float64)
    return rbf_kernel(X, problems.basis, problems.sigma)


def validate_xy(X, y) -> tuple[np.ndarray, np.ndarray]:
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y).ravel()
    if X.ndim != 2:
        raise ValueError(f"X must be 2-D, got shape {X.shape}")
    if X.shape[0] != y.shape[0]:
        raise ValueError(f"X has {X.shape[0]} rows but y has {y.shape[0]} labels")
    if not np.all(np.isfinite(X)):
        raise ValueError("X contains NaN or infinite values")
    labels = set(np.unique(y).tolist())
    if not labels <= {POS, NEG}:
        raise ValueError(f"labels must be +1 (busy) / -1 (free), got {sorted(labels)}")
    if labels != {POS, NEG}:
        raise ValueError("training data must contain both classes (+1 and -1)")
    return X, y.astype(int)


def validate_params(c1: float, c2: float, tau: float, kernel: str, sigma: float | None, eps: float) -> None:
    for name, val in (("c1", c1), ("c2", c2)):
        if not np.isfinite(val) or val <= 0:
            raise ValueError(f"{name} must be positive, got {val!r}")
    if not 0.0 <= tau <= 1.0:
        raise ValueError(f"tau must lie in [0, 1], got {tau!r}")
    if kernel not in KERNELS:
        raise ValueError(f"kernel must be one of {KERNELS}, got {kernel!r}")
    if kernel == "rbf" and (sigma is None or not np.isfinite(sigma) or sigma <= 0):
        raise ValueError(f"sigma must be positive for the RBF kernel, got {sigma!r}")
    if not np.isfinite(eps) or eps <= 0:
        raise ValueError(f"eps must be positive, got {eps!r}")


class PinGTSVM(ClassifierMixin, BaseEstimator):
    """Pin-GTSVM binary classifier. Labels must be +1 (busy) and -1 (free).

    Parameters mirror ``FunPara`` in the MATLAB code: ``c1``, ``c2``, ``tau`` and the
    Gaussian width ``sigma`` (``kerfPara.pars``, called mu in the paper). ``eps`` is the
    MATLAB ``eps1 = eps2 = 0.05`` ridge term. Ties in distance go to class +1, as in MATLAB.
    """

    def __init__(self, c1=1.0, c2=1.0, tau=0.5, kernel="rbf", sigma=1.0, eps=0.05, qp_options=None):
        self.c1 = c1
        self.c2 = c2
        self.tau = tau
        self.kernel = kernel
        self.sigma = sigma
        self.eps = eps
        self.qp_options = qp_options

    def fit(self, X, y):
        X, y = validate_xy(X, y)
        validate_params(self.c1, self.c2, self.tau, self.kernel, self.sigma, self.eps)
        problems = build_twin_problems(X[y == POS], X[y == NEG], self.kernel, self.sigma, self.eps)
        lam, status1 = solve_box_qp(problems.plane1.Q, self.c1, self.tau, self.qp_options)
        gam, status2 = solve_box_qp(problems.plane2.Q, self.c2, self.tau, self.qp_options)
        u = problems.plane1.recover @ lam
        v = problems.plane2.recover @ gam
        self.w1_, self.b1_ = u[:-1], float(u[-1])
        self.w2_, self.b2_ = v[:-1], float(v[-1])
        self.norm1_ = surface_norm(self.w1_, problems.gram)
        self.norm2_ = surface_norm(self.w2_, problems.gram)
        for idx, norm in ((1, self.norm1_), (2, self.norm2_)):
            if norm < _ZERO_NORM:
                warnings.warn(f"surface {idx} is degenerate (||w|| ~ 0)", ConvergenceWarning, stacklevel=2)
        self.basis_ = problems.basis
        self.dual_coef_ = (lam, gam)
        self.qp_status_ = (status1, status2)
        self.classes_ = np.array([NEG, POS])
        self.n_features_in_ = X.shape[1]
        return self

    def _kernel_rows(self, X) -> np.ndarray:
        check_is_fitted(self, "w1_")
        X = np.asarray(X, dtype=np.float64)
        if X.ndim != 2 or X.shape[1] != self.n_features_in_:
            raise ValueError(f"X must have shape (n, {self.n_features_in_}), got {X.shape}")
        if not np.all(np.isfinite(X)):
            raise ValueError("X contains NaN or infinite values")
        if self.kernel == "rbf":
            return rbf_kernel(X, self.basis_, self.sigma)
        return X

    def distances(self, X) -> np.ndarray:
        """(n, 2) array of normalised distances to surface 1 (class +1) and surface 2 (class -1)."""
        K = self._kernel_rows(X)
        d1 = surface_distance(K, self.w1_, self.b1_, self.norm1_)
        d2 = surface_distance(K, self.w2_, self.b2_, self.norm2_)
        return np.column_stack([d1, d2])

    def decision_function(self, X) -> np.ndarray:
        """d2 - d1: positive means class +1. Usable as a ranking score (ROC/AUC)."""
        d = self.distances(X)
        with np.errstate(invalid="ignore"):
            return d[:, 1] - d[:, 0]

    def predict(self, X) -> np.ndarray:
        d = self.distances(X)
        return np.where(d[:, 0] <= d[:, 1], POS, NEG)
