"""Python port of arXiv:2501.13422 (hybrid CNN features + Pin-GTSVM, hazy parking)."""

from .pin_gtsvm import PinGTSVM, rbf_kernel

__all__ = ["PinGTSVM", "rbf_kernel"]
__version__ = "0.1.0"
