import argparse
import importlib.util
from pathlib import Path

import pytest

_SPEC = importlib.util.spec_from_file_location("bench_solver", Path(__file__).resolve().parents[1] / "scripts" / "bench_solver.py")
bench = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(bench)


def test_parse_size():
    assert bench.parse_size("10:20:3") == (10, 20, 3)
    for bad in ("10:20", "a:b:c", "0:5:5", "-1:5:5"):
        with pytest.raises(argparse.ArgumentTypeError):
            bench.parse_size(bad)


def test_run_reports_every_field():
    row = bench.run(30, 20, 4)
    assert set(row) == set(bench.FIELDS)
    assert row["qp1_status"] == row["qp2_status"] == "optimal"
    assert row["fit_s"] >= row["build_s"] >= 0
