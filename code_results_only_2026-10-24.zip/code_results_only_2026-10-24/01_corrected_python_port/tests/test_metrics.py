import math

import numpy as np
import pytest
from sklearn.metrics import balanced_accuracy_score, f1_score, matthews_corrcoef, precision_score, recall_score

from hazypark.metrics import accuracy_rows, binary_metrics


def test_metrics_match_sklearn():
    rng = np.random.default_rng(0)
    y = rng.choice([1, -1], 200)
    p = np.where(rng.random(200) < 0.8, y, -y)
    m = binary_metrics(y, p)
    assert m["tp"] + m["fp"] + m["tn"] + m["fn"] == 200
    assert m["precision"] == pytest.approx(precision_score(y, p, pos_label=1))
    assert m["recall"] == pytest.approx(recall_score(y, p, pos_label=1))
    assert m["specificity"] == pytest.approx(recall_score(y, p, pos_label=-1))
    assert m["f1"] == pytest.approx(f1_score(y, p, pos_label=1))
    assert m["balanced_accuracy"] == pytest.approx(balanced_accuracy_score(y, p))
    assert m["mcc"] == pytest.approx(matthews_corrcoef(y, p))


def test_known_confusion_matrix():
    y = np.array([1, 1, 1, -1, -1])
    p = np.array([1, 1, -1, 1, -1])
    m = binary_metrics(y, p)
    assert (m["tp"], m["fp"], m["tn"], m["fn"]) == (2, 1, 1, 1)
    assert m["accuracy"] == pytest.approx(0.6)


def test_undefined_ratios_are_nan_not_zero():
    m = binary_metrics(np.array([1, -1]), np.array([-1, -1]))  # nothing predicted positive
    assert math.isnan(m["precision"]) and math.isnan(m["mcc"])
    assert m["recall"] == 0.0


@pytest.mark.parametrize("y,p", [([1, -1], [1]), ([], []), ([1, 0], [1, -1])])
def test_metric_validation(y, p):
    with pytest.raises(ValueError):
        binary_metrics(np.array(y), np.array(p))


def test_accuracy_rows():
    y = np.array([1, -1, 1])
    preds = np.array([[1, -1, 1], [-1, -1, -1]])
    np.testing.assert_allclose(accuracy_rows(y, preds), [1.0, 1 / 3])
