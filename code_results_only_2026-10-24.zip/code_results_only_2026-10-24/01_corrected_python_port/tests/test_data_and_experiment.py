import json
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from hazypark.data import find_unreadable, list_images, load_rgb, load_split
from hazypark.experiment import feature_file, load_config, run_classify, select_best

CONFIG_DIR = Path(__file__).resolve().parents[1] / "configs"


def _img(path: Path, mode="RGB"):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new(mode, (8, 6)).save(path)


# ---------------------------------------------------------------- data
def test_split_is_recursive_sorted_and_busy_first(tmp_path):
    _img(tmp_path / "busy" / "b.png")
    _img(tmp_path / "busy" / "sub" / "a.JPG")
    _img(tmp_path / "free" / "c.png", mode="L")
    (tmp_path / "busy" / "notes.txt").write_text("ignore me")
    split = load_split(tmp_path / "busy", tmp_path / "free")
    assert [p.name for p in split.paths] == ["b.png", "a.JPG", "c.png"]
    assert split.labels.tolist() == [1, 1, -1]
    assert load_rgb(split.paths[2]).mode == "RGB"  # grayscale converted


def test_missing_and_empty_folders(tmp_path):
    with pytest.raises(FileNotFoundError):
        list_images(tmp_path / "nope")
    (tmp_path / "empty").mkdir()
    with pytest.raises(ValueError, match="no images"):
        list_images(tmp_path / "empty")


def test_same_folder_for_both_classes_is_rejected(tmp_path):
    _img(tmp_path / "x" / "a.png")
    with pytest.raises(ValueError, match="both busy and free"):
        load_split(tmp_path / "x", tmp_path / "x")


def test_corrupt_image_is_reported(tmp_path):
    good, bad = tmp_path / "ok.png", tmp_path / "bad.png"
    _img(good)
    bad.write_bytes(b"not an image")
    report = find_unreadable([good, bad])
    assert [p for p, _ in report] == [bad]


# ---------------------------------------------------------------- config
@pytest.mark.parametrize("cfg", sorted(CONFIG_DIR.glob("*.yaml")), ids=lambda p: p.stem)
def test_shipped_configs_are_valid(cfg):
    loaded = load_config(cfg)
    assert loaded["name"] == cfg.stem


def test_config_validation(tmp_path):
    bad = tmp_path / "bad.yaml"
    bad.write_text("name: x\nfeatures: {}\ndata: {train: {busy: a}, test: {busy: a, free: b}}\nclassifier: {grid: {}}\nevaluation: {}\n")
    with pytest.raises(ValueError, match="busy"):
        load_config(bad)


def test_select_best_tie_breaks_towards_simpler_model():
    import pandas as pd

    df = pd.DataFrame(
        {"c1": [1.0, 0.5, 0.5], "c2": [1.0, 0.5, 0.5], "tau": [0.5] * 3, "sigma": [1.0, 1.0, 4.0], "score": [0.9, 0.9, 0.9]}
    )
    assert select_best(df, "score")["sigma"] == 4.0


# ---------------------------------------------------------------- end to end on synthetic features
def _write_features(path: Path, X, y):
    path.parent.mkdir(parents=True, exist_ok=True)
    paths = np.array([f"img_{i}.png" for i in range(len(y))])
    np.savez(path, X=X.astype(np.float32), y=y.astype(np.int8), paths=paths, meta=json.dumps({"model": "synthetic"}))


def test_run_classify_end_to_end(tmp_path):
    rng = np.random.default_rng(0)

    def make(n):
        y = np.r_[np.ones(n, int), -np.ones(n, int)]
        return rng.normal(size=(2 * n, 6)) + 1.2 * y[:, None], y

    cfg = {
        "name": "synthetic",
        "features": {"model": "resnet50", "layer": "fc1000"},
        "data": {"train": {"busy": "a", "free": "b"}, "test": {"busy": "c", "free": "d"}},
        "classifier": {"kernel": "rbf", "eps": 0.05, "standardize": True,
                       "grid": {"c1": [0.5, 2], "c2": [0.5, 2], "tau": [0.5, 1.0], "sigma": [1, 4]}},
        "evaluation": {"protocols": ["cv_select", "test_select"], "cv_folds": 3, "seed": 0},
        "output_root": str(tmp_path),
    }
    _write_features(feature_file(cfg, "train"), *make(30))
    _write_features(feature_file(cfg, "test"), *make(20))
    run_dir = run_classify(cfg)
    summary = json.loads((run_dir / "summary.json").read_text())
    for proto in ("cv_select", "test_select"):
        res = summary["protocols"][proto]
        assert res["metrics"]["accuracy"] > 0.85
        assert res["qp_status"] == ["optimal", "optimal"]
        assert len(res["false_positives"]) == res["metrics"]["fp"]
    assert (run_dir / "cv_grid.csv").exists() and (run_dir / "test_grid_paper_protocol.csv").exists()
    assert "PAPER PROTOCOL" in summary["protocols"]["test_select"]["note"]
