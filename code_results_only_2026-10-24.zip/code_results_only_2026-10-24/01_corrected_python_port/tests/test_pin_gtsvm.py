import numpy as np
import pytest
from cvxopt import matrix, solvers
from sklearn.metrics.pairwise import rbf_kernel as sk_rbf

from hazypark.grid import evaluate_grid, expand_values
from hazypark.pin_gtsvm import PinGTSVM, build_twin_problems, rbf_kernel, solve_box_qp


def blobs(n_per_class=40, d=5, shift=2.5, seed=0):
    rng = np.random.default_rng(seed)
    A = rng.normal(0, 1, (n_per_class, d)) + shift
    B = rng.normal(0, 1, (n_per_class, d)) - shift
    X = np.vstack([A, B])
    y = np.r_[np.ones(n_per_class, int), -np.ones(n_per_class, int)]
    return X, y


# ---------------------------------------------------------------- kernel
def test_rbf_matches_sklearn():
    rng = np.random.default_rng(1)
    X, Y = rng.normal(size=(7, 4)), rng.normal(size=(5, 4))
    sigma = 1.7
    np.testing.assert_allclose(rbf_kernel(X, Y, sigma), sk_rbf(X, Y, gamma=1 / (2 * sigma**2)), rtol=1e-12, atol=1e-14)


def test_rbf_self_distance_is_exactly_one():
    X = np.random.default_rng(2).normal(size=(6, 3)) * 1e3
    np.testing.assert_allclose(np.diag(rbf_kernel(X, X, 0.5)), 1.0)


@pytest.mark.parametrize("sigma", [0, -1, np.nan, np.inf])
def test_rbf_rejects_bad_sigma(sigma):
    with pytest.raises(ValueError):
        rbf_kernel(np.zeros((1, 1)), np.zeros((1, 1)), sigma)


# ---------------------------------------------------------------- QP
@pytest.mark.parametrize("tau", [0.0, 0.5, 1.0])
def test_box_qp_satisfies_kkt(tau):
    rng = np.random.default_rng(3)
    M = rng.normal(size=(15, 15))
    Q = M @ M.T / 15
    c = 0.7
    x, status = solve_box_qp(Q, c, tau)
    assert status == "optimal"
    assert np.all(x <= c + 1e-9) and np.all(x >= -tau * c - 1e-9)
    grad = Q @ x - 1.0
    tol = 1e-4
    upper, lower = x > c - tol, x < -tau * c + tol
    free = ~(upper | lower)
    assert np.all(np.abs(grad[free]) < 1e-3)
    assert np.all(grad[upper & ~lower] <= 1e-3)  # at upper bound the gradient must push upward
    assert np.all(grad[lower & ~upper] >= -1e-3)


def _solve_primal_plane(P, Opp, c, tau, eps, sign):
    """Directly solve the primal pinball QP of one plane (independent of the dual derivation).

    sign=-1 (plane 1):  Opp u <= -1 + xi  and  -tau*Opp u <= tau + xi  (opposite class on the negative side)
    sign=+1 (plane 2): -Opp v <= -1 + xi  and   tau*Opp v <= tau + xi
    """
    p, m = P.shape[1], Opp.shape[0]
    Pm = np.zeros((p + m, p + m))
    Pm[:p, :p] = P.T @ P + eps * np.eye(p)
    q = np.r_[np.zeros(p), c * np.ones(m)]
    S = -sign * Opp
    G = np.block([[S, -np.eye(m)], [-tau * S, -np.eye(m)]])
    h = np.r_[-np.ones(m), tau * np.ones(m)]
    sol = solvers.qp(matrix(Pm), matrix(q), matrix(G), matrix(h), options={"show_progress": False, "abstol": 1e-9, "reltol": 1e-9, "feastol": 1e-9, "maxiters": 200})
    assert sol["status"] == "optimal"
    return np.asarray(sol["x"]).ravel()[:p]


@pytest.mark.parametrize("kernel,sigma", [("linear", None), ("rbf", 2.0)])
@pytest.mark.parametrize("tau", [0.0, 0.5, 1.0])
def test_dual_solution_matches_primal(kernel, sigma, tau):
    """The dual box [-tau*c, c] and u = -(H'H+eps I)^-1 G' l reproduce the primal optimum."""
    X, y = blobs(15, 3, shift=1.0, seed=4)  # overlapping classes -> active pinball terms
    A, B = X[y == 1], X[y == -1]
    eps, c1, c2 = 0.05, 0.8, 1.3
    probs = build_twin_problems(A, B, kernel, sigma, eps)
    if kernel == "rbf":
        D = np.vstack([A, B])
        H = np.hstack([rbf_kernel(A, D, sigma), np.ones((len(A), 1))])
        G = np.hstack([rbf_kernel(B, D, sigma), np.ones((len(B), 1))])
    else:
        H, G = np.hstack([A, np.ones((len(A), 1))]), np.hstack([B, np.ones((len(B), 1))])
    opts = {"abstol": 1e-10, "reltol": 1e-10, "feastol": 1e-10}
    u_dual = probs.plane1.recover @ solve_box_qp(probs.plane1.Q, c1, tau, opts)[0]
    v_dual = probs.plane2.recover @ solve_box_qp(probs.plane2.Q, c2, tau, opts)[0]
    u_primal = _solve_primal_plane(H, G, c1, tau, eps, sign=-1)
    v_primal = _solve_primal_plane(G, H, c2, tau, eps, sign=+1)
    np.testing.assert_allclose(u_dual, u_primal, atol=1e-5)
    np.testing.assert_allclose(v_dual, v_primal, atol=1e-5)


# ---------------------------------------------------------------- estimator
@pytest.mark.parametrize("kernel,sigma", [("rbf", 3.0), ("linear", None)])
@pytest.mark.parametrize("tau", [0.0, 0.5, 0.8, 1.0])
def test_separable_blobs_are_learned(kernel, sigma, tau):
    X, y = blobs(seed=5)
    Xt, yt = blobs(seed=6)
    model = PinGTSVM(c1=1, c2=1, tau=tau, kernel=kernel, sigma=sigma).fit(X, y)
    assert model.qp_status_ == ("optimal", "optimal")
    assert (model.predict(Xt) == yt).mean() >= 0.97


def test_tau_one_is_not_degenerate():
    """MATLAB bug: tau=1 forced w=0 and predicted +1 for everything."""
    X, y = blobs(30, 4, shift=1.5, seed=7)
    model = PinGTSVM(tau=1.0, sigma=2.0).fit(X, y)
    assert model.norm1_ > 1e-6 and model.norm2_ > 1e-6
    assert set(np.unique(model.predict(X))) == {1, -1}


def test_tau_zero_gives_nonnegative_duals():
    X, y = blobs(20, 3, shift=1.0, seed=8)
    lam, gam = PinGTSVM(tau=0.0, sigma=1.0).fit(X, y).dual_coef_
    assert lam.min() >= 0 and gam.min() >= 0


def test_decision_function_sign_agrees_with_predict():
    X, y = blobs(25, 3, shift=0.8, seed=9)
    model = PinGTSVM(sigma=1.5).fit(X, y)
    score, pred = model.decision_function(X), model.predict(X)
    assert np.all(pred[score > 0] == 1) and np.all(pred[score < 0] == -1)


def test_linear_prediction_uses_all_columns():
    """MATLAB bug: linear branch dropped the last test column (dimension mismatch)."""
    X, y = blobs(20, 4, seed=10)
    model = PinGTSVM(kernel="linear").fit(X, y)
    assert model.w1_.shape == (4,)
    assert model.predict(X).shape == (40,)


@pytest.mark.parametrize(
    "X,y,match",
    [
        (np.zeros((3, 2)), np.array([1, 1, 1]), "both classes"),
        (np.zeros((3, 2)), np.array([1, 0, -1]), r"\+1"),
        (np.zeros((3, 2)), np.array([1, -1]), "rows"),
        (np.array([[np.nan, 0], [1, 1]]), np.array([1, -1]), "NaN"),
        (np.zeros(4), np.array([1, -1, 1, -1]), "2-D"),
    ],
)
def test_input_validation(X, y, match):
    with pytest.raises(ValueError, match=match):
        PinGTSVM().fit(X, y)


@pytest.mark.parametrize("kw", [{"c1": 0}, {"c2": -1}, {"tau": 1.5}, {"tau": -0.1}, {"sigma": 0}, {"eps": 0}, {"kernel": "poly"}])
def test_param_validation(kw):
    X, y = blobs(5, 2)
    with pytest.raises(ValueError):
        PinGTSVM(**kw).fit(X, y)


def test_predict_rejects_wrong_dimension():
    X, y = blobs(5, 2)
    model = PinGTSVM().fit(X, y)
    with pytest.raises(ValueError, match="shape"):
        model.predict(np.zeros((2, 3)))


# ---------------------------------------------------------------- grid
@pytest.mark.parametrize("kernel", ["rbf", "linear"])
def test_grid_matches_individual_fits(kernel):
    X, y = blobs(20, 3, shift=0.7, seed=11)
    Xe, _ = blobs(15, 3, shift=0.7, seed=12)
    grid = {"c1": [0.25, 2.0], "c2": [0.5, 4.0], "tau": [0.5, 1.0], "sigma": [0.5, 2.0]}
    res = evaluate_grid(X, y, Xe, grid, kernel=kernel)
    expected_rows = 2 * 2 * 2 * (2 if kernel == "rbf" else 1)
    assert res.predictions.shape == (expected_rows, 30)
    for params, pred in zip(res.params, res.predictions):
        model = PinGTSVM(kernel=kernel, **params).fit(X, y)
        np.testing.assert_array_equal(pred, model.predict(Xe))


def test_expand_values():
    assert expand_values({"log2": [-2, 1]}) == [0.25, 0.5, 1.0, 2.0]
    assert expand_values([0.5, 1]) == [0.5, 1.0]
    for bad in ({"log2": [2, 1]}, {"lin": [1, 2]}, []):
        with pytest.raises(ValueError):
            expand_values(bad)
