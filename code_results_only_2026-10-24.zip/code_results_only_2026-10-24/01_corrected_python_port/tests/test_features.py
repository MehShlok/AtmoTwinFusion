"""Feature-extractor shape checks. Skipped when torch is not installed (runs on Kaggle)."""

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("torchvision")

from hazypark.features import LAYERS, build_extractor  # noqa: E402


@pytest.mark.parametrize("key", sorted(LAYERS), ids=lambda k: f"{k[0]}-{k[1]}")
def test_layer_dimensions(key):
    model, layer = key
    extractor, spec = build_extractor(model, layer, pretrained=False)
    with torch.inference_mode():
        out = extractor(torch.zeros(2, 3, 224, 224))
    assert out.shape == (2, spec.dim)
