# Code behind the results — ViT features + Pin-GTSVM on ImageNet-C

Packed 2026-10-24 from git commit `54b6deb07bebb8dd9f6ad706cc6747cad699a85f`. Only code that produced a result we use or report as evidence, plus the code
it imports. SHA-256 checksums in `MANIFEST.json`.

| Folder | Contents |
|---|---|
| `01_corrected_python_port/` | Package `hazypark`: the paper's Pin-GTSVM, corrected (audit) and verified (67 tests; dual = primal to 1e-5). Its CVXOPT solver produced the exact reference predictions |
| `02_study_package/` | Package `vitpin`: `class_sets.py` + `scripts/select_classes.py` (the two 20-class sets), `imagenet_c.py` (manifest, split, leakage check), `features.py` (feature extraction, speed metrics), `phase8.py` (reference solver wrapper, accuracy gate, grid, tuning folds), `exact_torch.py` (the validated exact solver on GPU), `fast_pin.py` (needed: the two modules above import its shared helpers); unit tests; `scripts/plot_phase7.py` (the Phase 7 figures) |
| `03_kaggle_notebooks/` | The notebooks whose results are used, in run order; `__EXECUTED` copies carry the Kaggle outputs (same code cells) |
| `04_kaggle_tools/` | `build_bundle.py` (made the code bundles), `run_cpu_tests.py` (runs every unit test on CPU) |
| `05_code_bundles_as_run/` | The exact code snapshot each notebook ran with (version + git commit in its `BUNDLE.json`), and the saved CVXOPT reference predictions used by the GPU checks |

| Phase | Notebook | Result | Results folder (project) | Bundle |
|---|---|---|---|---|
| phase6 | `01_phase6_data.ipynb` | Data checks run 1: 150,000 images, split, no leakage | `results/phase6/phase6/` | v1 |
| phase6 | `02_phase6_data_v2.ipynb` | Data checks run 2: same result, byte-identical image list (reproducibility) | `results/phase6/phase6_outputs_v2/` | v2 |
| phase7 | `01_phase7_features_v3.ipynb` | Features of all 7 frozen models (used by every later phase); speed and sanity results | `results/phase7/phase7_summary_v3/` | v5 |
| phase8 | `01_phase8_check_v3_dinov3_s16.ipynb` | Exact CVXOPT reference predictions, DINOv3-S (the reference for the gate) | `results/phase8/phase8_check_v3_dinov3_s16/` | v8 |
| phase8 | `02_phase8_check_v3_fastvit_sa24.ipynb` | Exact CVXOPT reference predictions, FastViT-SA24 (the run crashed later, after saving them) | `results/phase8/results_failed/` | v8 |
| phase8 | `03_phase8_check_v5_t4.ipynb` | Gate passed: the paper's exact method on a GPU matches CVXOPT (99.998 %) | `results/phase8/phase8_check_v5/` | v10 |
| phase8 | `04_phase8_check_v7_t4.ipynb` | Batched solver re-check passed; GPU budget of the main runs (12.8 h) | `results/phase8/phase8_check_v7/` | v12 |

Left out as not behind any result used: notebooks never run (Phase 6 v3, Phase 7 v2, Phase 8 check v2), superseded or
failed attempts (Phase 7 v1, Phase 8 checks v1 with shared landmarks, v4 crashed, v6 superseded by v7), their code
bundles (v3, v4, v6, v7, v9, v11), and the paper's original MATLAB code (input material, not our code). They remain in
the project repository and its git history.

Tests: `pip install -e 01_corrected_python_port -e 02_study_package`, then `pytest` inside each package folder.
